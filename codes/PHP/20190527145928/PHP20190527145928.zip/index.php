<?php
    echo("hello world! 1-23 exclude！！！！");
?>
