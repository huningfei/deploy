<?php
    echo("hello world!--v6.0");
?>
