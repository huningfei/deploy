<?php
/**
 *
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-22
 * UTF-8
 */
function load_library($class_name) {

	if (empty ( $class_name )) {
		return false;
	}

	$class_name_arr = explode('_', $class_name);
	if(empty($class_name_arr)){
		return false;
	}

	if(substr ( $class_name, 0, 2 ) != 'Xb'){
		return false;
	}

	$file_path = str_replace ( '_', '/', $class_name ) . '.php';

	$full_path=LIBRARY_DIR . '/' . $file_path;
	
	require_once $full_path;
	return true;
}
spl_autoload_register ( 'load_library' );

if(file_exists(LIBRARY_DIR.'/vendor/autoload.php')){
    include LIBRARY_DIR."/vendor/autoload.php";
}