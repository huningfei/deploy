<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/23
 * Time: 18:12
 */
class XbModel_Merchant_ShareTheme extends XbModel_BaseModel{
    static $cache_tag = "Merchant_ShareTheme_";
    //链接库
    function __construct() {
        parent::_init("xb_mis");
    }
    //标题列表
    public function getList($status,$merchant_id,$start,$limit){
        $sql = 'select * from `sharetheme` where 1=1 ';
        $data = array();
        if(!empty($status)){
            $sql .=' and `status`=:status ';
            $data[':status']=$status;
        }
        if(!empty($merchant_id)){
            $sql .=' and `merchant_id`=:merchant_id ';
            $data[':merchant_id']=$merchant_id;
        }
        $sql .= ' ORDER BY `id` desc ';
        $sql .= ' LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
    
    //获取标题
    public function getListCount($status=0,$merchant_id=0){
        $sql = 'select count(1) as `total` from `sharetheme` where 1=1 ';
        $data = array();
        if(!empty($status)){
            $sql .=' and `status`=:status ';
            $data[':status']=$status;
        }
        if(!empty($merchant_id)){
            $sql .=' and `merchant_id`=:merchant_id ';
            $data[':merchant_id']=$merchant_id;
        }
        $result= $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        return $result['total'];
    }
    
    //根据商户获取分享信息
    public function getShareTheme($merchant_id){
        $sql = 'select * from `sharetheme` where merchant_id=:merchant_id ';
        $data = array();
        $data[':merchant_id']=$merchant_id;
        
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    
    //根据商户获取分享信息
    public function getDetail($id){
        $sql = 'select * from `sharetheme` where id=:id ';
        $data = array();
        $data[':id']=$id;
        
        return $this->dao->conn()->setTag(self::$cache_tag.'_'.$id)->preparedSql($sql, $data)->fetchOne();
    }
    //添加标题
    public function addTheme($sharetitle,$sharetext,$shareurl,$shareimg,$uid,$status,$merchant_id){
        $sql = 'INSERT INTO `sharetheme` (`sharetitle`, `sharetext`,`shareurl`,`shareimg`, `uid`, `status`,`merchant_id`, `create_time`) VALUES (:sharetitle,:sharetext,:shareurl,:shareimg,:uid,:status,:merchant_id,:create_time)';
        $data = array(
            ':sharetitle'        => $sharetitle,
            ':sharetext'       => $sharetext,
            ':shareurl'  => $shareurl,
            ':shareimg'  => $shareimg,
            ':uid'    => $uid,
            ':status'        => $status,
            ':merchant_id'=>$merchant_id,
            ':create_time'      => time()
        );
       return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
       
    }
    //修改标题信息
    public function updateTheme($id,$sharetitle,$sharetext,$shareurl,$shareimg,$status){
        $sql = 'UPDATE `sharetheme` SET  `sharetitle`=:sharetitle,`sharetext`=:sharetext,`status`=:status,shareurl=:shareurl,shareimg=:shareimg WHERE id=:id'; 
        $data = array(
            ':id'          => $id,
            ':sharetitle'        => $sharetitle,
            ':sharetext'       => $sharetext,
            ':shareurl'  => $shareurl,
            ':shareimg'  => $shareimg,
            ':status'    => $status
        );
       return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
       
    }
}