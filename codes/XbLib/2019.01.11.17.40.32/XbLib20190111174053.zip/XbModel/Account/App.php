<?php
/**
 * @desc    app�������
 * @author  qien
 * @date    18.01.18
 */
class XbModel_Account_App extends XbModel_BaseModel {
    static $cache_tag = "Account_App_Config_";

    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    ����mac��ַ��ȡ������Ϣ
     * @param   string  $mac        mac��ַ
     * @param   string  $channel    ͨ��
     * @return  array   $return ����������Ϣ
     */
    public function getNewsConfigByMac($mac, $channel){
        $sql  = 'SELECT * FROM `common_mac_config` WHERE `mac`=:mac AND `channel`=:channel';
        $data = array(
            ':mac'     => $mac,
            ':channel' => $channel
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    ����mac��ַ
     * @param   string  $mac        mac��ַ
     * @param   string  $channel    ͨ��
     * @param   string  $is_clock   �Ƿ���
     * @return  boolen  $return
     */
    public function createConfig($mac, $channel, $is_clock){
        $time = time();
        $sql  = 'INSERT INTO `common_mac_config`(`mac`, `channel`, `is_clock`, `create_time`) VALUES(:mac, :channel, :is_clock, :create_time)';
        $data = array(
            ':mac'         => $mac,
            ':channel'     => $channel,
            ':is_clock'    => $is_clock,
            ':create_time' => $time
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    ����timeʱ�����ǰ��ȫ��Ϊ����״̬
     * @return  boolen  $return     ����ִ�н��
     */
    public function updateAllClockOpen($channel){
        $sql = 'UPDATE `common_mac_config` SET `is_clock`=:is_clock WHERE `is_clock`=0 AND `channel`=:channel';
        $data = array(
            ':is_clock' => 1,
            ':channel' => $channel,
        );
        $res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return false;
    }

    /**
     * @desc    ��ȡ������Ϣ
     * @param   string  $type       ��������
     * @return  array   $return     ����������Ϣ
     */
    public function getConfigByType($type){
        $sql = 'SELECT * FROM `common_config` WHERE `type`=:type ';
        $data = array(
            ':type' => $type
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    ��ȡ��������
     * @return  array   $return     ����������Ϣ
     */
    public function getAllConfig(){
        $sql = 'SELECT * FROM `common_config`';
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, array())->fetchAll();
    }

    /**
     * @desc    �޸�����
     * @param   string  $type   ��������
     * @param   string  $value  ֵ
     * @return  boolen  $return
     */
    public function updateConfig($type, $postInfo){
        $sql  = 'UPDATE `common_config` SET `value`=:value,`version`=:version WHERE `type`=:type';
        $data = array(
            ':value' => $postInfo['value'],
            ':version' => $postInfo['version'],
            ':type'  => $type
        );
        $res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /*
     * @desc 获取下载地址链接
     * @param       int     $group    分组
     * @return      array   $return   返回执行结果
     * */
    public function getConfigByUrl($group){
        $sql = 'SELECT * FROM `common_config` WHERE  `group`=:group';
        $data = array(
            ':group'=>$group
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
}