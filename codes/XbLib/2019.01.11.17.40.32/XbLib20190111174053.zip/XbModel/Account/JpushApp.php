<?php
/**
 * @desc
 * @author  qien
 * @date    17.12.25
 */
class XbModel_Account_JpushApp extends XbModel_BaseModel
{
    static $cache_tag = "Account_JpushApp_";
    function __construct()
    {
        parent::_init("xb_account");
    }
    //推送消息入库
    public function addJpush($uid,$title,$content,$type,$bid=''){
        $sql = 'INSERT INTO `jpush` (`uid`, `title`, `content`, `type`, `bid`, `time`) VALUES (:uid, :title, :content, :type, :bid, :time)';
        $data = array(
            ':uid'     => $uid,
            ':title'   => $title,
            ':content' => $content,
            ':type'    => $type,
            ':bid'     => $bid,
            ':time'    => time(),
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    //消息列表
    public function getMessageList($uid,$page=''){
        $sql = "select * from `jpush` where uid=:uid order by time desc limit :page,:perpage ";
        if($page == ''){
            $page = 1;
        }
        $data = array(
            ':uid'     => $uid,
            ':page'    => ($page-1)*10,
            ':perpage' => 10,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    统计未读消息
     * @param   int     $uid    用户id
     * @return  int     $return 返回未读数量
     */
    public function getNotReadNum($uid){
        $sql = "SELECT COUNT(*) AS num FROM `jpush` WHERE uid=:uid AND is_read=:is_read";
        $data = array(
            ':uid'     => $uid,
            ':is_read' => 0
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /**
     * @desc    更改消息为已读
     * @param   int     $uid    用户id
     * @return  int     $return 返回结果
     */
    public function updateIsRead($uid){
        $sql = "UPDATE `jpush` SET is_read=:is_read WHERE uid=:uid";
        $data = array(
            ':is_read' => 1,
            ':uid'     => $uid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
}