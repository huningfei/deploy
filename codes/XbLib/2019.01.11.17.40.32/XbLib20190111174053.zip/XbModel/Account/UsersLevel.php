<?php
/**
 * @desc 	用户等级
 * @author  yurong
 * @date    18.02.07
 */
class XbModel_Account_UsersLevel extends XbModel_BaseModel{
    public static $cache_tag = "Account_Users_Level_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc   为用户创建默认等级---员工
     * @param  int   $id   用户ID
     * @param  int   $level   用户等级
     * @return  array  $return  返回结果
     */
    public  function createUserLevel($id,$level){
        $time = time();
        if($id){
            $sql = "INSERT INTO `users_level` (`uid`,`level_id`,`create_time`) VALUES (:uid,:level_id,:create_time)";
            $data = array(
                ':uid' => $id,
                ':level_id' => $level,
                ':create_time' => $time
            );
            $res =  $this->dao->conn()->noCache()->preparedSql($sql, $data)->affectedCount();
            if(!$res){
                return false;
            }
            $this->dao->clearTag(self::$cache_tag);
            return $res;
        }
        return false;
    }

    /**
     * @desc    获取用户等级
     * @param   int    $uid     用户ID
     * @return  array  $return  返回结果
     */
    public function getUserLevelByUid($uid){
        $sql = "SELECT c.*, u.uid,u.agency_type FROM `users_level` as u LEFT JOIN `common_level` as c ON u.level_id = c.level where u.`uid` = :uid";
        $data = array(
            ':uid' =>$uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据用户id list 获取用户等级
     * @param   string  $uidList    用户id集合
     * @return  array   $return     返回相关用户等级
     */
    public function getUserLevelByUidList($uidList){
        $sql = "SELECT * FROM `users_level` where `uid` IN ({$uidList})";
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, array())->fetchAll();
    }

    /**
     * @desc    根据父类id，查询需要分润的相关等级uid
     * @param   string      $parent_list    父类id
     * @param   string      $user_level     刷卡人等级
     * @return  array       $return         返回搜索结果
     */
    public function getProfitUidByParentList($parent_list, $user_level){
        $sql = 'SELECT level_id,uid,agency_type FROM `users_level` WHERE uid in (SELECT uid FROM users_profile WHERE uid IN ('.$parent_list.') AND `status`=:status) AND level_id > :level ORDER BY uid DESC';
        $data = array(
            ':status' => 3,
            ':level'  => $user_level
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    用户自动升级(增加一级)并记录日志
     * @param   int     $uid    用户id
     * @return  boolen  $return 返回执行结果
     */
    public function updateUserLevel($uid, $oldLevel, $oldLevelName, $newLevel, $newLevelName, $type, $desc,$old_agency_type,$old_agency_name,$agency_type,$agency_name){
        $this->dao->conn(false)->beginTransaction();
        $sql = 'UPDATE `users_level` SET `level_id`=:newLevel ';
        $data = array(
            ':newLevel' => $newLevel,
            ':uid'      => $uid
        );
        if($agency_type){
            $sql .=" , `agency_type`=:agency_type ,`agency_update_time`=:agency_update_time";
            $data[':agency_type'] = $agency_type;
            $data[':agency_update_time'] = time();
        }
        $sql .=" WHERE `uid`=:uid";

        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        if($agency_type){
            $sql = "INSERT INTO `users_level_log` (`uid`,`old_level`,`old_name`,`change_level`,`change_name`,`type`,`desc`,`create_time`,`old_agency_type`,`old_agency_name`,`change_agency_type`,`change_agency_name`) VALUES (:uid,:old_level,:old_name,:change_level,:change_name,:type,:desc,:create_time,:old_agency_type,:old_agency_name,:chang_agency_type,:change_agency_name)";
            $data = array(
                ':uid'          => $uid,
                ':old_level'    => $oldLevel,
                ':old_name'     => $oldLevelName,
                ':change_level' => $newLevel,
                ':change_name'  => $newLevelName,
                ':type'         => $type,
                ':desc'         => $desc,
                ':create_time'  => time(),
                ':old_agency_type'=>$old_agency_type,
                ':old_agency_name'=>$old_agency_name,
                ':chang_agency_type'=>$agency_type,
                ':change_agency_name'=>$agency_name
            );
        }else{
            $sql = "INSERT INTO `users_level_log` (`uid`,`old_level`,`old_name`,`change_level`,`change_name`,`type`,`desc`,`create_time`) VALUES (:uid,:old_level,:old_name,:change_level,:change_name,:type,:desc,:create_time)";
            $data = array(
                ':uid'          => $uid,
                ':old_level'    => $oldLevel,
                ':old_name'     => $oldLevelName,
                ':change_level' => $newLevel,
                ':change_name'  => $newLevelName,
                ':type'         => $type,
                ':desc'         => $desc,
                ':create_time'  => time()
            );
        }
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Account_Users_Level_Log');
        }
        return $res;
    }

    public function updateUserLevels($uid, $oldLevel, $oldLevelName, $newLevel, $newLevelName, $type, $desc){
        $this->dao->conn(false)->beginTransaction();
        $sql = 'select * from users_level where uid ='.$uid;
        $data = array();
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $sql = 'UPDATE `users_level` SET `level_id`= '.$newLevel.' WHERE `uid`='.$uid;
            $data = array();
            $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
            if(!$res){
                $this->dao->rollback();
                return false;
            }
        }else{
            $time = time();
            $sql = 'insert into users_level(`uid`,`level_id`,`create_time`)VALUES('.$uid.','.$newLevel.','.$time.')';
            $data = array();
            $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
            if(!$res){
                $this->dao->rollback();
                return false;
            }
        }
        $sql = "INSERT INTO `users_level_log` (`uid`,`old_level`,`old_name`,`change_level`,`change_name`,`type`,`desc`,`create_time`) VALUES (:uid,:old_level,:old_name,:change_level,:change_name,:type,:desc,:create_time)";
        $data = array(
            ':uid'          => $uid,
            ':old_level'    => $oldLevel,
            ':old_name'     => $oldLevelName,
            ':change_level' => $newLevel,
            ':change_name'  => $newLevelName,
            ':type'         => $type,
            ':desc'         => $desc,
            ':create_time'  => time()
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 获取用户等级列表
     * @param       int        $start     偏移量
     * @param       int        $limit     条数
     * @param       string     $phone     手机号
     * @param       string     $name      姓名
     * @return      array      $return    返回执行结果
     */
    public function getLevels($start,$limit,$type,$phone,$name){
        $sql =" SELECT u.*,user.phone,p.realname FROM `users_level` u LEFT JOIN `users` user ON u.uid = user.id LEFT JOIN `users_profile` p ON u.uid=p.uid WHERE 1=1";
        $data = array(':start'=>$start,':limit'=>$limit);
        if($type){
            $sql .= " AND u.agency_type =:type";
            $data[':type'] = $type;
        }else{
            $sql .= " AND u.agency_type > 0";
        }
        if($phone){
            $sql .= " AND user.phone =:phone";
            $data[':phone'] = $phone;
        }
        if($name){
            $sql .= " AND p.realname = :name";
            $data[':name'] = $name;
        }
        $sql .="  ORDER BY u.id DESC LIMIT :start,:limit";
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 获取用户等级列表
     * @param       string     $phone     手机号
     * @param       string     $name      姓名
     * @return      array      $return    返回执行结果
     */
    public function getLevelsCount($type,$phone,$name){
        $sql =" SELECT count(*) as num FROM `users_level` u LEFT JOIN `users` user ON u.uid = user.id LEFT JOIN `users_profile` p ON u.uid=p.uid WHERE 1=1";
        $data = [];
        if($type){
            $sql .= " AND u.agency_type =:type";
            $data[':type'] = $type;
        }else{
            $sql .= " AND u.agency_type > 0";
        }
        if($phone){
            $sql .= " AND user.phone =:phone";
            $data[':phone'] = $phone;
        }
        if($name){
            $sql .= " AND p.realname = :name";
            $data[':name'] = $name;
        }
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc    根据父类id，查询需要分润的相关等级uid
     * @param   string      $parent_list    父类id
     * @param   string      $user_level     刷卡人等级
     * @return  array       $return         返回搜索结果
     */
    public function getProfitUidByParent($parent){
        $sql = 'SELECT level_id,uid,agency_type FROM `users_level` WHERE uid in (SELECT uid FROM users_profile WHERE uid = '.$parent.' AND `status`=:status)  ORDER BY uid DESC';
        $data = array(
            ':status' => 3
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
}