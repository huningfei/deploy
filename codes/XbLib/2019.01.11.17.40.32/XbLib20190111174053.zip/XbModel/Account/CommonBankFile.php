<?php
/**
 * @desc    上传信用卡
 * @author  yurong
 * @date    18.06.06
 */

class XbModel_Account_CommonBankFile extends XbModel_BaseModel
{
    static $cache_tag = "Account_Common_Bank_File_";
    public static $cache_expire = 259200;

    //链接库
    function __construct()
    {
        parent::_init("xb_account");
    }
    /**
     * @desc 获取上传信用卡列表
     * @param    int          $start     偏移量
     * @param    int          $limit     条数
     * @param    string       $title     表格名称
     * @param    string       $start_time开始时间
     * @param    string       $end_time  结束时间
     * @param    int          $status    状态
     * @return   array        $return    返回执行结果
     **/
    public function getBankFileList($start,$limit,$title,$start_time,$end_time,$status){
        $sql = " SELECT * FROM  `common_bank_file` WHERE 1=1";
        $data = [];
        if($title){
            $sql .=' AND   `title`=:title';
            $data[':title'] = trim($title);
        }
        if($status){
            $sql .=" AND   `status`in ($status)";
        }
        if($start_time){
            $sql .=' AND `create_time`>=:start_time';
            $data[':start_time'] = strtotime($start_time);
        }
        if($end_time){
            $sql .=' AND `create_time`<=:end_time';
            $data['end_time'] = strtotime($start_time.' 23:59:59');
        }
        $sql .=' ORDER BY id desc LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 获取上传信用卡列表条数
     * @param    string       $title     表格名称
     * @param    string       $start_time开始时间
     * @param    string       $end_time  结束时间
     * @param    int          $status    状态
     * @return   array        $return    返回执行结果
     **/
    public function getBankFileCount($title,$start_time,$end_time,$status){
        $sql = " SELECT count(*) as num FROM  `common_bank_file` WHERE 1=1";
        $data = [];
        if($title){
            $sql .=' AND   `title`=:title';
            $data[':title'] = trim($title);
        }
        if($status){
            $sql .=" AND   `status`in ($status)";
        }
        if($start_time){
            $sql .=' AND `create_time`>=:start_time';
            $data[':start_time'] = strtotime($start_time);
        }
        if($end_time){
            $sql .=' AND `create_time`<=:end_time';
            $data['end_time'] = strtotime($start_time.' 23:59:59');
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 上传文件
     * @param   string     $batch_number      批次号
     * @param   string     $title             上传表格名称
     * @param   int        $status            状态
     * @param   string     $url               上传路径
     * @param   string     $operator          操作人
     * @return  int        $return            返回执行结果
     * */
    public function add($batch_number,$title,$status,$url,$operator){
        $time = time();
        $sql = "INSERT INTO `common_bank_file` (batch_number,title,url,status,create_time,operator) VALUES (:batch_number,:title,:url,:status,:create_time,:operator)";
        $data = array(
            ':batch_number' => $batch_number,
            ':title' => $title,
            ':url' => $url,
            ':status' => $status,
            ':create_time' => $time,
            ':operator' => $operator,
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 获取单条上传信息
     * @param    int    $id    上传ID
     * @return   array  $return返回执行结果
     * */
    public function getBankFileById($id){
        $sql = " SELECT * FROM `common_bank_file` WHERE `id`=:id ";
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * 更改上传文件状态
     * @param   int       $id       ID
     * @param   int       $status   状态
     * @param   string    $reason   原因
     * @return  boolean   $return   返回执行结果
     * */
    public function updateStatus($id,$status,$reason,$number){
        $time = time();
        $sql = " SELECT * FROM `common_bank_file` WHERE `id`=:id AND `status`=:status";
        $data = array(
            ':id' => $id,
            ':status'=>0
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
        if(!$res) return false;
        $up_sql = "UPDATE `common_bank_file` set `status`=:status,`reason`=:reason,`update_time`=:update_time,`number`=:number WHERE `id`=:id";
        $up_data = array(
            ':status'=>$status,
            ':reason'=>$reason,
            ':update_time'=>$time,
            ':id' =>$id,
            ':number' =>$number
        );
        $up_res = $this->dao->conn(false)->noCache()->preparedSql($up_sql,$up_data)->affectedCount();
        if($up_res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $up_res;
    }
    /**
     * @desc 获取当天最新批次号
     */
    public function getBatchNumber(){
        $start_time = strtotime(date('Y-m-d',time()));
        $end_time =  strtotime(date('Y-m-d',time()).' 23:59:59');
        $sql = "select batch_number from `common_bank_file` where create_time >= :start_time and create_time <= :end_time order by id desc limit 1";
        $data = array(
            ':start_time'=>$start_time,
            ':end_time'=>$end_time
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();

    }
}