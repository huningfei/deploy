<?php
/**
 * @desc    邀请用户文件
 * @author  qien
 * @date    18.01.26
 */
class XbModel_Account_UsersInvite extends XbModel_BaseModel{
    public static $cache_tag    = "Account_Users_Invite_";
    public static $cache_expire = 86400;

    function __construct(){
        parent::_init("xb_account");
    }

    /**
     * @desc    根据uid获取信息
     * @param   int             $uid    用户id
     * @return  array|false     $return 返回用户邀请信息
     */
    public function getInviteInfoByUid($uid){
        $sql = 'SELECT * FROM `users_invite` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    统计用户直接邀请人数
     * @param   int     $uid        用户id
     * @param   boolen  $is_auth    是否查询审核用户
     * @return  int     $return     返回结果
     */
    public function countUserInviteDirect($uid, $is_auth=false){
        if(!$is_auth){
            $sql = 'SELECT COUNT(*) AS num FROM `users_invite` WHERE `parentid`=:parentid';
        }else{
            $sql = 'SELECT COUNT(*) AS num FROM `users_invite` u LEFT JOIN `users_profile` up ON up.uid=u.uid WHERE u.`parentid`=:parentid AND up.`status`=:status';
            $data[':status'] = 3;
        }
        $data[':parentid'] = $uid;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    创建用户邀请关系，使用事务创建，主信息表users_invite,以及父类id表users_invite_parentlist
     * @param   int         $uid            用户id
     * @param   int         $rootid         分支父类id
     * @param   int         $deep           分支深度
     * @param   string      $parent_list    父类id集合
     * @param   int         $parentid       父类id
     * @return  boolen      $return         返回执行结果
     */
    public function createInviteInfo($uid, $rootid, $deep, $parent_list, $parentid){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        if ($parent_list && $parent_list != '|') {
            $parentInfo = explode('|', trim($parent_list, '|'));
            $sql = 'INSERT INTO `users_invite_parentlist`(`uid`, `parentid`, `create_time`) VALUES';
            $data[':create_time'] = $time;
            $data[':uid'] = $uid;
            foreach ($parentInfo as $k => $v) {
                $sql .= '(:uid, :parentid' . $k . ', :create_time),';
                $data[':parentid' . $k] = $v;
            }
            $sql = trim($sql, ',');
            $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
            if (!$res) {
                $this->dao->rollback();
                return false;
            }
        }
        $sql = 'INSERT INTO `users_invite`(`uid`, `rootid`, `deep`, `parent_list`, `parentid`, `create_time`) VALUES(:uid, :rootid, :deep, :parent_list, :parentid, :create_time)';
        $data = array(
            ':uid' => $uid,
            ':rootid' => $rootid,
            ':deep' => $deep,
            ':parent_list' => $parent_list,
            ':parentid' => $parentid,
            ':create_time' => $time
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if (!$res) {
            $this->dao->rollback();
            return false;
        }
        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    获取用户所有的下线，包括直接和间接
     * @param   int     $uid        用户id
     * @return  array   $return     返回所有下级
     */
    public function getAllInviteByUid($uid, $rootid, $deep){
        $sql  = 'SELECT u.* FROM users_invite AS u LEFT JOIN users_invite_parentlist AS up ON up.uid=u.uid WHERE u.rootid=:rootid AND u.deep>:deep AND up.parentid=:parentid;';
        $data = array(
            ':rootid'   => $rootid,
            ':deep'     => $deep,
            ':parentid' => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    获取用户等级信息
     * @param   int     $uid        用户ID
     * @param   int     $rootid     最初邀请人id
     * @param   int     $deep       邀请人深度
     * @param   int     $level      需要获取的等级
     * @param   boolen  $count      是否是统计
     * @return  array   $info       返回等级信息
     */
    public function getUserInviteByLevel($uid, $rootid, $deep, $level, $count=false){
        if(!$count){
            $sql = 'SELECT *,u.parentid FROM users_invite AS u LEFT JOIN users_invite_parentlist AS up ON up.uid=u.uid LEFT JOIN users_level AS ul ON u.uid=ul.uid WHERE u.rootid=:rootid AND u.deep>:deep AND up.parentid=:parentid AND ul.level_id=:level_id ORDER BY ul.create_time DESC';
        }else{
            $sql = 'SELECT COUNT(*) FROM users_invite AS u LEFT JOIN users_invite_parentlist AS up ON up.uid=u.uid LEFT JOIN users_level AS ul ON u.uid=ul.uid WHERE u.rootid=:rootid AND u.deep>:deep AND up.parentid=:parentid AND ul.level_id=:level_id';
        }
        $data = array(
            ':rootid'   => $rootid,
            ':deep'     => $deep,
            ':parentid' => $uid,
            ':level_id' => $level
        );
        return $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
    //$this->dao->clearTag(self::$cache_tag);


    /**
     * @desc    针对老用户把 父级IDList 分解插入 users_invite_parentlist
     * @param   int     $uid            用户id
     * @param   int     $rootid         分支父类id
     * @param   int     $deep           分支深度
     * @param   string  $parent_list    父类id集合
     * @param   int     $parentid       父类id
     * @return  boolen  $return         返回执行结果
     */
    public function addUsersParentList($uid, $parent_list){
        $time = time();
        if($parent_list && $parent_list != '|'){
            $parentInfo = explode('|',trim($parent_list, '|'));
            $sql = 'INSERT INTO `users_invite_parentlist`(`uid`, `parentid`, `create_time`) VALUES';
            $data[':create_time'] = $time;
            $data[':uid']          = $uid;
            foreach($parentInfo as $k=>$v){
                $sql .= '(:uid, :parentid'.$k.', :create_time),';
                $data[':parentid'.$k] = $v;
            }
            $sql = trim($sql, ',');
            $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();

            if(!$res){
                return false;
            }
            $this->dao->clearTag(self::$cache_tag);
            return $res;
        }
        return false;
    }

    /**
     * @desc    获取用户邀请人ID
     * @param   int     $uid            用户id
     * @return  boolen  $return         返回执行结果
     */
    public function getUsersDirect($uid){
        if($uid){
            $sql = "SELECT uid FROM `users_invite` WHERE `parentid` = :parentid";
            $data = array(
              ':parentid' => $uid,
            );
            return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        }
        return false;
    }
    /**
     * @desc 获取用户邀请 被邀请人所得备用金
     */
    public function getProfitAmountByUid($uid,$fromuid){
        $sql = "SELECT * FROM users_invite_money WHERE uid=:uid AND fromuid=:fromuid";
        $data = array(
            ':uid' => $uid,
            ':fromuid' => $fromuid,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    public function addProfitAcmont($uid,$from_uid,$money){
        $in_sql = "INSERT INTO users_invite_money values (null,:fromuid,:uid,:money,:create_time)";
        $in_data = array(
            ':money'=>$money,
            ':fromuid'=>$from_uid,
            ':uid'=>$uid,
            ':create_time'=>time(),
        );
       $res = $this->dao->conn(false)->noCache()->preparedSql($in_sql,$in_data)->lastInsertId();
       if($res){
           $this->dao->clearTag(self::$cache_tag);
       }
       return $res;
    }
}