<?php
/**
 * @desc 	记录发送短信详情
 * @author  qien
 * @date    18.1.3
 */
class XbModel_Account_PhoneMessage extends XbModel_BaseModel {

    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    创建短信数据
     * @param   int     $phone      发送短信手机号
     * @param   int     $mch_id     商户id
     * @param   string  $type       短信类型：reg,login,updatepwd...
     * @param   int     $uid        用户id
     * @return  boolen  $return     返回执行结果
     */
    public function createMessage($phone, $mch_id, $type, $uid=0){
        $time = time();
        $sql = 'INSERT INTO `phone_message`(`phone`, `mch_id`, `type`, `uid`, `create_time`) VALUES(:phone, :mch_id, :type, :uid, :create_time)';
        $data = array(
            ':phone'       => $phone,
            ':mch_id'      => $mch_id,
            ':type'        => $type,
            ':uid'         => $uid,
            ':create_time' => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->lastInsertId();
    }
}