<?php
/**
 * @desc 	返现
 * @author  qien
 * @date    18.1.4
 */
class XbModel_Account_Profit extends XbModel_BaseModel{
    public static $cache_tag    = "Account_Users_Profit_";
    public static $cache_expire = 86400;
    public static $suffix;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    根据用户获取返现记录
     * @param   int     $uid    用户id
     * @param   int     $start  搜索开始
     * @param   int     $limit  搜索条数
     * @return  array   $return 返回搜索结果
     */
    public function getProfitByUid($uid, $start, $limit, $type=false, $startTime=false, $endTime=false){
        $sql = 'SELECT * FROM `profit_'.self::$suffix.'` WHERE uid=:uid';
        $data = array(
            ':uid'   => $uid,
            ':start' => $start,
            ':limit' => $limit
        );
        //判断类型
        if($type !== false){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        //判断开始时间
        if($startTime !== false){
            $sql .= ' AND `create_time` >= :startTime';
            $data[':startTime'] = $startTime;
        }
        //判断结束时间
        if($endTime !== false){
            $sql .= ' AND `create_time` <= :endTime';
            $data[':endTime'] = $endTime;
        }
        $sql .= ' ORDER BY created_at DESC LIMIT :start,:limit';
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据用户统计返现记录
     * @param   int     $uid    用户id
     * @return  array   $return 返回搜索结果
     */
    public function countProfitByUid($uid, $type=false, $startTime=false, $endTime=false){
        $sql = 'SELECT COUNT(*) as num FROM `profit_'.self::$suffix.'` WHERE uid=:uid';
        $data = array(
            ':uid'   => $uid,
        );
        //判断类型
        if($type !== false){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        //判断开始时间
        if($startTime !== false){
            $sql .= ' AND `create_time` >= :startTime';
            $data[':startTime'] = $startTime;
        }
        //判断结束时间
        if($endTime !== false){
            $sql .= ' AND `create_time` <= :endTime';
            $data[':endTime'] = $endTime;
        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res['num'];
    }

    /**
     * @desc    返现体现
     * @param   int     $uid        用户id
     * @param   int     $order_id   订单id
     * @param   int     $mch_code   用户mch_code
     * @return  array   $return 返回搜索结果
     */
    public function withdraws($uid, $order_id, $profit_amount, $realname, $bankCardNumber,$bank,$phone,$channel){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        $sql = 'INSERT INTO `profit_'.self::$suffix.'`(`uid`, `order_id`, `amount`, `surplus_amount`, `created_at`, `create_time`, `type`, `status`) VALUES(:uid, :order_id, :amount, :surplus_amount, :created_at, :create_time, :type, :status)';
        $data = array(
            ':uid'            => $uid,
            ':order_id'       => $order_id,
            ':amount'         => $profit_amount,
            ':surplus_amount' => 0,
            ':created_at'     => $time,
            ':create_time'    => $time,
            ':type'           => 2,
            ':status'         => 0
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        //修改账户余额
        $sql = 'UPDATE `users_wallet` SET `profit_amount` = `profit_amount` - :profit_amount, `profit_frozen` = `profit_frozen` + :profit_amount WHERE `uid`=:uid';
        $data = array(
            ':profit_amount' => $profit_amount,
            ':uid'           => $uid
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        /*$withdrawsData = array(
            'orderNo'    => $order_id,
            'amount'     => $profit_amount,
            'username'   => $realname,
            'bankCardNo' => $bankCardNumber
        );
        $withdrawsCashResult = XbLib_PingAnPay::getInstance()->setType(1)->buildMessage($withdrawsData)->request();
        if($withdrawsCashResult['headerStatus'] != ':交易受理成功'){
            $this->dao->rollback();
            $withdrawsData['result'] = $withdrawsCashResult;
            $log = json_encode($withdrawsData);
            XbFunc_Log::write('withdrawsError', '提现错误：'.$log);
            return false;
        }*/
        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            $sql = 'INSERT INTO `withdraw_cash`(`order_id`, `uid`, `refer_id`, `channel_name`, `channel_id`, `amount`, `single_fee`, `actual_amount`, `status`, `bankcardNumber`, `realname`, `type`, `create_time`,`bank`,`phone`,`channel`) VALUES(:order_id, :uid, :refer_id, :channel_name, :channel_id, :amount, :single_fee, :actual_amount, :status, :bankcardNumber, :realname, :type, :create_time,:bank,:phone,:channel)';
            $single_fee = 2;
            $data = array(
                ':order_id'       => $order_id,
                ':uid'            => $uid,
                ':refer_id'       => '',
                ':channel_name'   => '平安银行',
                ':channel_id'     => 1,
                ':amount'         => $profit_amount,
                ':single_fee'     => $single_fee,
                ':actual_amount'  => bcsub($profit_amount, $single_fee, 2),
                ':status'         => 0,
                ':bankcardNumber' => $bankCardNumber,
                ':realname'       => $realname,
                ':type'           => 1,
                ':create_time'    => $time,
                ':bank'           => $bank,
                ':phone'          => $phone,
                ':channel'        => $channel
            );
            $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        }
        return $res;
    }

    /**
     * @desc    当修改订单结果时，处理用户冻结余额
     * @param   int     $uid        用户id
     * @param   int     $status     订单状态
     * @param   float   $amount     金额
     * @return  bool    $return     返回执行状态
     */
    public function disposeProfitFrozen($uid, $status, $amount){
        if($status == 1){
            $sql = 'UPDATE `users_wallet` SET `profit_amount` = `profit_amount` + :amount, `profit_frozen` = `profit_frozen` - :amount WHERE `uid`=:uid';
        }else{
            $sql = 'UPDATE `users_wallet` SET `profit_frozen` = `profit_frozen` - :amount WHERE `uid`=:uid';
        }
        $data = array(
            ':uid'    => $uid,
            ':amount' => $amount
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    获取用户返现账户余额，没有则创建
     * @param   int     $uid        用户id
     * @return  array   $return     返回账户详情
     */
    public function getProfitAmountByUid($uid){
        $sql = 'SELECT * FROM `users_wallet` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        if(!$res){
            $this->createUserProfit($uid, '0.00');
            $res = array(
                'uid'           => $uid,
                'profit_amount' => '0.00',
                'profit_frozen' => '0.00',
                'money'         => '0.00',
                'create_time'   => time()
            );
        }
        return $res;
    }

    /**
     * @desc    修改用户返现账户余额，如果修改失败则创建用户账户
     * @param   int     $uid        用户id
     * @param   int     $amount     返现金额
     * @return  boolen  $return     执行结果
     */
    public function addUserProfitAmount($uid, $amount,$money,$from_uid){
        $sql = 'UPDATE `users_wallet` SET `profit_amount` = `profit_amount` + :amount ';
        $data = array(
            ':amount' => $amount,
            ':uid'    => $uid
        );
        if($money){
            $sql .= " , profit_petty_cash = profit_petty_cash - :money ";
            $data[':money'] = $money;
        }
        $sql .= " WHERE `uid`=:uid ";
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            //修改
            if($money) {
                $up_sql = "UPDATE users_invite_money set money = money -:money where fromuid=:fromuid and uid=:uid";
                $up_data = array(
                    ':fromuid' => $from_uid,
                    ':uid' => $uid,
                    ':money' => $money,
                );
                @$this->dao->conn(false)->noCache()->preparedSql($up_sql, $up_data)->affectedCount();
            }
            $this->dao->clearTag(self::$cache_tag);
        }else{
            $createRes = $this->createUserProfit($uid, $amount);
            if(!$createRes){
                XbFunc_Log::write('usersWalletError', '分润增加失败，uid：'.$uid, '金额：'.$amount.'邀请备用金'.$money);
            }
            $res = $createRes;
        }
        return $res;
    }

    /**
     * @desc    创建用户账户
     * @param   int     $uid        用户id
     * @param   float   $amount     账户余额
     * @param   float   $money      邀请备用金
     * @return  boolen  $return     返回创建结果
     */
    public function createUserProfit($uid, $amount,$money=0){
        $sql  = 'INSERT INTO `users_wallet`(`uid`, `profit_amount`, `create_time`, `profit_petty_cash`) VALUES(:uid, :profit_amount, :create_time,:profit_petty_cash)';
        $data = array(
            ':uid'           => $uid,
            ':profit_amount' => $amount,
            ':profit_petty_cash' => $money,
            ':create_time'   => time()
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    根据订单号，查询提现信息
     * @param   string      $orderId    提现订单id
     * @return  array       $return     返回结果
     */
    public function getWithdrawByOrderId($orderId){
        $sql = 'SELECT * FROM `withdraw_cash` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $orderId
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    提现订单回调-平安银行
     * @param   string      $orderId        订单id
     * @param   string      $referId        对应通道订单id
     * @param   string      $tranId         对应通道订单交易id
     * @param   int         $status         订单状态
     * @param   boolen|int  $withdrawStatus 提现状态，如果无值，则使用$status
     * @param   string      $desc           描述
     * @return  boolen      $return         返回执行结果
     */
    public function withdrawsCallBack($orderId, $referId, $tranId, $status, $withdrawStatus=false, $desc=''){
        $this->dao->conn(false)->beginTransaction();
        $sql = 'UPDATE `profit_'.self::$suffix.'` SET `status`=:status, `reference_no`=:reference_no WHERE `order_id`=:order_id';
        $data = array(
            ':status'       => $status,
            ':reference_no' => $referId,
            ':order_id'     => $orderId
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        $sql = 'UPDATE `withdraw_cash` SET `status`=:status, `transaction_id`=:tranId, `desc`=:desc WHERE `order_id`=:order_id';
        $data = array(
            ':status'   => $withdrawStatus ? $withdrawStatus : $status,
            ':tranId'   => $tranId,
            ':desc'     => $desc,
            ':order_id' => $orderId,
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        return $this->dao->commit();
    }

    /*
     * @desc  获取分润订单
     * @param   int      $mch_id          代理ID
     * @param   string   $users_phone     商户手机号
     * @param   string   $phone           分润来源手机号
     * @param   string   $reference_no    分润订单号
     * @param   string   $order_id        取现订单号
     * @param   string   $channel_id      通道ID  TODO 无效参数
     * @param   string   $start_time      开始时间
     * @param   string   $end_time        结束时间
     * @param   int      $start           偏移量
     * @param   int      $limit           条数
     * @param   int      $type            类型1：分润；2：提现
     * @param   string   $users_name      商户名称
     * @return  array    $return          返回执行结果
     * */
    public function  getProfit($type = '',$mch_id = '',$users_phone = '',$phone = '',$reference_no = '',$order_id = '',$channel_id = '',$start_time = '',$end_time = '',$users_name = '',$page = '',$perpage = ''){
        $time = strtotime(date('Y-m-d',time()));
        if($mch_id){
            $data = array(
                ':page' => ($page-1)*$perpage,
                ':perpage' => $perpage,
            );
            $sql ='SELECT p.uid, p.from_uid, p.order_id,p.amount,p.name,p.phone,p.rate,p.create_time,p.reference_no,p.type,p.status ';
            $sql .=' FROM profit_'.self::$suffix.' as p';
            $sql .=' WHERE 1=1';
            if(!empty($type)){
                $sql .=' and p.type ='.$type;
            }

            $in_uid = array();
            //商户手机号
            if(!empty($users_phone)){
                $user_id = $this->dao->noCache()->preparedSql("SELECT id FROM users WHERE phone = :phone", array(':phone' => $users_phone))
                    ->fetchAll();

                if (!$user_id)
                {
                    return array();
                }

                foreach ($user_id as $item)
                {
                    $in_uid[] = $item['id'];
                }
            }

            //商户名称
            if(!empty($users_name)){
                $user_id = $this->dao->noCache()->preparedSql("SELECT uid FROM users_profile WHERE realname = :realname", array(':realname' => $users_name))
                    ->fetchAll();
                if (!$user_id)
                {
                    return array();
                }

                foreach ($user_id as $item)
                {
                    $in_uid[] = $item['uid'];
                }
            }

            if ($in_uid)
            {
                $sql .= ' and p.uid in (' . implode(',', $in_uid) . ')';
            }

            //分润来源商户手机号
            if(!empty($phone)){
                $sql .=' AND p.phone = "'.$phone.'"';
            }
            //取现订单号
            if(!empty($order_id)){
                $sql .=' AND p.order_id = "'.$order_id.'"';
            }
            //分润订单号
            if(!empty($reference_no)){
                $sql .=' AND  p.reference_no = "'.$reference_no.'"';
            }

//            if(!empty($channel_id)){
//                if($channel_id == 'axf'){
//                    $sql .=' AND o.type = 2';
//                }else{
//                    $sql .=' AND o.type = 1 AND o.channel_id = '.$channel_id;
//                }
//            }
            if(!empty($start_time)){
                $start_time = strtotime($start_time);
                $sql .= ' AND  p.create_time>='.$start_time;
            }
            if(!empty($end_time)){
                if (strlen($end_time) == 10){
                    $end_time = strtotime($end_time.' 23:59:59');
                }else{
                    $end_time = strtotime($end_time);
                }
                $sql .= ' AND  p.create_time<='.$end_time;
            }
            if($page!=''&&$perpage!=''){
                $sql .=' order by p.create_time desc limit :page,:perpage ';
            }
            $str = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
            $order_ids = '';
            foreach($str as &$v){
                if($v['order_id'] != 0){
                    $order_ids.= "'".$v['order_id']."',";
                }
            }

            //获取用户身份信息、等级信息、用户基本信息
            //u.phone as users_phone, pro.realname, level.level_id
            foreach ($str as &$it)
            {
                $it['user_phone'] = '';
                $it['realname'] = '';
                $it['level_id'] = '';
            }

            if(!empty($order_ids)){
                $order_ids = trim($order_ids,',');
                $sql = 'select order_id,rate as s_rate,channel_name,channel_id,amount as order_amount from order_'.self::$suffix .' where order_id in('.$order_ids.')';
                $data = array();
                $str2 = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
                $oArray = array();
                foreach($str2 as $k=>$pvel){
                    $oArray[$pvel['order_id']] = $pvel;
                }
                foreach($str as &$dv){
                    if(!empty($oArray[$dv['order_id']])){
                        $dv['s_rate'] = $oArray[$dv['order_id']]['s_rate'];
                        $dv['channel_name'] = $oArray[$dv['order_id']]['channel_name'];
                        $dv['channel_id'] = $oArray[$dv['order_id']]['channel_id'];
                        $dv['order_amount'] = $oArray[$dv['order_id']]['order_amount'];
                    }
                }
            }
            return $str;
        }
        return false;
    }

    /**
     * @desc    获取分润订单条数
     * @param   int      $mch_id          代理ID
     * @param   string   $users_phone     商户手机号
     * @param   string   $phone           分润来源手机号
     * @param   string   $reference_no    分润订单号
     * @param   string   $order_id        取现订单号
     * @param   string   $channel_id      通道ID
     * @param   string   $start_time      开始时间
     * @param   string   $end_time        结束时间
     * @param   int      $type            订单类型(1:分润，2：提现）
     * @param   string   $users_name      商户名称
     * @return  array    $return          返回实名信息
     */
    public function getProfitCount($mch_id,$users_phone,$phone,$reference_no,$order_id,$channel_id,$start_time,$end_time,$type,$users_name){
        if($mch_id){
            $sql = "SELECT count(*) as num FROM profit_".$mch_id." as p ";
            $sql .=' LEFT JOIN order_'.$mch_id.' as o ON o.id = p.order_id';
            $sql .=' WHERE 1=1 ';
            $data = array();

            $in_uid = array();
            //商户手机号
            if(!empty($users_phone)){
                $user_id = $this->dao->noCache()->preparedSql("SELECT id FROM users WHERE phone = :phone", array(':phone' => $users_phone))
                ->fetchAll();

                if (!$user_id)
                {
                    return 0;
                }

                foreach ($user_id as $item)
                {
                    $in_uid[] = $item['id'];
                }
            }

            //商户名称
            if(!empty($users_name)){
                $user_id = $this->dao->noCache()->preparedSql("SELECT uid FROM users_profile WHERE realname = :realname", array(':realname' => $users_name))
                ->fetchAll();

                if (!$user_id)
                {
                    return 0;
                }

                foreach ($user_id as $item)
                {
                    $in_uid[] = $item['uid'];
                }
            }

            if ($in_uid)
            {
                $sql .= ' and p.uid in (' . implode(',', $in_uid) . ')';
            }

            //分润来源商户手机号
            if(!empty($phone)){
                $sql .=' AND p.phone = :phone';
                $data[':phone'] = $phone;
            }
            //取现订单号
            if(!empty($order_id)){
                $sql .=' AND p.order_id = :order_id';
                $data[':order_id'] = $order_id;
            }
            //分润订单号
            if(!empty($reference_no)){
                $sql .=' AND p.reference_no = :reference_no';
                $data[':reference_no'] = $reference_no;
            }

            if(!empty($channel_id)){
                $sql .=' AND o.type = :channel_id';
                $data[':channel_id'] = $channel_id;
            }
            if(!empty($start_time)){
                $sql .= ' AND  p.create_time>=:starttime';
                $data[':starttime'] = strtotime($start_time);
            }
            if(!empty($end_time)){
                $sql .= ' AND  p.create_time<=:endtime';
                $data[':endtime'] = strtotime($end_time.' 23:59:59');
            }
            if(!empty($type)) {
                $sql .= ' AND p.type = :type';
                $data[':type'] = $type;
            }
            $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
            return $res['num'];
        }else{
            return false;
        }
    }

    /**
     * 获取取现定单条数
     *
     * @param string $is_order 代理id
     * @param string $channel 支付通道
     * @param string $status 支付状态
     * @param string $order 取现订单号
     * @param string $phone 商户手机号
     * @param string $m_id 查询人商户id
     * @param string $merchant_id 商户id
     * @param string $role_name 角色名
     * @param string $start_time
     * @param string $end_time
     * @return number
     */

    //获取取现订单列表
    public function getTakeMoney($is_order = '',$channel = '',$status = '',$order = '',$phone = '',$realname='',$m_id = '',$merchant_id = '',$role_name = '',$start_time = '',$end_time = '',$client_channel='',$page = '',$perpage = ''){
        $sql_order_table = ("SELECT table_name FROM information_schema.TABLES WHERE table_name = 'order_".$is_order."'");
        $table_isexist = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_order_table,array())->fetchAll();
        if (empty($table_isexist)) {
            if($page!='' && $perpage!=''){
                return array();
            } else {
                return 0;
            }
        }
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        if(!empty($end_time)){
            $end_time = $end_time + 86400;
        }
        if($realname !=''){
            $filed = 'uid,realname,bankcardNumber';
            $where = "`realname` = '".$realname."'";
            $res = $this->queryData('users_profile',$filed,$where,'uid',self::$cache_tag,1);
            $profileArray = $res['res'];
            $profileStr = $res['str'];
        }
        //order_id 订单号,creditbank银行名称，amount刷卡金额，create_time创建时间
        //getamount 获取金额 $orderInfo['status'] == 1 ? ($orderInfo['amount'] - $orderInfo['fee']) : 0;
        //fee 手续费,channel_name支付通道名称，status 订单状态，pay_time支付时间,rate_cost有积分费率成本，without_rate_cost无积分费率成本，service_cost手续费成本
//        $sql = 'select a.id,a.order_id,a.creditbank,a.amount,a.create_time,a.fee,a.channel_name,a.channel_id,a.status,a.pay_time,a.rate,a.type,b.mch_id,b.phone,c.realname,d.timelines,d.rate_cost,d.without_rate_cost,d.service_cost from order_'.$is_order.' a
//left join users b on a.uid = b.id left join users_profile c on a.uid = c.uid left join common_channel d on a.channel_id = d.channel_id where 1=1';
        $sql_rows = 'select a.id,a.uid,a.order_id,a.creditbank,a.amount,a.create_time,a.fee,a.channel_name,a.channel_id,a.status,a.pay_time,a.rate,a.type,a.actual_amount,a.single_fee,a.creditcard,b.mch_id,b.phone,a.client_channel from order_'.$is_order.' a
left join users b on a.uid = b.id where 1=1';
        $sql_count = 'select count(*) as num from order_'.$is_order.' a left join users b on a.uid = b.id where 1=1';
        $sql = '';
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and b.`mch_id` = '.$m_id;
        }
        if($merchant_id !=''){
            $sql .=' and b.`mch_id` = '.$merchant_id;
        }
        if($channel !=''){
            if($channel == 'axf'){
                $sql .=' and a.`type` = 2';
            }else{
                $sql_channel = 'select id from common_channel_level where type = 1 and channel_id = ' . $channel;
                $channel_arr = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_channel,array())->fetchAll();
                if (!empty($channel_arr)) {
                    $channel_ids = array_column($channel_arr, 'id');
                    $channel_ids = join(',', $channel_ids);
                } else {
                    $channel_ids = 'null';
                }
                $sql .=' and a.`type` = 1 and a.`channel_id` in ('. $channel_ids .')';
            }
        }
        if($order !=''){
            $sql .=' and a.`order_id` = "'.$order.'"';
        }
        if($realname !=''){
            if (!empty($profileStr)) {
                $sql .=' and a.`uid` in ('.implode(',',$profileStr).')';
            } else {
                $sql .=' and a.`uid` in (null)';
            }
        }
        if($phone !=''){
            $sql .=' and b.`phone` = "'.$phone.'"';
        }
        if($start_time !=''){
            $sql .=' and a.`create_time` >= '.$start_time;
        }
        if($end_time !=''){
            $sql .=' and a.`create_time` < '.$end_time;
        }
        if($status !=''){
            if($status == 4){
                $sql .=' and a.`status` = 0';
            }else{
                $sql .=' and a.`status` = '.$status;
            }
        }
        if ($client_channel) {
            $sql .= ' and a.`client_channel` = :client_channel';
            $data[':client_channel'] = $client_channel;
        }
        if($page!='' && $perpage!=''){
            $sql .=' order by a.id desc limit :page,:perpage ';
        } else {
            unset($data[':page']);
            unset($data[':perpage']);
            $count = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_count.$sql,$data)->fetchOne();
            return empty($count['num']) ? 0 : $count['num'];
        }
        $str = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql_rows.$sql,$data)->fetchAll();

        $mid = '';
        $uid = '';
        $channel_ids = '';
        foreach($str as &$v){
            if($v['mch_id'] != 0){
                $mid.= $v['mch_id'].',';
            }
            if($v['uid'] != 0){
                $uid.= $v['uid'].',';
            }
            if($v['channel_id'] != 0){
                $channel_ids.= $v['channel_id'].',';
            }
        }
        if(!empty($channel_ids)){
            $channel_ids = trim($channel_ids,',');
            $sql = 'select d.timelines,d.rate_cost,d.without_rate_cost,d.service_cost,d.channel_id as dch from common_channel d where channel_id in('.$channel_ids.')';
            $str2 = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
            $dArray = array();
            foreach($str2 as $k=>$pvel){
                $dArray[$pvel['channel_id']] = $pvel;
            }
            foreach($str as &$dv){
                if(!empty($dArray[$dv['channel_id']])){
                    $dv['timelines'] = $dArray[$dv['channel_id']]['timelines'];
                   /* $dv['timelines'] = $dArray[$dv['channel_id']]['timelines'];
                    $dv['timelines'] = $dArray[$dv['channel_id']]['timelines'];
                    $dv['timelines'] = $dArray[$dv['channel_id']]['timelines'];*/
                }
            }
        }
        if(!empty($uid)){
            if($realname == ''){
                $uid = trim($uid,',');
                $sql = 'select uid,realname,bankcardNumber from users_profile where uid in('.$uid.')';
                $str1 = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
                $profileArray = array();
                foreach($str1 as $k=>$pvel){
                    $profileArray[$pvel['uid']] = $pvel;
                }
            }
            foreach($str as &$pv){
                if(!empty($profileArray[$pv['uid']])){
                    $pv['realname'] = $profileArray[$pv['uid']]['realname'];
                    $pv['bankcardNumber'] = $profileArray[$pv['uid']]['bankcardNumber'];
                }
            }
        }
        //查询代理名称
        if(!empty($mid)){
            $mid = trim($mid,',');
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
            foreach($str as &$mv){
                $mv['m_name'] = 0;
                if(!empty($modifyArray[$mv['mch_id']])){
                    $mv['m_name'] = $modifyArray[$mv['mch_id']]['name'];
                }
            }
        }
        return $str;
    }

    public function getChannel(){
        $sql = 'select * from common_channel';
        $data = array();
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc    获取批量提现批次信息
     * @param   int     $limit      偏移量
     * @param   int     $num        搜索条数
     * @return  array   $return     搜索的数据
     */
    public function getWithdrawBatch($limit, $num, $orderId=false, $status=false){
        $sql = 'SELECT * FROM `withdraw_batch` WHERE 1=1';
        $data = array(
            ':limit' => $limit,
            ':num'   => $num
        );
        if($orderId !== false){
            $sql .= ' AND `showBatchNo`=:batch';
            $data[':batch'] = $orderId;
        }
        if($status !== false){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        $sql .= ' ORDER BY `id` DESC LIMIT :limit, :num';

        return $this->dao->conn()->noCache(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    获取批量提现批次信息数量
     * @return  int     $return     搜索的数据
     */
    public function countWithdrawBatch($orderId=false, $status=false, $time=false){
        $sql = 'SELECT COUNT(*) AS num FROM `withdraw_batch` WHERE 1=1';
        $data = array();
        if($orderId !== false){
            $sql .= ' AND `showBatchNo`=:batch';
            $data[':batch'] = $orderId;
        }
        if($status !== false){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        if($time !== false){
            $sql .= ' AND `create_time`>=:time';
            $data[':time'] = $time;
        }
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据order_id获取返利详情
     * @param   int     $orderId        订单id
     * @return  array   $return         返回返利详情
     */
    public function getProfitByOrderId($orderId){
        $sql = 'SELECT * FROM `profit_'.self::$suffix.'` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $orderId
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    统计提现笔数
     */
    public function countWithdrawCash($status, $time){
        $sql = 'SELECT COUNT(*) AS num FROM `withdraw_cash` WHERE `status`=:status AND `create_time`<=:time';
        $data = array(
            ':status' => $status,
            ':time'   => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    public function createWithdrawBatch($orderId, $countAmount, $num, $channel, $lastWithdrawBatchId, $time,$show_orderId){
        $this->dao->conn(false)->beginTransaction();
        //$orderId = XbModule_Account_OrderCode::getInstance()->getOrderCode().'0';
        $sql  = 'INSERT INTO `withdraw_batch`(`batchNo`, `amount`, `countNum`, `status`, `channel`, `create_time`,`showBatchNo`) VALUES(:batchNo, :amount, :countNum, :status, :channel, :create_time,:showBatchNo)';
        $data = array(
            ':batchNo'     => $orderId,
            ':amount'      => $countAmount,
            ':countNum'    => $num,
            ':status'      => 1,
            ':channel'     => $channel,
            ':create_time' => time(),
            ':showBatchNo' => $show_orderId
        );
        $batch_id = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$batch_id){
            $this->dao->rollback();
            return false;
        }
        $sql = 'UPDATE `withdraw_cash` SET `status`=:status, `batch_id`=:batch_id WHERE id<=:id AND `status`=:up_status AND `create_time`<=:time';
        $data = array(
            ':status'    => 3,
            ':batch_id'  => $batch_id,
            ':id'        => $lastWithdrawBatchId,
            ':up_status' => 0,
            ':time'      => $time
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res ? $batch_id : false;
    }

    /**
     * @desc    统计批次总金额
     */
    public function countWithdrawBatchAmout($limit, $num, $status, $time){
        $sql = "SELECT SUM(amount) AS amount FROM (SELECT * FROM `withdraw_cash` WHERE `status`=:status AND `create_time` <=:time LIMIT {$limit}, {$num}) AS amount";
        $data = array(
            ':status' => $status,
            ':time'   => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    统计生成批次中最后一个提现id
     */
    public function getLastWithdrawBatchId($limit, $time){
        $sql = 'SELECT * FROM `withdraw_cash` WHERE `status`=:status AND `create_time`<=:time LIMIT :limit, :num';
        $data = array(
            ':status' => 0,
            ':limit'  => $limit,
            ':num'    => 1,
            ':time'   => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc    统计生成批次中最后一个提现id
     */
    public function getLastWithdrawBatchInfo($limit,$time){
        $sql = 'SELECT * FROM `withdraw_cash` WHERE `status`=:status AND `create_time`<=:time LIMIT :limit, :num';
        $data = array(
            ':status' => 0,
            ':limit'  => $limit,
            ':num'    => 1,
            ':time'   => $time
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc    拒绝订单，修改批次信息
     */
    public function refuseWithdrawCash($batchId, $refuseNum, $refuseAmount){
        $sql = 'UPDATE `withdraw_batch` SET `refuseAmount`=`refuseAmount` + :refuseAmount, `refuseNum`=`refuseNum` + :refuseNum WHERE `id`=:id';
        $data = array(
            ':refuseAmount' => $refuseAmount,
            ':refuseNum'    => $refuseNum,
            ':id'           => $batchId
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    批量提现记录日志
     * @param   int     $bid        批次id
     * @param   int     $auid       管理员id
     * @param   string  $username   管理员姓名
     * @param   string  $log        日志内容
     * @param   string  $desc       具体操作
     * @return  boolen  $return     返回数据
     */
    public function createWithdrawBatchLog($bid, $auid, $username, $log, $desc=''){
        $sql = 'INSERT INTO `withdraw_batch_log`(`bid`, `auid`, `username`, `log`, `desc`, `create_time`) VALUES(:bid, :auid, :username, :log, :desc, :create_time)';
        $data = array(
            ':bid'         => $bid,
            ':auid'        => $auid,
            ':username'    => $username,
            ':log'         => $log,
            ':desc'        => $desc,
            ':create_time' => time()
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
    }

    /**
     * @desc    获取提现批次详情
     */
    public function getWithdrawBatchById($bid){
        $sql = 'SELECT * FROM `withdraw_batch` WHERE `id`=:id';
        $data = array(
            ':id' => $bid,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /*
     * @desc    修改批次订单
     * @param   int     $bid    修改批次相关订单状态
     * @param   int     $status 修改批次状态
     * @return  bool    $return 返回修改结果
     */
    public function updateWithdrawBatchOrderStatus($bid, $status, $whereStatus){
        $sql = 'UPDATE `withdraw_cash` SET `status`=:status WHERE `status`=:whereStatus AND `batch_id`=:batch_id';
        $data = array(
            ':status'      => $status,
            ':batch_id'    => $bid,
            ':whereStatus' => $whereStatus
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @param   根据批次id 获取订单信息
     */
    public function getWithdrawCachByBatchId($batchId, $status, $limit=false, $num=false){
        $sql = 'SELECT * FROM `withdraw_cash` WHERE `batch_id`=:batch_id AND `status`=:status';
        $data = array(
            ':batch_id' => $batchId,
            ':status'   => $status
        );
        if($limit !== false){
            $sql .= ' LIMIT :limit, :num';
            $data = array(
                ':limit' => $limit,
                ':num'   => $num
            );
        }
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据批次id 统计订单数量
     * @param   int         $batchId        批次id
     * @param   int         $status         订单状态
     * @return  array       $return         返回数量
     */
    public function countWithdrawCachByBatchId($batchId, $status){
        $sql = 'SELECT COUNT(*) as num FROM `withdraw_cash` WHERE `batch_id`=:batch_id AND `status`=:status';
        $data = array(
            ':batch_id' => $batchId,
            ':status' => $status,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据批次id 获取订单信息
     * @param   int         $batchNo        批次号
     * @return  array       $return         返回数量
     */
    public function getWithdrawBatchByBatchNo($batchNo){
        $sql = 'SELECT * FROM `withdraw_batch` WHERE `batchNo`=:batchNo';
        $data = array(
            ':batchNo' => $batchNo
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    修改批次状态
     * @param   int     $batchNo    批次号
     * @param   int     $status     状态
     * @return  bool    $return     返回执行情况
     */
    public function updateWithdrawBatchStatus($batchNo, $status){
        $sql = 'UPDATE `withdraw_batch` SET `status`=:status WHERE `batchNo`=:batchNo';
        $data = array(
            ':status'  => $status,
            ':batchNo' => $batchNo
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    根据批次id获取日志
     */
    public function getWithdrawCashLog($batchId){
        $sql = 'SELECT * FROM `withdraw_batch_log` WHERE `bid`=:bid';
        $data = array(
            ':bid' => $batchId
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc   根据批次id 获取订单信息
     */
    public function getWithdrawCashByBatchNo($batchNo){
        $sql = 'SELECT order_id,u.phone,uid,w.type,w.create_time,w.amount,w.single_fee,w.actual_amount,w.actual_amount,w.status,w.realname,w.bank,w.bankcardNumber,w.channel,w.desc,u.mch_id,w.refer_id,w.pay_time,w.batch_id,b.send_time FROM `withdraw_cash` w LEFT JOIN `users` u ON w.uid = u.id LEFT JOIN `withdraw_batch` b ON b.id = w.batch_id  WHERE b.batchNo=:batchNo ';
        $data = array(
            ':batchNo' => $batchNo,
        );

        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc   根据批次id 获取订单信息
     */
    public function getWithdrawCashsByBatchId($batchId){
        $sql = 'SELECT order_id,u.phone,uid,w.type,w.create_time,w.amount,w.single_fee,w.actual_amount,w.actual_amount,w.status,w.realname,w.bank,w.bankcardNumber,w.channel,w.desc,u.mch_id,w.refer_id,w.pay_time,w.batch_id,b.send_time FROM `withdraw_cash` w LEFT JOIN `users` u ON w.uid = u.id LEFT JOIN `withdraw_batch` b ON b.id = w.batch_id  WHERE `batch_id`=:batch_id ';
        $data = array(
            ':batch_id' => $batchId,
        );

        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc   根据批次id 获取订单信息
     */
    public function getWithdrawCash($batchId, $status, $limit, $num,$name,$phone,$uid,$start_time,$end_time,$mch_id,$order_id){
        $sql = 'SELECT w.*,b.batchNo,b.send_time FROM `withdraw_cash` w LEFT JOIN `withdraw_batch` b ON w.batch_id = b.id LEFT JOIN `users` u ON u.id = w.uid WHERE 1=1 ';
        $data = [];
        if($name){
            $sql .=' AND w.realname = :realname';
            $data[':realname'] = $name;
        }
        if($status){
            $sql .=' AND w.status = :status';
            $data[':status'] = $status;
        }
        if($batchId){
            $sql .=' AND b.showBatchNo =:batchNo';
            $data[':batchNo'] = $batchId;
        }
        if($phone){
            $sql .=' AND w.phone=:phone';
            $data[':phone'] = $phone;
        }
        if($uid){
            $sql .=' AND w.uid =:uid';
            $data[':uid'] = $uid;
        }
        if($order_id){
            $sql .=' AND w.order_id =:order_id';
            $data[':order_id'] = $order_id;
        }
        if($mch_id){
            $sql .=' AND u.mch_id =:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if($start_time){
            $sql .=' AND w.create_time >= :start_time';
            $data[':start_time'] = strtotime($start_time);

        }
        if($end_time){
            $sql .=' AND w.create_time <= :end_time';
            $data[':end_time'] = strtotime($end_time);

        }

        $sql .= ' LIMIT :limit, :num';
        $data[':limit'] = $limit;
        $data[':num'] = $num;
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc   根据批次id 获取订单信息
     */
    public function getWithdrawCashCount($batchId, $status,$name,$phone,$uid,$start_time,$end_time,$mch_id,$order_id){
        $sql = 'SELECT count(*) as num FROM `withdraw_cash` w LEFT JOIN `withdraw_batch` b ON w.batch_id = b.id LEFT JOIN `users` u ON u.id = w.uid WHERE 1=1 ';
        $data = [];
        if($name){
            $sql .=' AND w.`realname` = :realname';
            $data[':realname'] = $name;
        }
        if($status){
            $sql .=' AND w.`status` = :status';
            $data[':status'] = $status;
        }
        if($batchId){
            $sql .=' AND b.showBatchNo=:batchNo';
            $data[':batchNo'] = $batchId;
        }
        if($phone){
            $sql .=' AND w.`phone`=:phone';
            $data[':phone'] = $phone;
        }
        if($uid){
            $sql .=' AND w.uid =:uid';
            $data[':uid'] = $uid;
        }
        if($order_id){
            $sql .=' AND w.`order_id`=:order_id';
            $data[':order_id'] = $order_id;
        }
        if($mch_id){
            $sql .=' AND u.mch_id =:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if($start_time){
            $sql .=' AND w.`create_time` >= :start_time';
            $data[':start_time'] = strtotime($start_time);

        }
        if($end_time){
            $sql .=' AND w.`create_time` >= :end_time';
            $data[':end_time'] = strtotime($end_time);

        }
        $res = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $res ? $res['num'] : 0;
    }
    /**
     * @desc    修改批次状态
     * @param   int     $batchNo    批次号
     * @param   int     $send_time  时间
     * @return  bool    $return     返回执行情况
     */
    public function updateWithdrawBatchTime($batchNo, $send_time){
        $sql = 'UPDATE `withdraw_batch` SET `send_time`=:send_time WHERE `batchNo`=:batchNo';
        $data = array(
            ':send_time'  => $send_time,
            ':batchNo' => $batchNo
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 此方法仅用作后台批量修改提现数据
     */
    public function updateBatch($data,$batchNo){
        $time = time();
        $order_ids = '';
        //查询是否有此批次号信息
        $batch_sql = 'SELECT * FROM `withdraw_batch` WHERE `batchNo` = :batchNo';
        $batch_data = [':batchNo'=>$batchNo];
        $batch_res = $this->dao->conn()->conn()->noCache()->preparedSql($batch_sql,$batch_data)->fetchOne();
        if(!$batch_res){
            return false;
        }
        //先查询是否有当前订单信息
        foreach($data['detail'] as $key => $val){
            $order_ids .= "'".$val['Order_id']."',";
        }
        $order_ids = trim($order_ids,',');
        $order_sql = ' SELECT order_id FROM `withdraw_cash` WHERE order_id in ('.$order_ids.')';
        $order_res = $this->dao->conn()->noCache()->preparedSql($order_sql,[])->fetchAll();
        if($order_res){
            $this->dao->conn(false)->beginTransaction();
            $up_cash_sql = "UPDATE `withdraw_cash` SET `status`= :status ,`actual_amount`=:actual_amount,`pay_time`=:pay_time,`desc`=:desc WHERE `order_id`=:order_id";
            foreach($data['detail'] as $key => $val){
                foreach($order_res as $kk => $vv){
                    if($val['Order_id'] == $vv['order_id']){
                        $status = $val['ReturnCode']=='0000'?'2':'1';
                        $up_cash_data = array(
                            ':status'=>$status,
                            ':actual_amount'=>$val['TranAmount'],
                            ':pay_time'=>$time,
                            ':desc' => $val['ReturnMessage'],
                            ':order_id'=>$val['Order_id']
                        );
                        $up_cash_res = $this->dao->noCache()->preparedSql($up_cash_sql,$up_cash_data)->affectedCount();
                        if(!$up_cash_res){
                            $this->dao->rollback();
                            return false;
                        }
                    }
                }
            }
            //更改batch
            $up_batch_sql = "UPDATE `withdraw_batch` SET `amount`=:amount,`countNum`=:countNum,`refuseAmount`=:refuseAmount,`refuseNum`=:refuseNum,`successNum`=:successNum,`successAmount`=:successAmount,`failNum`=:failNum,`failAmount`=:failAmount,`status`=:status WHERE `id` =:id";
            $up_batch_data = array(
                ':amount'       => $data['TotalAmount'],
                ':countNum'     =>$data['TotalNum'],
                ':refuseAmount' =>$data['AbnormalAmount'],
                ':refuseNum'    =>$data['AbnormalNum'],
                ':successNum'   =>$data['SuccessNum'],
                ':successAmount'=>$data['SuccessAmount'],
                ':failNum'      =>$data['FailureNum'],
                ':failAmount'=>$data['FailureAmount'],
                ':id'           =>$batch_res['id'],
                ':status'       =>$data['SuccessNum'] > 0?6:7,
            );
            $up_batch_res = $this->dao->noCache()->preparedSql($up_batch_sql,$up_batch_data)->affectedCount();
            if(!$up_batch_res){
                $this->dao->rollback();
                return false;
            }
            $res = $this->dao->commit();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        }else{
            return false;
        }

    }
    /**
     * @desc 获取提现中所有数据
     */
    public function getAllProfit($uid){
        $sql = " SELECT * FROM `profit_".self::$suffix."` where uid=:uid order by id";
        $data[':uid'] = $uid;
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 更改cash标准银行卡名称
     * @param  int      $id      cash自增ID
     * @param  string   $bank    银行卡名称
     * @reutrn boolean  $return  返回执行结果
     */
    public function changeBank($id,$bank){
        $sql = "UPDATE `withdraw_cash` set bank = :bank WHERE id=:id";
        $data[':bank'] = $bank;
        $data[':id'] = $id;
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 修改变动后余额
     * @param          int     $id       自增ID
     * @param          int     $amount   变更后余额
     * @return         boolean $return   返回执行结果
     */
    public function changeSurplusAmount($id,$amount){
        $sql = "UPDATE `profit_".self::$suffix."` set surplus_amount = :surplus_amount WHERE id = :id";
        $data = array(
            ':surplus_amount' => $amount,
            ':id'             => $id
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql,$data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc    获取提现批次详情
     */
    public function getLastWithdrawBatchByShowBatchNo($showBatchNo){
        $sql = "SELECT * FROM `withdraw_batch` WHERE `showBatchNo` like :showBatchNo ORDER BY id desc LIMIT 1";
        $data = array(
            ':showBatchNo' => $showBatchNo.'%',
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc   根据批次id 获取订单信息
     */
    public function getWithdrawCashByShowBatchNo($showBatchNo){
        $sql = 'SELECT order_id,u.phone,uid,w.type,w.create_time,w.amount,w.single_fee,w.actual_amount,w.actual_amount,w.status,w.realname,w.bank,w.bankcardNumber,w.channel,w.desc,u.mch_id,w.refer_id,w.pay_time,w.batch_id,b.send_time FROM `withdraw_cash` w LEFT JOIN `users` u ON w.uid = u.id LEFT JOIN `withdraw_batch` b ON b.id = w.batch_id  WHERE b.showBatchNo=:showBatchNo ';
        $data = array(
            ':showBatchNo' => $showBatchNo,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * 修改用户备用金
     */
    public function updateUserMoney($from_uid,$profit_petty_cash,$uid){
        $sql= "SELECT * FROM users_wallet WHERE uid =:uid";
        $data = array(
            ':uid'=>$from_uid
        );
        $res = $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchOne();
        if($res){
            $up_sql = "UPDATE users_wallet set profit_petty_cash = profit_petty_cash + :money WHERE uid=:uid";
            $up_data = array(
                ':money'=>$profit_petty_cash,
                ':uid'=>$from_uid
            );
            $result = $this->dao->conn(false)->noCache()->preparedSql($up_sql,$up_data)->affectedCount();
        }else{
            $result =$this->createUserProfit($from_uid,0,$profit_petty_cash);
        }
        if($result){
            $in_sql = "INSERT INTO users_invite_money values (null,:fromuid,:uid,:money,:create_time)";
            $in_data = array(
                ':money'=>$profit_petty_cash,
                ':fromuid'=>$from_uid,
                ':uid'=>$uid,
                ':create_time'=>time(),
            );
            @$this->dao->conn(false)->noCache()->preparedSql($in_sql,$in_data)->lastInsertId();
        }
        return $result;
    }
}