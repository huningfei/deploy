<?php
/**
 * @desc 	订单相关
 * @author  qien
 * @date    18.3.5
 */
class XbModel_Account_OrderIndex extends XbModel_BaseModel{
    public static $cache_tag = "Account_Order_Index_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @desc    创建订单索引信息
     * @param   array   $param      订单索引信息
     * @return  array   $return     返回创建结果
     */
    public function createOrderIndex($index_data){
        $index_sql = 'INSERT INTO `order_index` (`order_table_num`, `order_table_id`, `order_id`, `uid`, `create_time`) VALUES(:order_table_num, :order_table_id, :order_id, :uid, :create_time)';
        $order_index = $this->dao->conn(false)->noCache()->preparedSql($index_sql, $index_data)->lastInsertId();
        if($order_index){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $order_index;
    }
    
    /**
     * @desc    根据订单号，查询订单索引信息
     * @param   int     $orderid    订单号
     * @return  array   $return     返回搜索结果
     */
    public function getOrderIndexByOrderId($order_id){
        $sql = 'SELECT * FROM `order_index` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $order_id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }
}