<?php

class XbModel_Account_CommonChannelLevel extends XbModel_BaseModel {

    public static $cache_tag = "Account_Common_Channel_Level_";
    public static $cache_expire = 259200;
    
    public function __construct() {
        parent::_init("xb_account");
    }
    
    /**
     * 获取渠道等级设置
     * 
     * @param string $channel_id
     * @param string $level_id
     * @param string $type
     * @param number $page
     * @param number $perpage
     * @return array|multitype:
     */
    public function getChannelLevel($channel_id = '', $level_id = '', $type = '', $page = 1, $perpage = 10,$mch_id=1) {
        $sql = 'SELECT * FROM common_channel_level WHERE 1 ';
        
        $data = [];
        
        if ($channel_id) {
            $sql .= ' AND channel_id = :channel_id ';
            $data[':channel_id'] = $channel_id;
        }
        
        if ($level_id) {
            $sql .= ' AND level_id = :level_id ';
            $data[':level_id'] = $level_id;
        }
        
        if ($type) {
            $sql .= ' AND type = :type ';
            $data[':type'] = $type;
        }
        if($mch_id){
            $sql .= " AND mch_id =:mch_id ";
            $data[':mch_id']= $mch_id;
        }
        
        $perpage = abs($perpage);
        $offset = $page > 1 ? ($page - 1) * $perpage : 0;
        
        $sql .= " LIMIT {$offset},{$perpage}";
        $info = $this->dao->conn(true)->noCache()->preparedSql($sql, $data)->fetchAll();

        return $info ? $info : [];
    }
    
    /**
     * 获取渠道费率
     *
     * @param unknown $id
     * @return unknown
     */
    public function getChannelLevelById($id) {
        $id = (int)$id;
        $sql = 'SELECT * FROM common_channel_level WHERE id = ' . $id;
        $info = $this->dao->conn()->noCache()->preparedSql($sql, [])->fetchOne();
        return $info ? $info : [];
    }
    
    /**
     * 编辑通道费率
     *
     * @param unknown $id
     * @param unknown $level_id
     * @param unknown $channel_id
     * @param unknown $rate
     * @param unknown $fee
     * @param unknown $type
     * @return unknown
     */
    public function updateChannelLevel($id, $level_id = '', $channel_id = '', $rate = '', $fee = '', $type = '',$mch_id='') {
        $sql = 'UPDATE common_channel_level SET ';
        
        $update = [];
        $data = [];
        
        if ($level_id) {
            $update[] = ' level_id = :level_id ';
            $data[':level_id'] = $level_id; 
        }
        
        if ($channel_id) {
            $update[] = ' channel_id = :channel_id ';
            $data[':channel_id'] = $channel_id;
        }
        
        if ($rate !== '' && $rate !== null) {
            $update[] = ' rate = :rate ';
            $data[':rate'] = $rate;
        }
        
        if ($fee !== '' && $fee !== null) {
            $update[] = ' fee = :fee ';
            $data[':fee'] = $fee;
        }
        
        if ($type !== '' && $type !== null) {
            $update[] = ' type = :type ';
            $data[':type'] = $type;
        }
        if ($mch_id){
            $update[] = ' mch_id = :mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if ($data) {
            $sql .= implode(',', $update);
            $id = (int)$id;
            $sql .= " WHERE id = {$id}";

            try 
            {
                $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
                
                $this->updateChannelFee($id);
            }
            catch (Exception $e) {
                return false;
            }
            
            return $res;
        }
        else {
            return false;
        }
    }
    
    /**
     * 修改等级渠道设置后，同步更新等级费率数据
     * 
     * @param unknown $level
     * @return boolean
     */
    public function updateChannelFee($channel_level_id) {
        $channel_level_id = (int)$channel_level_id;
        $sql = 'SELECT level_id FROM common_channel_level WHERE id = ' . $channel_level_id;
        $level_id = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->fetchColumn(0);
        
        if (!$level_id) {
            return false;
        }
        
        //有积分
        $fee2 = 0;
        //无积分
        $fee1 = 0;
        
        $level_id = (int)$level_id;
        $sql = 'SELECT MIN(rate) FROM `common_channel_level` WHERE `level_id` = ' . $level_id . ' AND `type` = 1 GROUP BY level_id';
        
        $res2 = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->fetchColumn(0);
        
        $sql = 'SELECT MIN(rate) FROM `common_channel_level` WHERE `level_id` = ' . $level_id . ' AND `type` = 2 GROUP BY level_id';
        
        $res1 = $this->dao->conn(false)->noCache()->preparedSql($sql, [])->fetchColumn(0);
        
        $fee1 = $res1 ? $res1 : 0;
        $fee2 = $res2 ? $res2 : 0;
        
        $res = XbModule_Account_Level::getInstance()->updateFee($level_id, $fee1, $fee2);
  
        return $res;
    }
    
    /**
     * 增加通道费率
     *
     * @param unknown $level_id
     * @param unknown $channel_id
     * @param unknown $rate
     * @param unknown $fee
     * @param unknown $type
     * @return unknown
     */
    public function addChannelLevel($level_id, $channel_id, $rate, $fee, $type,$mch_id) {
        $sql = 'INSERT common_channel_level (level_id, channel_id, rate, fee, type, create_time,mch_id) 
                    VALUES (:level_id, :channel_id, :rate, :fee, :type, :create_time,:mch_id)';
        
        $data = [
            ':level_id' => $level_id, 
            ':channel_id' => $channel_id, 
            ':rate' => $rate, 
            ':fee' => $fee, 
            ':type' => $type, 
            ':create_time' => time(),
            ':mch_id'=>$mch_id
        ];
        try
        {
            $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
            
            if ($id) {
                $this->updateChannelFee($id);
            }
        }
        catch (Exception $e) {
            echo $e->getMessage();
        }
        
        return $id;
    }
    /**
     * @desc 获取等级对应的所有ID
     * @param    int      $channel_id     通道ID
     * @return   array
     */
    public function getCClByChannelId($channel_id){
        $sql = "SELECT id FROM `common_channel_level` WHERE  `channel_id` = :channel_id ";
        $data = array(
            ':channel_id' => $channel_id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }
}