<?php
/**
 *
 * Author: abel
 * Date: 2017/12/6
 * Time: 15:54
 */
class XbModel_Account_Users extends XbModel_BaseModel {
    static $cache_tag = "Account_Users_";

    function __construct() {
        parent::_init("xb_account");
    }

    /**
     * @param $phone
     * @param $password
     * @param $salt
     * @param string $channel
     * @param string $sub_channel
     * @param int $fromuid
     * @param string $invite_phone
     * @return bool|mixed
     */
    public function addUser($phone, $password, $salt, $channel = '', $mch_id = '', $level_id,$tag) {
        $now = time();
        $this->dao->conn(false)->beginTransaction();
        $sql = "INSERT INTO `users` (`phone`,`password`,`salt`,`channel`,`mch_id`,`mch_code`,`create_time`,`tag`) VALUES (:phone,:password,:salt,:channel,:mch_id,:mch_code,:create_time,:tag)";
        $data = array(
            ":phone"    => $phone,
            ":password" => $password,
            ":salt"     => $salt,
            ":channel"  => $channel,
            ":mch_id"   => $mch_id,
            ":mch_code" => '',
            ":create_time" => $now,
            ":tag"      => $tag
        );
        $uid = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if (empty($uid)) {
            $this->dao->rollback();
            return false;
        }
        $invite_sql = "INSERT INTO `users_level` (`uid`, `level_id`, `create_time`) VALUES (:uid, :level_id, :create_time)";
        $invite_data = array(
            ":uid"         => $uid,
            ":level_id"    => $level_id,
            ":create_time" => $now
        );
        $res = $this->dao->noCache()->preparedSql($invite_sql, $invite_data)->affectedCount();
        if(empty($res)){
            $this->dao->rollback();
            return false;
        }
        if (empty($res)) {
            $this->dao->rollback();
            return false;
        } else {
            $result = $this->dao->commit();
        }
        if($result){
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Account_Users_invite_parentlist_');
            return $uid;
        }

        return false;
    }

    /**
     * @param $phone
     * @return mixed
     */
    function getUserByPhone($phone) {
        $sql = "SELECT * FROM `users` WHERE `phone`=:phone";
        $data = array(
            ":phone" => $phone
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        return $res;
    }

    function getUserByUid($uid) {
        $sql = "SELECT `id`,`nickname`,`phone`,`headimg`,`mch_id`,`create_time`,`nickname_up`,`wx_openid`,`wx_unionid` FROM `users` WHERE `id`=:uid";
        $data = [
            ":uid" => $uid
        ];
        $user = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $user;
    }

    /**
     * @desc    修改手机号
     * @param   string  $phone          手机号
     * @param   string  $crypt_password 修改的密码
     * @param   string  $salt           密码盐
     * @return  boolen  $return         返回修改结果
     */
    public function updatePassword($phone, $crypt_password, $salt){
        $sql = "UPDATE `users` SET `password`=:password,`salt`=:salt WHERE phone=:phone";
        $data = array(
            ':password' => $crypt_password,
            ':salt'     => $salt,
            ':phone'    => $phone
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    修改用户头像
     * @param   int     $uid        用户id
     * @param   string  $headImg    用户头像
     * @return  boolen  $return     返回执行结果
     */
    public function updateHeadImg($uid, $headImg){
        $sql = "UPDATE `users` SET `headimg`=:headimg WHERE `id`=:id";
        $data = array(
            ':headimg' => $headImg,
            ':id' => $uid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    //获取拓展用户
    public function getExpandingUsers($id){
        $sql = "SELECT count(0) FROM `users` WHERE `mch_id`=:id";
        $data = [
            ":id" => $id
        ];
        $user = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        return $user;
    }

    /**
     * @desc    修改用户名
     * @param   int     $uid        用户id
     * @param   string  $username   用户名
     * @return  boolen  $return     返回执行结果
     */
    public function updateUsername($uid, $username){
        $sql = "UPDATE `users` SET `nickname`=:nickname WHERE `id`=:id";
        $data = array(
            ":id"       => $uid,
            ":nickname" => $username
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    根据uid获取邀请信息
     * @param   int     $uid        用户id
     * @return  array   $return     返回搜索结果
     */
    public function getInvite($uid){
        $sql = 'SELECT * FROM `invite` WHERE `uid`=:uid';
        $data = array(
            ":uid" => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据uid获取邀请码
     * @param   int     $uid        用户id
     * @return  array   $return     返回搜索结果
     */
    public function getInviteCode($uid){
        $sql  = 'SELECT * FROM `users_invite_code` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        if(!$res){
            $factory    = new RandomLib\Factory();
            $generator  = $factory->getGenerator(new SecurityLib\Strength());
            $build      = true;
            $inviteCode = "";
            while ($build) {
                $inviteCode = $generator->generateString(11, "abcdefghijklmnopqrstuvwxyz1234567890");
                //检查是否重复
                $inviteCodeData = $this->getInviteCodeByCode($inviteCode);
                if (empty($inviteCodeData)) {
                    $build = false;
                }
            }
            $sql  = 'INSERT INTO `users_invite_code`(`uid`, `inviteCode`) VALUES (:uid, :inviteCode)';
            $data = array(
                ':uid'        => $uid,
                ':inviteCode' => $inviteCode
            );
            $res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->lastInsertId();
            if(!$res){
                return false;
            }
            $this->dao->clearTag(self::$cache_tag);
            return $inviteCode;
        }
        return $res['inviteCode'];
    }

    /**
     * @desc    根据uid获取邀请码
     * @param   int     $uid        用户id
     * @return  array   $return     返回搜索结果
     */
    public function getInviteCodeByCode($inviteCode){
        $sql = 'SELECT * FROM `users_invite_code` WHERE `inviteCode`=:inviteCode';
        $data = array(
            ':inviteCode' => $inviteCode
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据微信unionid获取用户信息
     * @param   string      $unionid     用户微信unionid
     * @return  array       $return     返回用户信息
     */
    public function getUserinfoByUnionid($unionid){
        $sql = 'SELECT `id`,`nickname`,`phone`,`headimg`,`mch_id`,`create_time`,`nickname_up`,`wx_openid`,`wx_unionid` FROM `users` WHERE `wx_unionid`=:wx_unionid';
        $data = array(
            ':wx_unionid' => $unionid
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
//        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据openid、unionid创建用户
     * @param   string      $openid     用户微信openid
     * @param   string      $unionid    用户微信unionid
     * @return  array       $return     返回用户信息
     */
    public function createUserByOpenid($openid, $unionid, $nickname, $headimg, $channel,$mch_id){
        $time = time();
        $sql = 'INSERT INTO `users` (`wx_openid`, `wx_unionid`, `nickname`, `headimg`, `channel`, `create_time`,`mch_id`) VALUES (:wx_openid, :wx_unionid, :nickname, :headimg, :channel, :create_time,:mch_id)';
        $data = array(
            ':wx_openid'   => $openid,
            ':wx_unionid'  => $unionid,
            ':nickname'    => $nickname,
            ':headimg'     => $headimg,
            ':channel'     => $channel,
            ':create_time' => $time,
            ':mch_id'       => $mch_id
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            return $res;
        }
        return false;
    }

    /**
     * @desc    根据用户id，修改用户手机号，此方法是微信绑定手机号时使用，其他勿用**手机号数据不可更改选项**
     * @param   int     $uid       用户id
     * @param   int     $phone     用户手机号
     * @return  int     $return 执行结果|影响行数
     */
    public function updatePhoneByUid($uid, $phone){
        $sql = 'UPDATE `users` SET `phone`=:phone WHERE `id`=:id';
        $data = array(
            ':phone'    => $phone,
            ':id'       => $uid
        );
        return $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
    }

    /**
     * @desc    根据用户id，修改openid、uniondid，删除原来微信账户,此方法是微信绑定手机号时使用，其他勿用
     * @param   int     $uid        用户id
     * @param   int     $openid     微信openid
     * @param   int     $unionid    微信unionid
     * @param   int     $nickname   微信昵称
     * @param   int     $headimg    微信头像
     * @param   int     $oldUid     微信创建的用户id
     * @return  int     $return 执行结果|影响行数
     */
    public function updateUserOpenid($uid, $openid, $unionid, $nickname, $headimg, $oldUid){
        $this->dao->conn(false)->beginTransaction();
        $sql = 'UPDATE `users` SET `wx_openid`=:wx_openid, `wx_unionid`=:wx_unionid, `nickname`=:nickname, `headimg`=:headimg WHERE `id`=:id';
        $data = array(
            ':wx_openid'  => $openid,
            ':wx_unionid' => $unionid,
            ':nickname'   => $nickname,
            ':headimg'    => $headimg,
            ':id'         => $uid
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        $sql = 'DELETE FROM `users` WHERE `id`=:id';
        $data = array(
            ':id' => $oldUid
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        $res = $this->dao->commit();
        return $res;
    }
    /**
     * @desc    根据用户id，修改openid、uniondid
     * @param   int     $uid        用户id
     * @param   int     $openid     微信openid
     * @param   int     $unionid    微信unionid
     * @param   int     $nickname   微信昵称
     * @param   int     $headimg    微信头像
     * @return  int     $return 执行结果|影响行数
     */
    public function updateUserWechat($uid, $openid, $unionid, $nickname, $headimg){
        $sql = 'UPDATE `users` SET `wx_openid`=:wx_openid, `wx_unionid`=:wx_unionid, `nickname`=:nickname, `headimg`=:headimg WHERE `id`=:id';
        $data = array(
            ':wx_openid'  => $openid,
            ':wx_unionid' => $unionid,
            ':nickname'   => $nickname,
            ':headimg'    => $headimg,
            ':id'         => $uid
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            return false;
        }
        $this->dao->clearTag(self::$cache_tag);
        return $res;
    }

    /**
     * @desc    获取用户的parent_id
     * @return  array|false     $return 返回用户邀请人
     */
    public function getUsersRefer(){
        $sql = 'SELECT u.id,i.fromuid FROM `users` u  LEFT JOIN `invite` i ON u.id = i.uid';
        $data = array();
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc 校验昵称是否重复
     * @param  string    $nickName   昵称
     * @return array     $return     返回结果
     */
    public function checkNickName($nickName){
        $sql = 'SELECT id FROM `users` WHERE `nickname` = :nickname ';
        $data = array(
            ':nickname'=>$nickName
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @dec 修改昵称
     * @param  int      $uid          用户ID
     * @param  string   $$nickname    用户昵称
     * @return boolean  $return       返回执行结果
     */
    public function updateNickName($uid,$nickname){
        $mon = date('m',time());
        if($uid && $nickname){
            $sql = "UPDATE `users` set `nickname` = :nickname , `nickname_up` = :nickname_up WHERE `id` = :id";
            $data = array(
                ':id' => $uid,
                ':nickname' => $nickname,
                ':nickname_up' => $mon,
            );
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
                $_SESSION['users']['nickname'] = $nickname;
                $_SESSION['users']['nickname_up'] = $mon;
            }
            return $res;
        }
        return false;
    }
    /*
     * @desc 更新邀请二维码连接
     * @param    int          $uid        用户ID
     * @param    string       $qrcode     邀请二维码连接
     * @return   array        $return     返回执行结果
     * */
    public function  updateQrcode($uid,$qrcode){
        if($uid && $qrcode){
            $sql = "UPDATE `users_invite_code` set `qrcode_url` = :qrcode_url  WHERE `uid` = :uid";
            $data = array(
                ':uid' => $uid,
                ':qrcode_url' => $qrcode
            );
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        }
        return false;
    }
    /**
     * @desc 获取用户二维码邀请连接
     * @param  $uid      $uid   用户ID
     * @return array     $return     返回结果
     */
    public function getUserQrcode($uid){
        $sql = 'SELECT qrcode_url FROM `users_invite_code` WHERE `uid` = :uid ';
        $data = array(
            ':uid'=>$uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    获取所有用户信息
     * @return  array   $return     返回搜索结果
     */
    public function getAllUsers(){
        $sql = 'SELECT * FROM `users`';
        $data = array();
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc    获取用户在地天泰的等级 存入数据库
     * @param   int     $uid        用户id
     * @param   int     $level      用户等级
     * @return  array   $return     返回执行结果
     */
    public function addUsersLevel($uid,$level){
        $now = time();
        $get_sql ="SELECT uid FROM users_level where uid=:uid";
        $get_data = array(
            ':uid'=>$uid
        );
        $res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($get_sql, $get_data)->fetchOne();
        if(!$res){
            $sql = "INSERT INTO `users_level` (`uid`,`level_id`,`create_time`) VALUES (:uid,:level_id,:create_time)";
            $data = array(
                ':uid'         => $uid,
                ':level_id'    => $level,
                ':create_time' => $now
            );
            $res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->lastInsertId();
            if(!$res){
                return false;
            }
            return $res;
        }
        return $res['uid'];
    }

    //查询下线数量
    public function m_count(){
        $sql_num = 'select count(*) u_count,parentid from `users_invite_parentlist` GROUP BY parentid';
        $data = array();
        $str = $this->dao->conn()->noCache()->preparedSql($sql_num,$data)->fetchAll();
        $strArray = [];
        foreach($str as $k=>$v){
            $strArray[$v['parentid']] =$v;
        }
        return $strArray;
    }

    //注册商户列表
    public function registerIndex($id = '',$phone = '',$start_time = '',$end_time = '',$status = '',$s_phone = '',$realname = '',$merchant_id = '',$rank = '',$sens = '',$role_name = '',$m_id = '',$from_name = '',$page = '',$perpage = '',$flagcate,$tag){
        $count = $this->m_count();
        if($status !=''){
            $sql = 'select a.id,a.phone,a.nickname,a.mch_id,a.channel,a.wx_openid,a.wx_unionid,a.create_time,b.realname,b.`status`,a.tag from users a LEFT JOIN users_profile b on a.id = b.uid WHERE 1=1';
            if($status == 1){//已实名
                $sql .=' and b.`status` = 3';
            }elseif($status == 2){//未实名
                $sql .=' and (b.`status` = 0 or b.`status` is null)';
            }elseif($status == 3){//待审核
                $sql .=' and b.`status` = 2';
            }elseif($status == 4){//审核失败
                $sql .=' and b.`status` = 1';
            }
        }else{
            $sql = 'select a.id,a.phone,a.nickname,a.mch_id,a.channel,a.wx_openid,a.wx_unionid,a.create_time,a.tag from users a WHERE 1=1';
        }
        if($s_phone !=''){
            $users_sql = "SELECT id FROM `users` WHERE `phone` = $s_phone";
            $users_arr = $this->dao->conn()->noCache()->setTag(self::$cache_tag)->preparedSql($users_sql,array())->fetchOne();
            if(empty($users_arr)){
                return array();
            }
            $filed = 'uid,parentid';
            $where = "parentid = ".$users_arr['id'];
            $res = $this->queryData('users_invite',$filed,$where,'uid',self::$cache_tag,1);
            $users_invite_arr = $res['res'];
            $users_invite_str = $res['str'];
        }
        if($rank !=''){
            $filed = 'uid,level_id';
            $where = "level_id = $rank";
            $res = $this->queryData('users_level',$filed,$where,'uid',self::$cache_tag,1);
            $users_level_arr = $res['res'];
            $users_level_str = $res['str'];
        }
        if($realname !=''){
            $realname_sql = "SELECT `uid` FROM `users_profile` WHERE `realname` = '".$realname."'";
            $realname_arr = $this->dao->conn()->noCache()->setTag(self::$cache_tag)->preparedSql($realname_sql,array())->fetchAll();
            $users_profile_realname = array();
            foreach($realname_arr as $value){
                $users_profile_realname[] = $value['uid'];
            }
        }

        if($flagcate !=''){
            $flagcate_res = XbModule_Account_Flag::getInstance()->getAllFlagCate($flagcate);
            $flag_ids = array();
            $flag_userid=array();
            if($flagcate_res){
                foreach($flagcate_res as $key => $val){
                    $flag_ids[] = $val['id'];
                }
                //获取用户ID
                $flag_id = implode(',',$flag_ids);
                $flag_users = XbModule_Account_Users::getInstance()->getUserIdByFlagId($flag_id);
                if($flag_users){
                    foreach($flag_users as $key => $val){
                        $flag_userid[] = $val['uid'];
                    }
                }
            }

        }
        $data = array(
            ':page' => ($page-1)*$perpage,
            ':perpage' => $perpage,
        );
        //判断是否是代理
        if($role_name == "商户"){
            $sql .=' and a.`mch_id` = '.$m_id;
        }
        //判断用户来源
        if($from_name !=''){
            $sql .=' and a.`channel` = "'.$from_name.'"';
        }
        if($id !=''){
            $sql .=' and a.`id` = "'.$id.'"';
        }
        if($phone !=''){
            $sql .=' and a.`phone` = "'.$phone.'"';
        }
        if($start_time !=''){
            $sql .=' and a.`create_time` >= '.strtotime($start_time);
        }
        if($end_time !=''){
            $sql .=' and a.`create_time` < '.strtotime($end_time.' 23:29:29');
        }
        if($tag != ''){
            $sql .= " and a.tag ='".$tag."'";
        }
        if($s_phone !='' || $rank !='' || $realname !='' || $flagcate !=''){
            $new_uid = [];
            if($users_invite_str){
                foreach($users_invite_str as $v){
                    $new_uid[$v]=$v;
                }
            }
            if($users_level_str){
                foreach($users_level_str as $v){
                    $new_uid[$v]=$v;
                }
            }
            if($users_profile_realname){
                foreach($users_profile_realname as $v){
                    $new_uid[$v]=$v;
                }
            }
            if($flag_userid){
                foreach($flag_userid as $v){
                    $new_uid[$v]=$v;
                }
            }
            if(empty($new_uid)){
                $new_uid[0] = 0;
            }
           if(!empty($new_uid)){
               $query_id = implode(',',array_keys($new_uid));
               $sql .=' and a.`id` in ('.$query_id.')';
           }

        }
        if($merchant_id !=''){
            $sql .=' and a.`mch_id` = '.$merchant_id;
        }
        if($sens !=''){
            if($sens == 1){
                $sql .=' and a.`phone` != ""';
            }else{
                $sql .=' and a.`phone` = ""';
            }
        }
        if($page!='' && $perpage!=''){
            $sql .=' order by a.id desc limit :page,:perpage ';
        }
        $str = $this->dao->conn()->noCache()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
        $mid = '';
        $uid = '';
        foreach($str as &$v){
            $v['count'] = 0;
            if(!empty($count[$v['id']])){
                $v['count'] = $count[$v['id']]['u_count'];
            }
            if($v['mch_id'] != 0){
                $mid.= $v['mch_id'].',';
            }
            if($v['id'] != 0){
                $uid.= $v['id'].',';
            }
        }
        $uid = trim($uid,',');
        $mid = trim($mid,',');
        //查询代理名称
        if(!empty($mid)){
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($mid);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
        }
        //查询用户的父级用户
        if($s_phone == '' && !empty($uid)){
            $filed = 'uid,parentid';
            $where = "uid in ($uid)";
            $users_invite_arr = $this->queryData('users_invite',$filed,$where,'uid',self::$cache_tag,0);
        }
        //查询父级的手机号码
        if($users_invite_arr){
            $filed = 'id,phone';
            $p_users_id = '';
            foreach($users_invite_arr as $value){
                if($value['parentid'] != 0){
                    $p_users_id.= ','.$value['parentid'];
                }
            }
            $p_users_id = trim($p_users_id,',');
            if($p_users_id){
                $where = "id in ($p_users_id)";
                $p_users_arr = $this->queryData('users',$filed,$where,'id',self::$cache_tag,0);
            }
        }
        //查询商户真是姓名以及状态
        if($status =='' && !empty($uid)){
            $users_profile_str = $uid;
            if (!empty($users_invite_arr)){
                foreach($users_invite_arr as $value){
                    if($value['parentid'] != 0){
                        $users_profile_str .= ','.$value['parentid'];
                    }
                }
            }
            $filed = 'uid,realname,status';
            $where = "uid in ($users_profile_str)";
            $users_profile_arr = $this->queryData('users_profile',$filed,$where,'uid',self::$cache_tag,0);
        }
        //查询商户等级id
        if($rank =='' && !empty($uid)){
            $filed = 'uid,level_id';
            $where = "uid in ($uid)";
            $users_level_arr = $this->queryData('users_level',$filed,$where,'uid',self::$cache_tag,0);
        }
        //查询等级列表
        if(!empty($users_level_arr)){
            $level_id = array();
            foreach($users_level_arr as $value){
                $level_id[]= $value['level_id'];
            }
            $level_id = implode(',',array_unique($level_id));
            $filed = 'id,levelName';
            $where = "id in ($level_id)";
            $common_level_arr = $this->queryData('common_level',$filed,$where,'id',self::$cache_tag,0);
        }
        //查询用户注册来源
        if(!empty($uid)){
            $flag_sql = "SELECT u.*,c.title,c.id as f_id,c.pid FROM `users_source` u LEFT JOIN `common_flag` c ON u.flag_id=c.id WHERE `uid`in(".$uid.")";
            $data = [];
            $flag_res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($flag_sql,$data)->fetchAll();

        }


        foreach($str as &$v){
            $v['m_name'] = 0;
            if(!empty($modifyArray[$v['mch_id']])){
                $v['m_name'] = $modifyArray[$v['mch_id']]['name'];
            }
            //状态
            if($status ==''){
                $v['realname'] = '';
                if(!empty($users_profile_arr[$v['id']])){
                    $v['realname'] = $users_profile_arr[$v['id']]['realname'];
                    $v['status'] = $users_profile_arr[$v['id']]['status'];
                }
            }
            //上级姓名以及电话
            $v['p_name'] = '';
            $v['p_phone'] = '';
            if($users_invite_arr){
                if(!empty($users_profile_arr[$users_invite_arr[$v['id']]['parentid']])){
                    $v['p_name'] = $users_profile_arr[$users_invite_arr[$v['id']]['parentid']]['realname'];
                    $v['p_phone'] = $p_users_arr[$users_invite_arr[$v['id']]['parentid']]['phone'];
                }
            }
            //商户等级
            $v['levelName'] = '员工';
            if($users_level_arr){
                if(!empty($common_level_arr[$users_level_arr[$v['id']]['level_id']])){
                    $v['levelName'] = $common_level_arr[$users_level_arr[$v['id']]['level_id']]['levelName'];
                }
            }
            $v['flag']='';
            $v['domain']='';
            $v['url']='';
            $v['wx_subscribe']='';
            $v['pid']='';
            if($flag_res){
                foreach($flag_res as $kk => $vv){
                    if($v['id'] == $vv['uid']){
                        $v['flag'] = $vv['title'];
                        $v['domain'] = $vv['domain'];
                        $v['url'] = $vv['url'];
                        $v['wx_subscribe'] = $vv['wx_subscribe'];
                        $v['pid'] = $vv['pid'];
                    }

                }
            }
        }

        return $str;
    }

    //查看某商户
    public function registerOne($id = ''){
        $sql = 'SELECT a.id,a.phone,a.nickname,a.mch_id,a.mch_code,b.realname,b.idcardNumber,b.status,u.level_id,d.levelName FROM `users` a LEFT JOIN `users_profile` b on a.id=b.uid LEFT JOIN users_level u on a.id = u.uid LEFT JOIN common_level d on u.level_id = d.level WHERE a.id = '.$id;
        $data = array();
        $list = $this->dao->conn()->noCache()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
        //查询代理名称
        if(!empty($list['mch_id'])){
            $modify = XbModule_Merchant_Merchant::getInstance()->inMerchart($list['mch_id']);
            $modifyArray = array();
            foreach($modify as $k=>$vel){
                $modifyArray[$vel['id']] = $vel;
            }
            if(!empty($modifyArray[$list['mch_id']])){
                $list['mch_name'] = $modifyArray[$list['mch_id']]['name'];
            }
        }
        return $list;
    }


    //下线明细(加入筛选条件)
    public function registerDetails($param){
        extract($param);
        //当前id的直接下线
        $sqlDirect = 'select uid from `users_invite` where parentid = ' . $id;

        //查询sql
        $sql = 'select a.uid,a.parentid,b.id,b.phone,b.nickname,b.create_time,d.realname,e.level_id,f.levelName,g.status from `users_invite_parentlist` a LEFT JOIN `users` b on a.uid = b.id LEFT JOIN `users_profile` d on b.id = d.uid LEFT JOIN `users_level` e on a.uid = e.uid LEFT JOIN `common_level` f on e.level_id = f.level LEFT JOIN `users_profile` g on a.uid = g.uid where a.parentid = ' . $id;

        if ($is_work == 1) {//筛选直接下线
            $sql .= " and a.uid in ($sqlDirect)";
        }elseif ( $is_work == 2) {//筛选间接下线
            $sql .= " and a.uid not in ($sqlDirect)";
        }
        if($phone !=''){//筛选手机号
            $sql .=' and b.`phone` = "'.$phone.'"';
        }
        if($start_time !=''){//筛选注册时间
            $sql .=' and a.`create_time` >= ' . strtotime($start_time . ' 00:00:00');
        }
        if($end_time !=''){//筛选注册时间
            $sql .=' and a.`create_time` < ' . strtotime($end_time . ' 23:59:59');
        }

        $data = array(
            ':pagenum' => ($pagenum-1)*$pagesize,
            ':pagesize' => $pagesize,
        );
        if($pagenum!='' && $pagesize!=''){
            $sql .=' limit :pagenum,:pagesize ';
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * 获取用户的信息和用户的
     * @param $uid
     */
    public function getUserAndUserFrofileInfor($uid){
        $sql = "SELECT u.id,u.nickname,u.phone,u.headimg,u.mch_code,u.mch_id,u.create_time,u.nickname_up,u.wx_openid,u.wx_unionid,p.realname 
                FROM users u LEFT JOIN users_profile p 
                ON u.id=p.uid 
                WHERE u.id=:uid";
        $data = [
            ":uid" => $uid
        ];
        $user = $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
        return $user;
    }

    /**
     * @desc    添加用户注册标识
     * @param   array       $param      标识信息
     * @return  array       $return     返回用户标识结果
     */
    public function userSignupFlag($param){
        $flag_sql ="SELECT id FROM common_flag where pid > 0 and title=:flag_title";
        $flag_data = array(
            ':flag_title'=>$param['flag_title']
        );
        $flag_res = $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($flag_sql, $flag_data)->fetchOne();
        if ($flag_res) {
            $param['domain'] = empty($param['domain']) ? '' : $param['domain'];
            $param['url'] = empty($param['url']) ? '' : $param['url'];
            unset($param['flag_title']);
            $param['flag_id'] = $flag_res['id'];
            $sql = "INSERT INTO `users_source` (`uid`,`flag_id`,`domain`,`url`,`create_time`) VALUES (:uid,:flag_id,:domain,:url,:create_time)";
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $param)->lastInsertId();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        } else {
            return false;
        }

    }

    /**
     * @desc    记录扫描二维码时是否已关注公众
     * @param   bool       $param      标识信息
     * @return  array       $return     返回结果
     */
    public function setUserSubscribe($uid, $is_subscribe = 0){
            $sql = "UPDATE `users_source` SET `wx_subscribe`=:is_subscribe WHERE uid=:uid and wx_subscribe = 0";
            $data = array(
                ':uid' => $uid,
                ':is_subscribe'     => $is_subscribe
            );
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
            if($res){
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
    }
    /**
     * @desc 通过标识获取用户
     * */
    public function getUserIdByFlagId($flag_ids){
        $sql = "SELECT u.*,c.title,c.id as f_id FROM `users_source` u LEFT JOIN `common_flag` c ON u.flag_id=c.id WHERE `flag_id` in (".$flag_ids.")";
        $data = [];
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 获取用户注册来源
     * */
    public function getUserSourceByUid($uid){
        $sql = "SELECT u.*,c.title,c.id as f_id,c.pid FROM `users_source` u LEFT JOIN `common_flag` c ON u.flag_id=c.id WHERE `uid`=:uid";
        $data = array(
            ':uid' => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /*
         * @desc 获取用户申请信用卡列表
         * @param   int    $uid    用户ID
         * @return  array  $return 返回执行结果
         * */
    public function gerUserApplyBank($uid){
        $sql  = "SELECT * FROM  `users_apply_bank` WHERE `uid`=:uid";
        $data = array(
            ':uid' => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc 获取申请信用卡列表
     * @param    int          $start       偏移量
     * @param    int          $limit       条数
     * @param    string       $phone       手机号
     * @param    string       $start_time  开始时间
     * @param    string       $end_time    结束时间
     * @param    string       $status      状态
     * @param    string       $batch_number批次号
     * @return   array        $returnn     返回执行结果
     * */
    public function getApplyBankList($start,$limit,$phone,$start_time,$end_time,$status,$batch_number){
        $sql = "SELECT * FROM `users_apply_bank` WHERE 1=1 ";
        $data=[];
        if($phone){
            $sql .=' AND   `phone`=:phone';
            $data[':phone'] = trim($phone);
        }
        if($status){
            $sql .=' AND   `status`=:status';
            $data[':status'] = $status;
        }
        if($batch_number){
            $sql .=' AND   `batch_number`=:batch_number';
            $data[':batch_number'] = trim($batch_number);
        }
        if($start_time){
            $sql .=' AND `apply_time`>=:start_time';
            $data[':start_time'] = strtotime($start_time);
        }
        if($end_time){
            $sql .=' AND `apply_time`<=:end_time';
            $data['end_time'] = strtotime($start_time.' 23:59:59');
        }
        $sql .=' ORDER BY id desc LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();

    }

    /**
     * @desc 获取申请信用卡条数
     * @param    string       $phone       手机号
     * @param    string       $start_time  开始时间
     * @param    string       $end_time    结束时间
     * @param    string       $status      状态
     * @param    string       $batch_number批次号
     * @return   int          $num         返回查询次数
     * */
    public function getApplyBankCount($phone,$start_time,$end_time,$status,$batch_number){
        $sql = "SELECT count(*) as num FROM `users_apply_bank` WHERE 1=1 ";
        $data=[];
        if($phone){
            $sql .=' AND   `phone`=:phone';
            $data[':phone'] = trim($phone);
        }
        if($status){
            $sql .=' AND   `status`=:status';
            $data[':status'] = $status;
        }
        if($batch_number){
            $sql .=' AND   `batch_number`=:batch_number';
            $data[':batch_number'] = trim($batch_number);
        }
        if($start_time){
            $sql .=' AND `apply_time`>=:start_time';
            $data[':start_time'] = strtotime($start_time);
        }
        if($end_time){
            $sql .=' AND `apply_time`<=:end_time';
            $data['end_time'] = strtotime($start_time.' 23:59:59');
        }

        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();

    }
    /**
     * @desc 批量插入用户申请信用卡列表
     * @param     int       $file_id 上传文件ID
     * @param     array     $datas   用户数据
     * @return    boolean   $return 返回执行结果
     * */
    public function addUserBanks($file_id,$datas)
    {
        $number = count($datas);//导入总条数
        //先查询订单是否存在 没有：入库 反之更新
        $order_ids = '';
        foreach ($datas as $k => $v) {
            $order_ids .= $v['order_id'] . ',';
        }
        $order_ids = rtrim($order_ids, ',');
        $sel_sql = "SELECT id,order_id,status FROM `users_apply_bank` WHERE order_id in ($order_ids)";
        $sel_res = $this->dao->conn()->noCache()->preparedSql($sel_sql, [])->fetchAll();
        $up_data = [];//需要更新的数据
        $new_data = [];//需要新增的数据
        if ($sel_res) {
            foreach ($datas as $kk => &$vv) {
                foreach ($sel_res as $kkk => $vvv) {
                    if ($vv['order_id'] == $vvv['order_id']) {
                        $arr = $vv;
                        $arr['id'] = $vvv['id'];
                        $arr['old_status'] = $vvv['status'];
                        $up_data[] = $arr;
                        unset($datas[$kk]);
                    }
                }
            }
            $new_data = $datas ? $datas : [];
        } else {
            $new_data = $datas;
        }

        $check = true;
        $time = time();
        $data = [];
        $this->dao->conn(false)->beginTransaction();
        if ($up_data) {
            $up_sql = " UPDATE `users_apply_bank` SET `status`=:status,match_time=:match_time,update_time=:update_time,batch_number=:batch_number  WHERE id =:id";
            foreach ($up_data as $key => $val) {
                $status = $val['old_status'] == '已结算' ? $val['old_status'] : $val['status'];
                $update_data = array(
                    ':status' => $status,
                    ':match_time' => strtotime($val['match_time']),
                    ':update_time' => $time,
                    ':id' => $val['id'],
                    ':batch_number' => $val['batch_number'],
                );
                $up_res = $this->dao->noCache()->preparedSql($up_sql, $update_data)->affectedCount();
                if (!$up_res && $up_res !== 0) {
                    $this->dao->rollback();
                    XbFunc_Log::write('importBank', 'users_apply_bank失败：更改数据' . json_encode($up_data) . "结果" . $up_res);
                    $check = false;
                }
            }
        }
        if ($new_data) {
            $sql = "INSERT INTO `users_apply_bank` (order_id,phone,bank,uid,apply_time,status,match_time,batch_number,create_time) VALUES ";
            foreach ($new_data as $key => $val) {
                $key = $key + 1;
                $sql .= "  (:order_id" . $key . ",:phone" . $key . ",:bank" . $key . ",:uid" . $key . ",:apply_time" . $key . ",:status" . $key . ",:match_time" . $key . ",:batch_number" . $key . ",:create_time" . $key . "),";
                $data[":order_id" . $key] = $val['order_id'];
                $data[":phone" . $key] = $val['phone'];
                $data[":bank" . $key] = $val['bank'];
                $data[":uid" . $key] = $val['uid'];
                $data[":apply_time" . $key] = strtotime($val['apply_time']);
                $data[":status" . $key] = $val['status'];
                $data[":match_time" . $key] = strtotime($val['match_time']);
                $data[":batch_number" . $key] = $val['batch_number'];
                $data[":create_time" . $key] = $time;
            }
            $sql = rtrim($sql, ',');
            $new_res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
            if (!$new_res) {
                XbFunc_Log::write('importBank', 'users_apply_bank插入失败：更改数据' . json_encode($data) . "结果" . $new_res);
                $this->dao->rollback();
                $check = false;
            }
        }
        //更改上传数据状态
        if ($check) {
            $res = $this->dao->commit();
            if ($res) {
                $this->dao->clearTag(self::$cache_tag);
                $file_res = XbModule_Account_CommonBankFile::getInstance()->updateStatus($file_id, 1, '', $number);
                if (!$file_res) {
                    XbFunc_Log::write('importBank', '更改common_bank_file失败' . $file_res);
                }

                XbLib_ActEvent_EventManager::attach(XbLib_ActEvent_CommonEvent::AFTER_UPLOAD_CREDITCARD_APPLY);

                XbLib_ActEvent_EventManager::trigger(XbLib_ActEvent_CommonEvent::AFTER_UPLOAD_CREDITCARD_APPLY, $this, [
                    'file_id' => $file_id
                ]);
            }
            return $res;
        } else {
            $file_res = XbModule_Account_CommonBankFile::getInstance()->updateStatus($file_id, 2, '数据导入失败', $number);
            if (!$file_res) {
                XbFunc_Log::write('importBank', '更改common_bank_file失败' . $file_res);
            }
            return false;
        }
    }
    /**
     * @desc    批量获取实名用户信息
     * @param   int     $limit      偏移量
     * @param   int     $num        获取条数
     * @param   int     $mch_id     代理id
     * @param   boolen  $isALl      是否查询全部用户，如果不是的话，只查询有手机号用户
     * @return  array   $return     返回搜索的用户数据
     */
    public function getUsers($limit, $num, $mch_id=false, $status=false, $uid=false, $realname=false, $phone=false, $startTime=false, $endTime=false, $isALl=false)
    {
        $sql = 'SELECT u.*,up.realname,up.idcardNumber FROM `users` u 
                LEFT JOIN `users_profile` up ON u.id=up.uid
                WHERE 1=1';
        $data = array(
            ':limit' => $limit,
            ':num'   => $num,
        );
        if($mch_id){
            $sql .= ' AND u.`mch_id`=:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if($status !== false){
            $sql .= ' AND up.`status`=:status';
            $data[':status'] = $status;
        }
        if($phone !== false){
            $sql .= ' AND u.`phone`=:phone';
            $data[':phone'] = $phone;
        }
        if($uid !== false){
            $sql .= ' AND u.`id`=:id';
            $data[':id'] = $uid;
        }
        if($realname !== false){
            $sql .= ' AND up.`realname`=:realname';
            $data[':realname'] = $realname;
        }
        if($startTime !== false){
            $sql .= ' AND u.`create_time` >= :startTime';
            $data[':startTime'] = $startTime;
        }
        if($endTime !== false){
            $sql .= ' AND u.`create_time` <= :endTime';
            $data[':endTime'] = $endTime;
        }
        if(!$isALl){
            $sql .= ' AND u.`phone` != ""';
        }
        $sql .= ' LIMIT :limit, :num';
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    统计用户数量
     * @param   int             $mch_id     代理id
     * @param   boolen|false    $isALl      是否查询所有用户，如果是false
     * @return  int             $return     返回查询条数
     */
    public function countUsers($mch_id=false, $status=false, $uid=false, $realname=false, $phone=false, $startTime=false, $endTime=false, $isALl=false)
    {
        $sql = 'SELECT COUNT(*) AS num FROM `users` u 
                LEFT JOIN `users_profile` up ON u.id=up.uid
                WHERE 1=1';
        $data = array();
        if($mch_id){
            $sql .= ' AND u.`mch_id`=:mch_id';
            $data[':mch_id'] = $mch_id;
        }
        if($status !== false){
            $sql .= ' AND up.`status`=:status';
            $data[':status'] = $status;
        }
        if($phone !== false){
            $sql .= ' AND u.`phone`=:phone';
            $data[':phone'] = $phone;
        }
        if($uid !== false){
            $sql .= ' AND u.`id`=:id';
            $data[':id'] = $uid;
        }
        if($realname !== false){
            $sql .= ' AND up.`realname`=:realname';
            $data[':realname'] = $realname;
        }
        if($startTime !== false){
            $sql .= ' AND u.`create_time` >= :startTime';
            $data[':startTime'] = $startTime;
        }
        if($endTime !== false){
            $sql .= ' AND u.`create_time` <= :endTime';
            $data[':endTime'] = $endTime;
        }
        if(!$isALl){
            $sql .= ' AND u.`phone` != ""';
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    修改用户手机号
     * @param   int             $uid        用户id
     * @param   int             $phone      手机号
     * @return  int             $return     返回结果
     */
    public function changePhone($uid, $phone) {
        $sql = "UPDATE `users` SET `phone`=:phone WHERE id=:uid";
        $data = array(
            ':uid' => $uid,
            ':phone' => $phone
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc 随机获取手机号
     */
    public function getPhone($limit){
        $sql = "SELECT phone FROM users where phone !='' order by rand() limit :limit";
        $data[':limit'] = $limit;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
}