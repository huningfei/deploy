<?php
/**
 * @desc 	用户还款渠道注册
 * @author  qien
 * @date    18.04.14
 */
class XbModel_Repayment_UsersChannel extends XbModel_BaseModel{
    public static $cache_tag = "Repayment_UsersChannel_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_repayment");
    }

    /**
     * @desc    创建用户通道身份标识
     * @param   int     $uid            用户id
     * @param   array   $channelInfo    通道标识信息
     * @return  boolen  $return         返回创建结果
     */
    public function createChannelCode($uid, $channelInfo){
        if(count($channelInfo) == 0) return false;
        $time = time();
        $sql = 'INSERT INTO `users_channel_code`(`uid`, `channel_id`, `channel_code`, `channel_key`, `status`, `create_time`) VALUES';
        $data = array(
            ':uid'         => $uid,
            ':status'      => 2,
            ':create_time' => $time
        );
        foreach($channelInfo as $k=>$v){
            if(!$v['channel_code']) continue;
            $sql .= "(:uid, :channel_id{$k}, :channel_code{$k}, :channel_key{$k}, :status, :create_time),";
            $data[":channel_id{$k}"]   = $v['channel_id'];
            $data[":channel_code{$k}"] = $v['channel_code'];
            $data[":channel_key{$k}"]  = $v['channel_key'];
        }
        if(count($data) <= 3) return false;
        $sql = trim($sql, ',');
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    获取用户注册通道信息
     * @param   int     $uid            用户id
     * @param   int     $channel_id     通道id
     * @return  array   $return         返回用户通道信息
     */
    public function getUserChannelInfo($uid, $channel_id){
        $sql = 'SELECT * FROM `users_channel_code` WHERE `uid`=:uid AND `channel_id`=:channel_id';
        $data = array(
            ':uid'        => $uid,
            ':channel_id' => $channel_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    /**
     *@desc  通过channel_code 获取用户ID
     *@param   string      $channel_code     通道码
     *@return  return      $return           返回执行结果
     */
    public function getUserId($channel_code){
        $sql = "SELECT * FROM `users_channel_code` WHERE `channel_code` = :channel_code ";
        $data = array(
            ':channel_code'   =>  $channel_code,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }

    /**
     * @desc    用户注册指定还款通道
     * @param   int     $channel_id 通道id
     * @param   int     $uid        用户id
     * @return  array   $return     返回注册情况
     */
    public function userSignUp($channel_id, $uid){
        $order_obj = XbLib_RepaymentObjs_Order::getInstance()->userSignUp($channel_id, $uid);
        if (!$order_obj instanceof XbLib_RepaymentObjs_Order) {
            return $order_obj;
        }
        $res_sign_up = XbLib_Repayment_Channel::getInstance()->userSignUp($channel_id, $order_obj);
        if (!$res_sign_up['success']) {
            return new XbLib_WebError(400,'通道进件失败');
        }

        $sql = 'INSERT INTO `users_channel_code`(`uid`, `channel_id`, `channel_code`, `channel_key`, `status`, `create_time`) VALUES (:uid, :channel_id, :channel_code, :channel_key, :status, :create_time)';
        $data = array(
            ':uid'         => $uid,
            ':channel_id'  => $channel_id,
            ':channel_code'=> $res_sign_up['data']['mimer_member_id'],
            ':channel_key' => '',
            ':status'      => 2,
            ':create_time' => time()
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
}