<?php
/**
 * @desc 	还款渠道
 * @author  qien
 * @date    18.04.14
 */
class XbModel_Repayment_Channel extends XbModel_BaseModel{
    public static $cache_tag = "Repayment_Channel_";
    public static $cache_expire = 259200;
    function __construct() {
        parent::_init("xb_repayment");
    }
    
    /**
     * @desc    获取渠道列表
     * @param   int     $channel_tag      有无积分（1：有积分；2：无积分）
     * @param   int     $type             通道类型
     * @param   int     $start            偏移量
     * @param   int     $limit            每页显示条数
     * @return  array   $return           返回执行结果
     */
    public function getChannelList($channel_tag,$type,$start,$limit){
        $time = time();
        $sql = 'SELECT * FROM `channel` WHERE create_time<'.$time;
        $data=[];
        if(!empty($channel_tag) && $channel_tag==1){
            $sql .= ' AND with_integral=:with_integral';
            $data[':with_integral'] = $channel_tag;
        }
        if(is_numeric($channel_tag) &&  $channel_tag==0){
            $sql .= ' AND without_integral=:without_integral';
            $data[':without_integral'] = $channel_tag;
        }
        if(!empty($type)){
            $sql .= ' AND type=:type';
            $data[':type'] = $type;
        }
        $sql .=' LIMIT :start,:limit';
        $data[':start'] = $start;
        $data[':limit'] = $limit;
        $res =  $this->dao->conn()->expire(self::$cache_expire)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
        if($res){
            return $res;
        }
        return false;
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelid($channel_id){
        $sql = 'SELECT * FROM `channel` WHERE `channel_id`=:channel_id';
        $data = array(
            ':channel_id' => $channel_id
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据channel_id获取渠道信息
     * @param   int     $channel_id     渠道channnel_id
     * @param   int     $level          相关等级
     * @return  array   $return         返回渠道信息
     */
    public function getChannelByChannelidLevel($channel_id, $level){
        $sql = 'SELECT * FROM `channel` c LEFT JOIN `channel_level` cl ON cl.channel_id=c.channel_id WHERE c.`channel_id`=:channel_id AND cl.`level_id`=:level';
        $data = array(
            ':channel_id' => $channel_id,
            ':level'   => $level
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据状态，用户等级获取通道
     * @param   int     $status     通道状态
     * @param   int     $level      用户等级
     * @return  array   $return     返回通道
     */
    public function getAllChannelByStatusLevel($status, $level){
        $sql = 'SELECT * FROM `channel` c LEFT JOIN `channel_level` cl ON cl.channel_id=c.channel_id WHERE c.`status`=:status AND cl.`level_id`=:level';
        $data = array(
            ':status' => $status,
            ':level'  => $level
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc 获取可用通道
     * @param  int    $status   通道状态
     * @return  array $return   返回执行结果
     * */
    public function getChannel($status){
        $sql = "SELECT * FROM  `channel` WHERE `status`=:status";
        $data = array(
            ':status'=>$status
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @desc    根据level获取费率信息
     * @param   int     $level      用户等级
     * @return  array   $return     返回根据等级配置的通道信息
     */
    public function getChannelByLevel($level){
        $sql = 'SELECT * FROM `channel_level` WHERE `level_id`=:level';
        $data = array(
            ':level' => $level
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
}