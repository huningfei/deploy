<?php
/**
 * @desc 	信用卡还款订单
 * @author  qien
 * @date    18.04.21
 */
class XbModel_Repayment_OrderPlan extends XbModel_BaseModel{
    public static $cache_tag = "Repayment_OrderPlan_";
    public static $cache_expire = 259200;
    public static $suffix;
    function __construct() {
        parent::_init("xb_repayment");
    }

    /**
     * @desc    创建订单计划
     * @param   int     $uid        用户id
     * @param   int     $cid        信用卡id
     * @param   int     $amount     还款金额
     * @param   int     $time       还款次数
     * @param   float   $fee_total  总共手续费
     * @param   int     $fee        单次手续费
     * @param   float   $rate       利率
     * @param   string  $details    计划详情
     * @return  int     $return     返回订单order_id
     */
    public function createOrderTmp($uid, $cid, $amount, $time, $fee_total, $fee, $rate, $details, $type){
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $sql = 'INSERT INTO `order_plan_'.self::$suffix.'_tmp`(`order_id`, `uid`, `cid`, `amount`, `plan_time`, `fee_total`, `fee`, `rate`, `details`, `type`, `create_time`) VALUES(:order_id, :uid, :cid, :amount, :plan_time, :fee_total, :fee, :rate, :details, :type, :create_time)';
        $data = array(
            ':order_id'    => $order_id,
            ':uid'         => $uid,
            ':cid'         => $cid,
            ':amount'      => $amount,
            ':plan_time'   => $time,
            ':fee_total'   => $fee_total,
            ':fee'         => $fee,
            ':rate'        => $rate,
            ':details'     => $details,
            ':type'        => $type,
            ':create_time' => time()
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res ? $order_id : $res;
    }

    /**
     * @desc    获取制定计划详情
     * @param   string      $orderId        订单号
     * @param   int         $uid            用户id
     * @return  array       $return         返回订单详情
     */
    public function getOrderPlanTmp($orderId, $uid){
        $sql = 'SELECT * FROM `order_plan_'.self::$suffix.'_tmp` WHERE `order_id`=:order_id AND `uid`=:uid ORDER by id';
        $data = array(
            ':order_id' => $orderId,
            ':uid'      => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc 获取还款计划明细列表
     * */
    public function getOrderPlan($oid,$uid,$start,$limit,$type){
        $sql = 'SELECT * FROM `order_plan_'.self::$suffix.'` WHERE `oid`=:oid AND `uid`=:uid ';
        $data = array(
            ':oid' => $oid,
            ':uid'      => $uid
        );
        if(!empty($type)){
            $sql .= " AND `plan_type`=:plan_type";
            $data[':plan_type'] = $type;
        }
        $sql .=' ORDER by issue';
        if(is_numeric($start) && $limit){
            $sql .= " LIMIT ".$start." , ".$limit;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc 获取还款计划明细列表数量
     * */
    public function getOrderPlanCount($oid,$uid,$type){
        $sql = 'SELECT count(*) as num FROM `order_plan_'.self::$suffix.'` WHERE `oid`=:oid AND `uid`=:uid ';
        $data = array(
            ':oid' => $oid,
            ':uid'      => $uid
        );
        if(!empty($type)){
            $sql .= " AND `plan_type`=:plan_type";
            $data[':plan_type'] = $type;
        }
        $sql .=' ORDER by issue';

        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc    根据订单号获取订单
     */
    public function getOrderPlanByOrderId($orderId){
        $sql  = 'SELECT * FROM `order_plan_'.self::$suffix.'` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $orderId
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc 获取还款计划明细列表
     * */
    public function getOrderPlanById($id){
        $sql = 'SELECT * FROM `order_plan_'.$this->suffix.'` WHERE `id`=:id ';
        $data['id'] = $id;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
}