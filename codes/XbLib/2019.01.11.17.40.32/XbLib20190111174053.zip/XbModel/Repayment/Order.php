<?php
/**
 * @desc 	信用卡还款订单
 * @author  qien
 * @date    18.04.14
 */
class XbModel_Repayment_Order extends XbModel_BaseModel{
    public static $cache_tag = "Repayment_Order_";
    public static $cache_expire = 259200;
    public static $suffix;
    function __construct() {
        parent::_init("xb_repayment");
    }

    /**
     * @desc    根据订单号获取订单
     */
    public function getOrderByOrderId($orderId){
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $orderId
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    一键还款订单
     */
    public function createCommonOrder($uid, $cid, $amount, $channel_id, $merchant_id){
        $order_obj = XbLib_RepaymentObjs_Order::getInstance()->userCreateOrder($channel_id,$uid,$cid, $amount, $merchant_id);
        if (!$order_obj instanceof XbLib_RepaymentObjs_Order) {
            return $order_obj;
        }

        $this->dao->conn(false)->beginTransaction();
        $sql = 'INSERT INTO `order_'.self::$suffix.'`(`order_id`, `uid`, `amount`, `custom_amount`, `single_fee`, `level`, `rate`, `paycard_id`, `paycard_number`, `repaycard_id`, `repaycard`, `channel_id`, `channel_name`, `repaycardcode`, `repaybank`, `realname`, `sett_transferway`, `status`, `create_time`, `type`) VALUES(:order_id, :uid, :amount, :custom_amount, :single_fee, :level, :rate, :paycard_id, :paycard_number, :repaycard_id, :repaycard, :channel_id, :channel_name, :repaycardcode, :repaybank, :realname, :sett_transferway, :status, :create_time, :type)';
        $data = array(
            ':order_id'         => $order_obj->param['order_id'],
            ':uid'              => $order_obj->user->uid,
            ':amount'           => $order_obj->param['pay_amount'],
            ':custom_amount'    => $order_obj->param['amount'],
            ':single_fee'       => $order_obj->user->channel_level['fee'],
            ':level'            => $order_obj->user->level['level'],
            ':rate'             => $order_obj->user->channel_level['rate'],
            ':paycard_id'       => $order_obj->user->card['id'],
            ':paycard_number'   => $order_obj->user->card['cardNumber'],
            ':repaycard_id'     => $order_obj->user->card['id'],
            ':repaycard'        => $order_obj->user->card['cardNumber'],
            ':repaycardcode'    => $order_obj->user->card['bankCode'],
            ':repaybank'        => $order_obj->user->card['bank'],
            ':realname'         => $order_obj->user->info['realname'],
            ':channel_id'       => $order_obj->channel->info['id'],
            ':channel_name'     => $order_obj->channel->info['channel_name'],
            ':sett_transferway' => $order_obj->channel->info['is_settlement'],
            ':status'           => 0,
            ':create_time'      => $order_obj->param['time'],
            ':type'             => 1
        );
        $res_sql = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res_sql){
            $this->dao->rollback();
            return new XbLib_WebError(400,'创建订单失败');
        }

        $index_sql = 'INSERT INTO `order_index` (`order_table_num`, `order_table_id`, `order_id`, `uid`, `type`, `create_time`) VALUES(:order_table_num, :order_table_id, :order_id, :uid, :type, :create_time)';
        $index_data = array(
            ':order_table_num'  => self::$suffix,
            ':order_table_id'   => $res_sql,
            ':order_id'         => $order_obj->param['order_id'],
            ':uid'              => $order_obj->user->uid,
            ':type'             => 1,
            ':create_time'      => $order_obj->param['time'],
        );
        $res_index_sql = $this->dao->noCache()->preparedSql($index_sql, $index_data)->lastInsertId();
        if(!$res_index_sql){
            $this->dao->rollback();
            return new XbLib_WebError(400,'创建订单索引失败');
        }
        $res_trans = XbLib_Repayment_Channel::getInstance()->createOrder($order_obj->channel->channel_id, $order_obj);

        if(!$res_trans['success']){
            $this->dao->rollback();
            return new XbLib_WebError(400,'调用通道失败');
        }
        $res = $this->dao->commit();

        if($res){
            $this->dao->clearTag(self::$cache_tag);
            //支付下单创建分润信息
            XbInterface_Repayment_Repayment::getInstance()->createProfit($order_obj->param['order_id'],self::$suffix,$order_obj->param['amount'],5,$order_obj->user->uid);
            return $order_obj->param['order_id'];
        }
        return new XbLib_WebError(400, '下单失败');
    }

    /*
     * @desc    创建智能还款订单
     * @param*/
    public function createWiseOrder($uid, $amount, $fee, $feeTotal, $level, $rate, $cid, $bankCardNumber, $bankCardCode, $bankName, $realname, $plan_time, $sett_type, $type, $detail, $district_id){
        if(count($detail) == 0){
            return false;
        }
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $sql = 'INSERT INTO `order_'.self::$suffix.'`(`order_id`, `uid`, `amount`, `single_fee`, `fee`, `level`, `rate`, `paycard_id`, `paycard_number`, `repaycard_id`, `repaycard`, `repaycardcode`, `repaybank`, `realname`, `sett_transferway`, `status`, `create_time`, `type`, `plan_time`, `district_id`) VALUES(:order_id, :uid, :amount, :single_fee, :fee, :level, :rate, :paycard_id, :paycard_number, :repaycard_id, :repaycard, :repaycardcode, :repaybank, :realname, :sett_transferway, :status, :create_time, :type, :plan_time, :district_id)';
        $data = array(
            ':order_id'         => $order_id,
            ':uid'              => $uid,
            ':amount'           => $amount,
            ':single_fee'       => $fee,
            ':fee'              => $feeTotal,
            ':level'            => $level,
            ':rate'             => $rate,
            ':paycard_id'       => $cid,
            ':paycard_number'   => $bankCardNumber,
            ':repaycard_id'     => $cid,
            ':repaycard'        => $bankCardNumber,
            ':repaycardcode'    => $bankCardCode,
            ':repaybank'        => $bankName,
            ':realname'         => $realname,
            ':sett_transferway' => $sett_type,
            ':status'           => 0,
            ':create_time'      => $time,
            ':type'             => 2,
            ':plan_time'        => $plan_time,
            ':district_id'       => $district_id,
        );
        $oid = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        //var_dump($oid);exit;
        if(!$oid){
            $this->dao->rollback();
            return false;
        }

        $index_sql = 'INSERT INTO `order_index` (`order_table_num`, `order_table_id`, `order_id`, `uid`, `type`, `create_time`) VALUES(:order_table_num, :order_table_id, :order_id, :uid, :type, :create_time)';
        $index_data = array(
            ':order_table_num'  => self::$suffix,
            ':order_table_id'   => $oid,
            ':order_id'         => $order_id,
            ':uid'              => $uid,
            ':type'             => 1,
            ':create_time'      => $time,
        );
        $order_index_id = $this->dao->noCache()->preparedSql($index_sql, $index_data)->lastInsertId();
        if(!$order_index_id){
            $this->dao->rollback();
            return false;
        }

        $sql = 'INSERT INTO `order_plan_'.self::$suffix.'`(`oid`, `order_id`, `uid`, `issue`, `amount`, `single_fee`, `sett_type`, `status`, `type`, `plan_type`, `pay_time`, `create_time`) VALUES';
        $data = array(
            ':oid'         => $oid,
            ':uid'         => $uid,
            ':single_fee'  => $fee,
            ':sett_type'   => $sett_type,
            ':status'      => 0,
            ':type'        => $type,
            ':plan_type'   => 1,
            ':create_time' => $time
        );
        foreach($detail as $k=>$v){
            $sql .= "(:oid, :order_id{$k}, :uid, :issue{$k}, :amount{$k}, :single_fee, :sett_type, :status, :type, :plan_type, :pay_time{$k}, :create_time),";
            $data[":order_id{$k}"] = XbModule_Account_OrderCode::getInstance()->getOrderCode();
            $data[":issue{$k}"]    = $v['time'];
            $data[":amount{$k}"]   = $v['amount'];
            $data[":pay_time{$k}"] = $v['date'];
        }
        $sql = trim($sql, ',');
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }
        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
            return $order_id;
        }
        return false;
    }

    /**
     * @desc    暂停执行计划
     */
    public function stopWisePlan($orderId, $status, $desc){
        $sql = 'UPDATE `order_'.self::$suffix.'` SET `status`=:status, `desc`=:desc WHERE `order_id`=:order_id';
        $data = array(
            ':status'   => $status,
            ':desc'     => $desc,
            ':order_id' => $orderId
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    根据用户id获取用户订单
     */
    public function getRepaymentOrder($uid, $limit, $num, $type=false, $status=false){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data['type'] = $type;
        }
        $sql .= ' ORDER BY id DESC LIMIT '.$limit.','.$num;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    统计用户id获取用户订单
     */
    public function countRepaymentOrder($uid, $type=false, $status=false){
        $sql = 'SELECT COUNT(*) AS num FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        if($status){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    获取用户刷卡订单金额
     */
    public function getRepaymentOrderAmount($uid, $type=false, $status=false){
        $sql = 'SELECT SUM(`amount`) AS amount FROM `order_'.self::$suffix.'` WHERE `uid`=:uid';
        $data = array(
            ':uid' => $uid
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        if($status){
            $sql .= ' AND `status`=:status';
            $data[':status'] = $status;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    获取订单详情
     */
    public function getOrderInfo($orderId, $type=false){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `order_id`=:order_id';
        $data = array(
            ':order_id' => $orderId
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    根据oid获取订单计划详情
     */
    public function getOrderPlanByOid($oid){
        $sql = 'SELECT * FROM `order_plan_'.self::$suffix.'` WHERE `oid`=:oid';
        $data = array(
            ':oid'  => $oid,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据信用卡号获取用户订单
     */
    public function getOrderByCard($uid, $cardNumber, $start, $limit, $type=false){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `uid`=:uid AND `repaycard`=:repaycard';
        $data = array(
            ':uid'       => $uid,
            ':repaycard' => $cardNumber
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        $sql .= ' ORDER BY id DESC LIMIT '.$start.','.$limit;
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据信用卡号获取用户订单
     */
    public function countOrderByCard($uid, $cardNumber, $type=false){
        $sql = 'SELECT COUNT(*) AS num FROM `order_'.self::$suffix.'` WHERE `uid`=:uid AND `repaycard`=:repaycard';
        $data = array(
            ':uid'       => $uid,
            ':repaycard' => $cardNumber
        );
        if($type){
            $sql .= ' AND `type`=:type';
            $data[':type'] = $type;
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /*
     * @desc    根据订单状态和类型获取订单
     */
    public function getOrderByStatusAndType($status, $type, $limit, $num, $startTime=false, $endTime=false){
        $sql = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `status`=:status AND `type`=:type';
        $data = array(
            ':status' => $status,
            ':type'   => $type,
            ':limit'  => $limit,
            ':num'    => $num
        );
        if($startTime){
            $sql .= ' AND `create_time`>=:startTime AND `create_time`<=:endTime';
            $data[':startTime'] = $startTime;
            $data[':endTime']   = $endTime;
        }
        $sql .= ' LIMIT :limit, :num';
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    根据订单状态和类型获取计划订单
     * @param   int     $status     计划订单状态
     * @param   int     $type       计划订单类型
     * @param   int     $limit      开始条数
     * @param   int     $num        结束条数
     * @return  array   $return     返回查询结果
     */
    public function getPlanOrderByStatusAndType($status, $type, $limit, $num){
        $sql = 'SELECT * FROM `order_plan_'.self::$suffix.'` WHERE `real_status`=:status AND `plan_type`=:type LIMIT :limit,:num';
        $data = array(
            ':status' => $status,
            ':type'   => $type,
            ':limit'  => $limit,
            ':num'    => $num
        );
        return $this->dao->conn()->noCache(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc 获取订单列表
     * */
    public function getOrderList($phone,$id,$status,$channel_id,$start_time,$end_time,$start,$limit){
        $sql = " SELECT * FROM `order_".self::$suffix."` as o WHERE  1=1 ";
        $data=[];
        if(!empty($id)){
            $sql .= " AND o.id = ".$id;
        }
        if(!empty($status) || $status === 0){
            $sql .= " AND o.status = ".$status;
        }
        if(!empty($channel_id)){
            $sql .= " AND 0.channel_id = ".$channel_id;
        }
        if(!empty($start_time)){
            $sql .= ' AND  o.create_time >= '.strtotime($start_time.' 00:00:00');
        }
        if(!empty($end_time)){
            $end_time = strtotime($end_time.' 23:59:59');
            $sql .= ' AND  o.create_time <= '.$end_time;
        }

        if(!empty($phone)){
            //通过手机号获取uid
            $uid = XbModule_Account_Users::getInstance()->getUserByPhone($phone)['id'];
            if($uid){
                $sql .=" AND o.uid = ".$uid;
            }
        }
        $sql .=' order by o.create_time desc limit '.$start.','.$limit;

        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();

    }
    /**
     * @desc 获取总订单数量
     * */
    public function getOrderListCount($phone,$id,$status,$channel_id,$start_time,$end_time){
        $sql = " SELECT count(*) as num FROM `order_".self::$suffix."` as o WHERE  1=1 ";
        $data=[];
        if(!empty($id)){
            $sql .= " AND o.id = ".$id;
        }
        if(!empty($status)){
            $sql .= " AND o.status = ".$status;
        }
        if(!empty($channel_id)){
            $sql .= " AND 0.channel_id = ".$channel_id;
        }
        if(!empty($start_time)){
            $sql .= ' AND  o.create_time >= '.strtotime($start_time.' 00:00:00');
        }
        if(!empty($end_time)){
            $end_time = strtotime($end_time.' 23:59:59');
            $sql .= ' AND  o.create_time <= '.$end_time;
        }
        if(!empty($phone)){
            //通过手机号获取uid
            $uid = XbModule_Account_Users::getInstance()->getUserByPhone($phone)['id'];
            if($uid){
                $sql .=" AND o.uid = ".$uid;
            }
        }
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc    根据ID获取订单
     */
    public function getOrderById($id){
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `id`=:id';
        $data = array(
            ':id' => $id
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     *@desc 更改还款订单状态
     * */
    public function updateStatus($id, $status, $desc=''){
        //先查询当前订单是否可以被修改状态
        $sql = " SELECT * FROM `order_".self::$suffix."` WHERE id =".$id." AND status in(0,3,4)";
        $data=[];
        $res = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
        if($res){
            //修改状态
            $order_sql = "UPDATE `order_".self::$suffix."` set `status`=:status, `desc`=:desc WHERE id=:id";
            $order_data = array(
                ':id'     => $id,
                ':desc'   => $desc,
                ':status' => $status,
            );
            $order_res = $this->dao->conn(false)->noCache()->preparedSql($order_sql,$order_data)->affectedCount();
           if($order_res){
               $this->dao->clearTag(self::$cache_tag);
           }
            return $order_res;
        }
        return false;
    }

    /**
     * @desc    根据通道流水订单号获取订单
     */
    public function getOrderByExternalId($externalld){
        $sql  = 'SELECT * FROM `order_'.self::$suffix.'` WHERE `externalld`=:externalld';
        $data = array(
            ':externalld' => $externalld
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc 一键还款回调
     * @param    array    $data    回调返回数据
     * @return   boolean  $return  返回执行结果
     * */
    public function oneKeyCallBackField($data){
        $time = time();
        if($data['status'] == 1){
            if($data['play_status'] == 3){
                $play_money_sql = "INSERT INTO `order_play_money` (`channel_id`,`play_money_no`,`order_no`,`uid`,`amount`,`status`,`collection_time`,`create_time`,`rate`,`after_amount`,`type`) VALUES(:channel_id,:play_money_no,:order_no,:uid,:amount,:status,:collection_time,:create_time,:rate,:after_amount,:type)";
                $play_data = array(
                    ':channel_id' => $data['channel_id'],
                    ':play_money_no' => $data['orderId'],
                    ':order_no' => $data['order_id'],
                    ':uid' => $data['uid'],
                    ':amount' => $data['pay_amount'],
                    ':after_amount' => $data['after_amount'],
                    ':rate' => $data['rate'],
                    ':collection_time' => strtotime($data['paytime']),
                    ':create_time' => $time,
                    ':status' => $data['play_status'],
                    ':type' => 1
                );
                $play_result= $this->dao->conn(false)->noCache()->preparedSql($play_money_sql, $play_data)->lastInsertId();
                if($play_result){
                    $sql = "UPDATE `order_" . self::$suffix . "` SET ";
                    $sql .= "`status`=:status, `pay_time`=:pay_time";
                    $sql .= "  WHERE `order_id`=:order_id ";
                    $data = array(
                        ':status'   => 3,
                        ':pay_time' => $time,
                        ':order_id' => $data['order_id']
                    );
                    $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
                    $this->dao->clearTag(self::$cache_tag);
                }
                return $play_result;
            }else {

                $this->dao->conn(false)->beginTransaction();
                $play_money_sql = "INSERT INTO `order_play_money` (`channel_id`,`play_money_no`,`serial_no`,`order_no`,`uid`,`amount`,`status`,`collection_time`,`create_time`,`rate`,`after_amount`) VALUES(:channel_id,:play_money_no,:serial_no,:order_no,:uid,:amount,:status,:collection_time,:create_time,:rate,:after_amount)";
                $play_data = array(
                    ':channel_id' => $data['channel_id'],
                    ':play_money_no' => $data['orderId'],
                    ':order_no' => $data['order_id'],
                    ':uid' => $data['uid'],
                    ':amount' => $data['pay_amount'],
                    ':after_amount' => $data['after_amount'],
                    ':rate' => $data['rate'],
                    ':collection_time' => $data['paytime'],
                    ':create_time' => $time,
                    ':status' => $data['play_status'],
                    ':serial_no' => $data['orderId'],
                );

                $play_result = $this->dao->noCache()->preparedSql($play_money_sql, $play_data)->lastInsertId();
                if (!$play_result) {
                    $this->dao->rollback();
                    return false;
                }

                $sql = "UPDATE `order_" . self::$suffix . "` SET ";
                $sql .= "`fee` =:fee ,`status`=:status ,`actual_amount`=:actual_amount ,`pay_time`=:pay_time ";
                $sql .= "  WHERE `order_id`=:order_id ";
                $data = array(
                    ':fee' => $data['fee'],
                    ':status' => $data['status'],
                    ':actual_amount' => $data['after_amount'],
                    ':pay_time' => $data['paytime'],
                    ':order_id' => $data['order_id'],
                );
                $order_result = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
                if (!$order_result) {
                    $this->dao->rollback();
                    return false;
                }
                $res = $this->dao->commit();
                if ($res) {
                    $this->dao->clearTag(self::$cache_tag);
                }
                return $res;
            }
        }else{
            $order_sql = "UPDATE `order_" . self::$suffix . "` set `status`=:status,`desc`=:desc WHERE id=:id";
            $order_data = array(
                ':status' => $data['status'],
                ':desc' => "子订单【" . $data['order_id'] . "】执行失败，" . $data['msg'],
                ':id' => $data['oid']
            );
            $res =  $this->dao->conn(false)->noCache()->preparedSql($order_sql, $order_data)->affectedCount();
            if ($res) {
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        }
    }

    /**
     * @desc 雅酷一键还款支付回调
     * @param    array    $data    回调返回数据
     * @return   boolean  $return  返回执行结果
     * */
    public function yakuOneKeyCallBackField($status, $order_index, $callback_data){
        $order_obj = XbLib_RepaymentObjs_Order::getInstance()->userCreatePayOrder($order_index);
        if (!$order_obj instanceof XbLib_RepaymentObjs_Order) {
            return $order_obj;
        }

        if($status == 1){
            //支付成功
            if ($order_obj->order['status'] != 0){
                //已调用代付

            }else{
                //发起代付
                $res_withdraw = XbLib_Repayment_Channel::getInstance()->settlement($order_obj->channel->channel_id,$order_obj);

                if ($res_withdraw['success']){
                    $play_money_sql = "INSERT INTO `order_play_money` (`channel_id`,`play_money_no`,`order_no`,`uid`,`amount`,`status`,`collection_time`,`create_time`,`rate`,`after_amount`,`type`) VALUES(:channel_id,:play_money_no,:order_no,:uid,:amount,:status,:collection_time,:create_time,:rate,:after_amount,:type)";
                    $play_data = array(
                        ':channel_id'    => $order_obj->order['channel_id'],
                        ':play_money_no' => $order_obj->param['order_id'],
                        ':order_no'      => $order_obj->order['order_id'],
                        ':uid'           => $order_obj->order['uid'],
                        ':amount'        => $order_obj->order['amount'],
                        ':after_amount'  => $order_obj->order['custom_amount'],
                        ':rate'          => $order_obj->order['rate'],
                        ':collection_time' => $callback_data['pay_time'],
                        ':create_time'   => $order_obj->param['time'],
                        ':status'        => 0,
                        ':type' => 1
                    );
                    $play_result= $this->dao->conn(false)->noCache()->preparedSql($play_money_sql, $play_data)->lastInsertId();
                    $order_data = array(
                        ':status'   => 3,
                        ':pay_time' => $callback_data['pay_time'],
                        ':actual_amount' => $order_obj->order['custom_amount'],
                        ':fee'      => $order_obj->param['fee'],
                        ':desc'     => '',
                        ':order_id' => $order_obj->order['order_id'],
                    );
                }
            }
        }else{
            //支付失败
            $order_data = array(
                ':status'   => 2,
                ':pay_time' => $callback_data['pay_time'],
                ':actual_amount' => 0,
                ':fee'      => 0,
                ':desc'     => "子订单【" . $order_obj->order['order_id'] . "】执行失败，" . $callback_data['msg'],
                ':order_id' => $order_obj->order['order_id'],
            );
        }

        if ($order_data) {
            $sql = "UPDATE `order_" . self::$suffix . "` SET `status`=:status, `pay_time`=:pay_time, `actual_amount`=:actual_amount, `fee`=:fee, `desc`=:desc  WHERE `order_id`=:order_id ";
            $this->dao->conn(false)->noCache()->preparedSql($sql, $order_data)->affectedCount();
            $this->dao->clearTag(self::$cache_tag);
        }

        return $play_result;
    }
    /**
     * @desc 雅酷一键还款代付回调
     * */
    public function yakuOneKeyCallBackSettlement($status, $order_index, $order_play, $callback_data){
        $order_obj = XbLib_RepaymentObjs_Order::getInstance()->userFinishOrder($status, $order_index, $order_play);
        if (!$order_obj instanceof XbLib_RepaymentObjs_Order) {
            return $order_obj;
        }

        $order_sql = "UPDATE `order_" . self::$suffix . "` SET `status`=:status  WHERE `order_id`=:order_id ";
        $order_param[':status'] = $order_obj->param['order_data']['status'];
        $order_param[':order_id'] = $order_obj->order['order_id'];
        $res_order = $this->dao->conn(false)->noCache()->preparedSql($order_sql, $order_param)->affectedCount();

        $play_sql = "UPDATE `order_play_money` SET `status`=:status  WHERE `order_no`=:order_no ";
        $play_param[':status'] = $order_obj->param['play_data']['status'];
        $play_param[':order_no'] = $order_obj->order['order_id'];
        $res_play = $this->dao->conn(false)->noCache()->preparedSql($play_sql, $play_param)->affectedCount();
        $this->dao->clearTag(self::$cache_tag);
        //支付成功修改分润信息
        XbModule_Repayment_Order::getInstance(self::$suffix)->synOrderProfit($order_obj->order['id'],$order_obj->user->uid,$order_obj->order['custom_amount'],$order_obj->order['order_id']);

        return $res_play;
    }
    /**
     * @desc 智能还款回调
     * @param    array    $data    回调返回数据
     * @return   boolean  $return  返回执行结果
     * */
    public function intelCallBackField($data){
        //$time = time();
        if ($data['status'] == 1) {
            $sql = "UPDATE `order_plan_" . self::$suffix . "` SET ";
            $sql .= "  `fee`=:fee, `status`=:status, `real_status`=:real_status, `actual_amount`=:actual_amount ";
            $sql .= "  WHERE `order_id`=:order_id ";
            $plandata = array(
                ':fee'           => $data['fee'],
                ':status'        => $data['status'],
                ':real_status'   => 4,
                ':actual_amount' => $data['after_amount'],
                ':order_id'      => $data['order_id'],
            );
            $res =  $this->dao->conn(false)->noCache()->preparedSql($sql, $plandata)->affectedCount();
            if ($res) {
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;

        } else {
            $this->dao->conn(false)->beginTransaction();
            $sql = "UPDATE `order_plan_" . self::$suffix . "` SET ";
            $sql .= " `status`=:status, `real_status`=:real_status ";
            $sql .= "  WHERE `order_id`=:order_id ";
            $plandata = array(
                ':status'      => $data['status'],
                ':real_status' => 3,
                ':order_id'    => $data['order_id'],
            );
            $res = $this->dao->noCache()->preparedSql($sql, $plandata)->affectedCount();
            if (!$res) {
                $this->dao->rollback();
                return false;
            }
            $order_sql = "UPDATE `order_" . self::$suffix . "` set `status`=:status,`desc`=:desc WHERE id=:id";
            $order_data = array(
                ':status' => 6,
                ':desc' => "子订单【" . $data['order_id'] . "】执行失败，" . $data['msg'],
                ':id' => $data['oid']
            );
            $order_res = $this->dao->noCache()->preparedSql($order_sql, $order_data)->affectedCount();
            if (!$order_res) {
                $this->dao->rollback();
                return false;
            }
            $result = $this->dao->commit();
            if ($result) {
                $this->dao->clearTag(self::$cache_tag);
            }
            return $result;
        }
    }
    /**
     * @desc 拉取订单结算状态
     * */
    public function settCallBackField($data){
        if($data['play_status'] == 1){
            $this->dao->conn(false)->beginTransaction();
            $play_money_sql = "UPDATE  `order_play_money` set `serial_no`=:serial_no,`status`=:status WHERE `play_money_no`=:play_money_no ";
            $play_data = array(
                ':play_money_no' => $data['order_no'],
                ':status' => $data['status'],
                ':serial_no' => $data['serial_no'],
            );
            $play_result = $this->dao->noCache()->preparedSql($play_money_sql, $play_data)->affectedCount();
            if (!$play_result) {
                $this->dao->rollback();
                return false;
            }

            $sql = "UPDATE `order_" . self::$suffix . "` SET ";
            $sql .= "`fee` =:fee ,`status`=:status ,`actual_amount`=:actual_amount ,`pay_time`=:pay_time ";
            $sql .= "  WHERE `order_id`=:order_id ";
            $data = array(
                ':fee' => $data['fee'],
                ':status' => $data['status'],
                ':actual_amount' => $data['after_amount'],
                ':pay_time' => $data['paytime'],
                ':order_id' => $data['order_id'],
            );
            $order_result = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
            if (!$order_result) {
                $this->dao->rollback();
                return false;
            }
            $res = $this->dao->commit();
            if ($res) {
                $this->dao->clearTag(self::$cache_tag);
            }
            return $res;
        }else{
            return false;
        }
        return false;

    }
    /**
     * @desc    统计用户正在执行中的计划数量
     * @param   int     $uid            用户id
     * @param   int     $cardNumber     信用卡卡号
     * @return  array   $return         返回统计数量
     */
    public function countUserPlanOrder($uid, $cardNumber){
        $sql = 'SELECT COUNT(*) as num FROM `order_' . self::$suffix . '` WHERE `uid`=:uid AND `type`=:type AND `status` in (0, 4) AND `paycard_number`=:paycard_number';
        $data = array(
            ':uid'            => $uid,
            ':type'           => 2,
            ':paycard_number' => $cardNumber
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }
    /**
     * @desc 脚本 获取未支付订单
     * */
    public function getPlayOrderByStatus($status, $type, $limit, $num, $time)
    {
        $sql = "SELECT * FROM `order_play_money` WHERE `status`=:status AND `create_time`<=:end_time AND `type`=:type ORDER BY id ASC limit " . $limit .','. $num;
        $data = array(
            ':status'   => $status,
            ':type'     => $type,
            ':end_time' => $time
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchAll();
    }
    /**
     * @desc 获取打款订单
     * */
    public function getPlayOrderByPlayNo($play_money_no)
    {
        $sql = "SELECT * FROM `order_play_money` WHERE `play_money_no`=:play_money_no ";
        $data = array(
            ':play_money_no'   => $play_money_no,
        );
        return $this->dao->conn()->noCache()->preparedSql($sql, $data)->fetchOne();
    }

    /*
     * @desc    获取还款信用卡执行计划 ----订单计划脚本专用
     */
    public function scriptOrderPlan($startTime, $endTime, $limit, $num){
        $sql = 'SELECT * FROM `order_plan_' . self::$suffix . '` WHERE `pay_time`>=:startTime AND `pay_time`<:endTime LIMIT :limit, :num';
        $data = array(
            ':startTime' => $startTime,
            ':endTime'   => $endTime,
            ':limit'     => $limit,
            ':num'       => $num
        );
        return $this->dao->conn(false)->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchAll();
    }

    /**
     * @desc    智能还款刷卡
     */
    public function orderPlanTrans($id, $channel_id, $channel_name, $trans_data, $oid=false, $order_obj=''){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        if($oid){
            $sql = 'UPDATE `order_' . self::$suffix . '` SET `status`=:status WHERE `id`=:id';
            $data = array(
                ':status' => 4,
                ':id'     => $oid
            );
            $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
            if(!$res){
                $this->dao->rollback();
                return false;
            }
        }

        $sql = 'UPDATE `order_plan_' . self::$suffix . '` SET `real_status`=:real_status, `channel_id`=:channel_id, `channel_name`=:channel_name WHERE `id`=:id';
        $data = array(
            ':real_status'  => 1,
            ':channel_id'   => $channel_id,
            ':channel_name' => $channel_name,
            ':id'           => $id
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->affectedCount();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        $transOrder = XbLib_Repayment_Channel::getInstance()->createOrder($channel_id, $order_obj);
        if(!$transOrder['success']){
            $this->dao->rollback();
            return false;
        }
        $res = $this->dao->commit();
        if($res){
            try {
                if (!$oid){
                    $pre_order_plan = XbModule_Repayment_Order::getInstance(self::$suffix)->getOrderByIssue($trans_data['oid'], $trans_data['issue']-1, 1);
                    //支付成功修改分润信息(上一期)
                    $res_profit_update = XbModule_Repayment_Order::getInstance(self::$suffix)->synOrderProfit($pre_order_plan['id'],$pre_order_plan['uid'],$pre_order_plan['amount'],$pre_order_plan['order_id'],0,1);
                }
                //支付下单创建分润信息
                $res_profit_create = XbInterface_Repayment_Repayment::getInstance()->createProfit($trans_data['order_id'],self::$suffix,$trans_data['amount'],$channel_id,$order_obj->user->uid,1);
            } catch ( Exception $e ) {
                XbFunc_Log::write('repaymentProfitError', '修改上一期分润或创建本期分润信息错误',$e->getMessage());
            }
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    智能还款失败处理
     */
    public function orderPlanExecFail($oid, $planId, $desc,  $realStatus=2){
        $sql = 'UPDATE `order_' . self::$suffix . '` SET `status`=:status, `desc`=:desc WHERE id=:id';
        $data = array(
            ':status' => 6,
            ':desc'   => $desc,
            ':id'     => $oid,
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }

        $sql = 'UPDATE `order_plan_' . self::$suffix . '` SET `status`=:status, `real_status`=:real_status WHERE id=:id';
        $data = array(
            ':status'      => 2,
            ':real_status' => $realStatus,
            ':id'          => $planId,
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        return $res;
    }

    /*
     * @desc    根据oid以及issue查找计划详情
     */
    public function getOrderByIssue($oid, $issue, $planType){
        $sql = 'SELECT * FROM `order_plan_' . self::$suffix . '` WHERE `oid`=:oid AND `issue`=:issue AND `plan_type`=:plan_type';
        $data = array(
            ':oid'       => $oid,
            ':issue'     => $issue,
            ':plan_type' => $planType
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, $data)->fetchOne();
    }

    /**
     * @desc    订单计划结算
     */
    public function orderPlanWithdraw($planInfo, $channel_id, $channel_name, $withdrawData, $order_obj=''){
        $time = time();
        $this->dao->conn(false)->beginTransaction();
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        //体现订单号必须是18位
        $order_id = substr($order_id, 0, 18);
        $sql = 'INSERT INTO `order_plan_'.self::$suffix.'`(`oid`, `order_id`, `uid`, `issue`, `amount`, `single_fee`, `sett_type`, `sett_amount`, `sett_fee`, `status`, `type`, `plan_type`, `pay_time`, `real_status`, `channel_id`, `channel_name`, `create_time`) VALUES(:oid, :order_id, :uid, :issue, :amount, :single_fee, :sett_type, :sett_amount, :sett_fee, :status, :type, :plan_type, :pay_time, :real_status, :channel_id, :channel_name, :create_time)';
        $data = array(
            ':oid'          => $planInfo['oid'],
            ':order_id'     => $order_id,
            ':uid'          => $planInfo['uid'],
            ':issue'        => $planInfo['issue'],
            ':amount'       => $withdrawData['amount'],     //todo
            ':single_fee'   => $withdrawData['fee'],
            ':sett_type'    => $planInfo['sett_type'],
            ':sett_amount'  => $withdrawData['amount'],     //todo
            ':sett_fee'     => $withdrawData['fee'],
            ':status'       => 3,
            ':type'         => $planInfo['type'],
            ':plan_type'    => 2,
            ':pay_time'     => $time,
            ':real_status'  => 1,
            ':channel_id'   => $channel_id,
            ':channel_name' => $channel_name,
            ':create_time'  => $time
        );
        $res = $this->dao->noCache()->preparedSql($sql, $data)->lastInsertId();
        if(!$res){
            $this->dao->rollback();
            return false;
        }

        $order_obj->param['order_id'] = $order_id;
        $transOrder = XbLib_Repayment_Channel::getInstance()->settlement($channel_id, $order_obj);
        /*if(!$transOrder){
            $this->dao->rollback();
            return false;
        }*/
        $res = $this->dao->commit();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }

    /**
     * @desc    修改提现订单状态
     */
    public function updateWithdrawOrderStatus($id, $status){
        if($status == 1) $realStatus = 4;
        if($status == 2) $realStatus = 3;
        $sql = 'UPDATE `order_plan_'.self::$suffix.'` SET `status`=:status, `real_status`=:real_status WHERE `id`=:id';
        $data = array(
            ':status'      => $status,
            ':real_status' => $realStatus,
            ':id'          => $id
        );
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
        if($res){
            $this->dao->clearTag(self::$cache_tag);
        }
        return $res;
    }
    /**
     * @desc    同步订单反润，修改订单数据，transaction处理
     * @param   string      $order_id       订单号
     * @param   array       $profit         分润数据
     * @param   float       $profit_rate    分润最低费率
     * @param   int         $is_profit      是否更新分润订单，0未更新，1已更新，2没有分润信息
     * @return  boolen      $return         执行结果
     */
    public function synOrderProfit($order_no, $profit, $is_profit,$parent_order_no,$type){
        $time = time();
        if($is_profit == 1){
            $sql = 'INSERT INTO `xb_account`.`profit_'.self::$suffix.'`(`uid`, `order_id`, `reference_no`, `from_uid`, `rate`, `amount`, `created_at`, `create_time`,`money`,`is_plan`) VALUES';
            $data = array();
            foreach($profit as $k=>$v){
                $sql .= "(:uid{$k}, :order_id{$k}, :reference_no{$k}, :from_uid{$k}, :rate{$k}, :amount{$k}, :created_at{$k}, :create_time{$k}, :money{$k} ,:is_plan{$k}),";
                $data[":uid{$k}"]          = $v['uid'];
                $data[":order_id{$k}"]     = $v['order_id'];
                $data[":reference_no{$k}"] = $v['reference_no'];
                $data[":from_uid{$k}"]     = $v['from_uid'];
                $data[":rate{$k}"]         = $v['rate'];
                $data[":money{$k}"]        = $v['money'];
                $data[":amount{$k}"]       = bcadd($v['amount'],$v['money'],2);
                $data[":created_at{$k}"]   = $time;
                $data[":create_time{$k}"]  = $time;
                $data[":is_plan{$k}"]      = $v['is_plan'];
            }
            $sql = trim($sql, ',');
            $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
            if(!$res){
                return false;
            }
            if($type){
                //智能还款
                $sql_plan = 'UPDATE '.'order_plan_'.self::$suffix.' SET  `is_profit`=:is_profit WHERE `order_id`=:order_id';
                $data_plan = array(
                    ':is_profit'   => $is_profit,
                    ':order_id'    => $order_no
                );
                $plan_res = $this->dao->conn(false)->noCache()->preparedSql($sql_plan, $data_plan)->affectedCount();
                if(!$plan_res){
                    return false;
                }
            } else {
                //一键还款
                $sql = 'UPDATE '. 'order_'.self::$suffix . ' SET  `is_profit`=:is_profit WHERE `order_id`=:order_id';
                $data = array(
                    ':is_profit'   => $is_profit,
                    ':order_id'    => $order_no
                );
                $onekey_res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->affectedCount();
                if(!$onekey_res){
                    return false;
                }
            }
            $this->dao->clearTag(self::$cache_tag);
            $this->dao->clearTag('Account_Users_Profit_');
            return $res;
        }
        return false;
    }
}