<?php

class XbModel_Act_ActivityData extends XbModel_BaseModel {
    public static $cache_tag = "Act_Activity_Data_";
    
    public static $cache_expire = 259200;
    
    
    public function __construct() {
        parent::_init("xb_act");
    }
    
    public function set($key, $name, $val) {
        return XbLib_Redis_Hash::hSet($key, $name, $val);
    }
    
    public function get($key, $name) {
        return XbLib_Redis_Hash::hGet($key, $name);
    }
    
    public function getAll($key) {
        return XbLib_Redis_Hash::hGetAll($key);
    }
    
    public function incr($key, $name, $step = 1) {
        return XbLib_Redis_Hash::hIncrby($key, $name, $step);
    }
}