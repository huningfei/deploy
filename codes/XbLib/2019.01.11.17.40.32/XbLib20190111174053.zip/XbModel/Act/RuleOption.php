<?php

class XbModel_Act_RuleOption extends XbModel_BaseModel {
    public static $cache_tag = "Act_Rule_Option_";
    
    public static $cache_expire = 259200;
    
    public function __construct() {
        parent::_init("xb_act");
    }
    
    /**
     * 增加
     * 
     * @param unknown $rule_id
     * @param unknown $target
     * @param unknown $target_attr
     * @param unknown $target_type
     * @param unknown $op
     * @param unknown $value
     * @return boolean|string
     */
    public function add($rule_id, $target, $target_attr, $target_type, $op, $value) {
        $sql = 'INSERT INTO `rule_option` (`rule_id`, `target`, `target_attr`, `target_type`, `op`, `value`) VALUES 
            (:rule_id, :target, :target_attr, :target_type, :op, :value)';
        
        $data = [
            ':rule_id' => $rule_id, 
            ':target' => $target, 
            ':target_attr' => $target_attr, 
            ':target_type' => $target_type, 
            ':op' => $op, 
            ':value' => $value
        ];
        
        $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        
        if ($id)
            $this->dao->clearTag(self::$cache_tag);
        
        return $id ? $id : false;
    }
    
    /**
     * 编辑
     * 
     * @param unknown $id
     * @param unknown $rule_id
     * @param unknown $target
     * @param unknown $target_attr
     * @param unknown $target_type
     * @param unknown $op
     * @param unknown $value
     * @return boolean
     */
    public function edit($id, $rule_id = null, $target = null, $target_attr = null, $target_type = null, $op = null, $value = null) {
        $sql = 'UPDATE `rule_option` SET ';
        $data = [];
        $update = [];
        
        if ($rule_id !== null) {
            $update[] = '`rule_id` = :rule_id ';
            $data[':rule_id'] = $rule_id;
        }
        
        if ($target !== null) {
            $update[] = '`target` = :target ';
            $data[':target'] = $target;
        }
        
        if ($target_attr !== null) {
            $update[] = '`target_attr` = :target_attr ';
            $data[':target_attr'] = $target_attr;
        }
        
        if ($target_type !== null) {
            $update[] = '`target_type` = :target_type ';
            $data[':target_type'] = $target_type;
        }
        
        if ($op !== null) {
            $update[] = '`op` = :op ';
            $data[':op'] = $op;
        }
        
        if ($value !== null) {
            $update[] = '`value` = :value ';
            $data[':value'] = $value;
        }
        
        if (!$update) return false;
        
        $sql .= implode(',', $update) . ' WHERE id = :id';
        $data[':id'] = $id;
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($res)
            $this->dao->clearTag(self::$cache_tag);
        
        return $res ? $res : false;
    }
    
    /**
     * 显示规则选项
     * 
     * @param unknown $id
     * @return array|multitype:
     */
    public function listOptionByRuleId($id) {
        $id = (int)$id;
        $sql = 'SELECT * FROM `rule_option` WHERE rule_id = ' . $id;
        
        $data = $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql, [])->fetchAll();
        
        return $data ? $data : [];
    }
    
    public function deleteByRuleId($rule_id) {
        $sql = 'DELETE FROM `rule_option` WHERE rule_id = :rule_id';
        $data = [
            ':rule_id' => $rule_id,
        ];
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($res)
            $this->dao->clearTag(self::$cache_tag);
            
        return $res ? $res : false;
    }
    
    /**
     * 删除
     * 
     * @param unknown $rule_id
     * @param unknown $target
     * @param unknown $target_attr
     * @return boolean
     */
    public function delete($rule_id, $target, $target_attr) {
        $sql = 'DELETE FROM `rule_option` WHERE rule_id = :rule_id AND target = :target AND target_attr = :target_attr';
        $data = [
            ':rule_id' => $rule_id,
            ':target' => $target, 
            ':target_attr' => $target_attr
        ];
        
        $res = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->excute();
        
        if ($res)
            $this->dao->clearTag(self::$cache_tag);
        
        return $res ? $res : false;
    }
}