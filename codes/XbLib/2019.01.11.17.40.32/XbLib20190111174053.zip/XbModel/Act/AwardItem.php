<?php
/**
 * @desc  用户奖励管理
 * User: yr
 * Date: 4/8/18
 * Time: 15:33
 */
class XbModel_Act_AwardItem extends XbModel_BaseModel
{
    static $cache_tag = "Act_Award_Item_";

    //链接库
    function __construct()
    {
        parent::_init("xb_act");
    }
    /**
     * @desc 获取用户单条奖励
     * @param    string    $order_id   订单ID
     * @param    int       $uid        用户ID
     * @return   array     $return     返回执行结果
     * */
    public function getUserAwardByOrderId($order_id,$uid){
        $sql = "SELECT * FROM `award_item` WHERE `order_no`=:order_no AND `uid`=:uid";
        $data =array(
            ':order_no' => $order_id,
            ':uid'      => $uid,
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
    /**
     * @desc 获取用户奖励
     * @param   int                      $uid    用户ID
     * @param   int                      $status 红包领取状态
     * @return  array|multitype:|array   $array  返回执行结果
     * */
    public function getAward($uid){
        $sql = "SELECT i.*,a.title,a.award_type FROM `award_item` i LEFT JOIN `award` a ON i.award_id = a.id WHERE `uid`=:uid";
        $data = array(
            ':uid' => $uid
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchAll();
    }
    /**
     * @h获取所有未领取的红包
     * @param     int                       $status     红包使用状态
     * @return   array|multitype:|array     $return     返回执行结果
     * */
    public function getAwardList($status){
        $sql = "SELECT i.*,a.title,a.act_type FROM `award_item` i LEFT JOIN `award` a ON i.award_id = a.id WHERE `item_state`=:status ";
        $data = array(
            ':status' => $status
        );
        return $this->dao->conn()->noCache()->preparedSql($sql,$data)->fetchAll();
    }

    /**
     * @desc 获取用户奖励
     * @param   int     $id     item_id
     * @param   array   $array  返回执行结果
     * */
    public function getAwardByItemId($item_id){
        $sql = "SELECT i.*,a.title,a.award_type,a.act_type FROM `award_item` i LEFT JOIN `award` a ON i.award_id = a.id WHERE i.id=:item_id";
        $data = array(
            ':item_id' => $item_id
        );
        return $this->dao->conn()->setTag(self::$cache_tag)->preparedSql($sql,$data)->fetchOne();
    }
}