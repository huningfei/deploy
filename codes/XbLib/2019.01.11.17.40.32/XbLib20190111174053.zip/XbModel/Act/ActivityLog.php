<?php

class XbModel_Act_ActivityLog extends XbModel_BaseModel {
    public static $cache_tag = "Act_Activity_Log_";
    
    public static $cache_expire = 259200;
    
    
    public function __construct() {
        parent::_init("xb_act");
    }
    
    /**
     * 插入接口调用日志
     * 
     * @param unknown $activity_id
     * @param unknown $user_id
     * @param unknown $order_id
     * @param unknown $params
     * @param number $api_id
     * @param number $status
     * @return boolean|string
     */
    public function add($activity_id, $user_id, $order_id, $params, $api_id = 1, $status = 1) {
        $sql = "INSERT INTO `activity_log` (`activity_id`, `user_id`, `status`, `order_id`, `params`, `api_id`) VALUES 
                (:activity_id, :user_id, :status, :order_id, :params, :api_id)";
        
        $data = [
            ':activity_id' => $activity_id, 
            ':user_id' => $user_id, 
            ':status' => $status, 
            ':order_id' => $order_id, 
            ':params' => serialize($params), 
            ':api_id' => $api_id
        ];
        
        $id = $this->dao->conn(false)->noCache()->preparedSql($sql, $data)->lastInsertId();
        return $id ? $id : false;
    }
}
    