<?php
/**
 * @desc    返现接口
 * @author  qien
 * @date    18.06.12
 */
class XbInterface_Profit_Profit extends XbInterface_InterfaceBase{
    private static $obj = null;

    public function __construct(){
        $this->_init();
    }

    /**
     * 单例
     * @return null|XbInterface_Profit_Profit
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbInterface_Profit_Profit();
        }
        return self::$obj;
    }
    /**
     * @desc 返现明细
     * */
    public function profitInfo($user){
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($user['id']);
        //获取用户余额
        $user_wallet = XbModule_Account_Profit::getInstance($user['mch_id'])->getPrefitAmountByUid($user['id']);
        $res['balance']  = $user_wallet['profit_amount']?$user_wallet['profit_amount']:'0.00';
        $res['note']     = '金额超过50元可提现，提现费2元/笔';
        $res['bankInfo'] = $profile['bank'].'(***'.substr($profile['bankcardNumber'],-4).')';
        return $res;
    }
   /**
    * @desc 获取返现明细
    * */
   public function profitList($user,$page){
       $limit = 10;
       $start = ($page -1)*10;
       $profitInfo = XbModule_Account_Profit::getInstance($user['mch_id'])->getProfitByUid($user['id'], $start, $limit);
       $res = array();
       $all_amount = 0;
       if($profitInfo){
           foreach($profitInfo as $v){
               $detail = array();
               $detail['amount'] = ($v['type'] == 2 ? '-' : '+').$v['amount'];
                if($v['type']==1){
                    $desc = '邀请返现奖励';
                }elseif($v['type'] == 2){
                    $desc = '账户提现';
                }else{
                    $desc = $v['title'].'红包';
                }
               $detail['desc']   = $desc;
               $detail['date']   = date('Y-m-d H:i:s', $v['created_at']);
               $detail['type']   = $v['type'];
               $detail['status']   = $v['status'];
               $detail['orderId']   = $v['order_id'];
               $all_amount += $v['amount'];
               $res['list'][] = $detail;
           }
       }
       $res['all_amount'] = $all_amount;
       $res['num'] = XbModule_Account_Profit::getInstance($user['mch_id'])->countProfitByUid($user['id']);
       return $res;
   }


    /**
     * @desc    获取用户分润详情
     */
    public function getProfitDetail($uid, $orderId, $type){
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        if(!$user){
            return new XbLib_WebError(4108);
        }
        if($type == 2){
            return new XbLib_WebError(5107);
        }
        $profit = XbModule_Account_Profit::getInstance($user['mch_id'])->getProfitByOrderId($orderId);
        if(!$profit || $profit['uid'] != $uid){
            return new XbLib_WebError(5107);
        }
        $type = XbLib_Var::$profitType;
        $res = array(
            'orderId' => $profit['order_id'],
            'date'    => date('Y-m-d H:i:s', $profit['create_time']),
            'profit'  => $profit['amount'],
            'amount'  => $profit['amount'],
            'type'    => $profit['title'] ? $profit['title'] : (isset($type[$profit['type']]) ? $type[$profit['type']] : '')
        );
        return $res;
    }

    /**
     * @desc    获取用户提现详情
     */
    public function getWithdrawCashDetail($uid, $orderId, $type){
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        if(!$user){
            return new XbLib_WebError(4108);
        }
        if($type != 2){
            return new XbLib_WebError(5107);
        }
        $profit = XbModule_Account_Profit::getInstance($user['mch_id'])->getProfitByOrderId($orderId);
        if(!$profit || $profit['uid'] != $uid){
            return new XbLib_WebError(5107);
        }
        $withDrawInfo = XbModule_Account_Profit::getInstance($user['mch_id'])->getWithdrawByOrderId($orderId);
        if(!$withDrawInfo || $withDrawInfo['uid'] != $uid){
            return new XbLib_WebError(5107);
        }
        $res = array(
            'orderId'        => $profit['order_id'],
            'date'           => date('Y-m-d H:i:s', $profit['create_time']),
            'withdrawAmount' => number_format($profit['amount'], 2, '.', ''),
            'singleFee'      => 2,
            'intoAccount'    => number_format(bcsub($profit['amount'], 2, 2), 2, '.', ''),
            'bankcardNumber' => substr($withDrawInfo['bankcardNumber'], -4),
            'amount'         => $profit['amount'],
            'status'         => $profit['status'],
            'payDate'        => $profit['pay_time'] ? date('Y-m-d H:i:s', $profit['pay_time']) : '',
            'desc'           => $withDrawInfo['desc']
        );
        return $res;
    }

    /**
     * @desc    生成提现批次
     */
    public function buildWithdrawBatch($hour, $type, $number, $logInfo){
        $time = strtotime(date("Y-m-d {$hour}:00:00"));
        if($type == 1) $number = 1000;
        $count = XbModule_Account_Profit::getInstance(0)->countWithdrawCash(0, $time);
        if($count == 0){
            return new XbLib_WebError(401, '此批次节点之前没有没有新提现订单！');
        }
        if($type == 2 && $count < $number){
            return new XbLib_WebError(401, '当前批次节点限定笔数不能大于'.$count.'笔');
        }
        if($count){
            $batchNum = ceil($count/$number);
            for($i = 0; $i < $batchNum; $i++){
                if($count <= $number) $number = $count;
                $res = XbModule_Account_Profit::getInstance(0)->createWithdrawBatch($number, $time, $logInfo);
                if(!$res){
                    return new XbLib_WebError(401, '部分批次创建成功，剩余请从新提交创建！');
                }
                $count -= $number;
            }
        }
        return true;
    }
}
