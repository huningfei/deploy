<?php
/**
 * @desc    信用卡接口文件
 * @author  qien
 * @date    18.04.15
 */
class XbInterface_Repayment_Repayment extends XbInterface_InterfaceBase{
    private static $obj = null;

    public function __construct(){
        $this->_init();
    }

    /**
     * 单例
     * @return null|XbInterface_Repayment_Repayment
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbInterface_Repayment_Repayment();
        }
        return self::$obj;
    }

    /**
     * @desc    获取用户还款信用卡list
     */
    public function getRepaymentCard($uid){
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getRepaymentCreditCard($uid, 1);
        $res['cardInfo'] = array();
        if($cardInfo){
            foreach($cardInfo as $k=>$v){
                $detail = array();
                $detail['cid']           = $v['id'];
                $detail['cardBank']      = $v['bank'];
                $detail['cardNumber']    = mb_substr($v['cardNumber'], -4);
                $detail['realname']      = mb_substr($profile['realname'],-1);
                $detail['accountLimit']  = number_format($v['amountLimit'], 2, '.', '');
                $detail['statementDate'] = $v['billDate'];
                $detail['paymentDate']   = $v['payDate'];
                $detail['logo']          = $this->getBankImg($v['bankCode']);
                $res['cardInfo'][]       = $detail;
            }
        }
        return $res;
    }

    /**
     * @desc    信用卡还款主页
     */
    public function index($uid, $cid){
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if($cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if(!$cardInfo || $cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        $res = array(
            'cid'           => $cardInfo['id'],
            'cardBank'      => $cardInfo['bank'],
            'cardNumber'    => mb_substr($cardInfo['cardNumber'], -4),
            'cardNum'       => mb_substr($cardInfo['cardNumber'], 0, 6).'********'.mb_substr($cardInfo['cardNumber'], -4),
            'realname'      => mb_substr($profile['realname'],-1),
            'accountLimit'  => number_format($cardInfo['amountLimit'], 2, '.', ''),
            'statementDate' => $cardInfo['billDate'],
            'paymentDate'   => $cardInfo['payDate'],
            'logo'          => $this->getBankImg($cardInfo['bankCode']),
        );
        return $res;
    }

    /*
     * @desc    一键还款首页
     * @param   int     $uid        用户id
     * @param   int     $cid        信用卡id
     * @return  array   $res
     */
    public function commonRp($uid, $cid){
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if($cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if(!$cardInfo || $cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        $userLevel = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $rate = XbModule_Account_Level::getInstance()->getLevelRate($uid, $userLevel['level']);
        $res = array(
            'cid'        => $cardInfo['id'],
            'cardBank'   => $cardInfo['bank'],
            'cardNumber' => mb_substr($cardInfo['cardNumber'], -4),
            'logo'       => $this->getBankImg($cardInfo['bankCode']),
            'rate'       => bcmul($rate['repaymentfee'], 100),
        );
        return $res;
    }

    /**
     * @desc    计算手续费
     * @param   int     $uid        用户id
     * @param   int     $amount     刷卡金额
     * @return  array   $res        计算结果
     */
    public function getCommonFee($uid, $amount){
        $check = XbLib_Verify::checkInt($amount, 3, 11);
        if(!$check) return new XbLib_WebError(4302);
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        $userLevel = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $channel_id = 5;
        $rate = XbModule_Repayment_Channel::getInstance()->getChannelByChannelidLevel($channel_id, $userLevel['level']);

        $fee_format = XbLib_Repayment_ChannelFunc::getCommonFee($rate['rate'], $amount, $rate['fee']);
        $res = array(
            'fee'    => bcsub($fee_format, $amount, 2),
            'amount' => $fee_format
        );
        return $res;
    }

    /**
     * @desc    一键还款下单
     * @param   int     $uid        用户id
     * @param   int     $mch_id     用户所属代理
     * @param   int     $cid        信用卡id
     * @param   int     $amount     金额
     * @return  boolen  $return     返回创建订单结果
     */
    public function createCommonOrder($uid, $mch_id, $cid, $amount, $merchant_id){
        $channelId = 5;
        return XbModule_Repayment_Order::getInstance($mch_id)->createCommonOrder($uid, $cid, $amount, $channelId, $merchant_id);
    }
    /**
     * 还款分润处理
     */
    public function createProfit($orderId,$mch_id,$amount,$channelId=5,$uid,$type=0){
        if($orderId && $mch_id != 1){
            //汇衫用户分润
            //分润信息
            //获取用户等级
            $user_level = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
            $profitUsers = XbModule_Account_UsersInvite::getInstance()->getRepaymentProfitInfoByUid($uid, $user_level['level'],$channelId,$amount,$mch_id);
            if(count($profitUsers) > 0){
                $profitRes = XbModule_Repayment_OrderProfit::getInstance()->createProfit($profitUsers,$orderId, $mch_id,$type);
                if(!$profitRes){
                    $log = json_encode($profitUsers);
                    XbFunc_Log::write('repaymentProfitUserError','创建订单分润信息（分润用户）失败，订单表：'.XbModel_Account_Order::$suffix.'，订单id：'.$orderId, '用户信息：'.$log);
                }
            }
        }
    }

    /**
     * @desc    制定还款计划
     * @param   int     $uid            用户金额
     * @param   int     $amount         金额
     * @param   int     $cid            信用卡id
     * @param   int     $mch_id         商户id
     * @param   int     $customAmount   自定义金额
     * @return  array   $return         返回制定还款计划
     */
    public function getWisePlan($uid, $amount, $cid, $mch_id, $customAmount){
        if(!XbLib_Verify::checkInt($amount, 3, 11)) return new XbLib_WebError(4505);
        if(!$cid) return new XbLib_WebError(400);
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }

        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        if($customAmount != 0 && $customAmount < 300){
            return new XbLib_WebError(4508);
        }
        //制定计划
        $planInfo = XbLib_Repayment_WisePlan::getInstance()->makePlan($uid, $amount, $cardInfo, $mch_id, $customAmount);
        if(is_array($planInfo)){
            $res = array(
                'cid'          => $cardInfo['id'],
                'cardBank'     => $cardInfo['bank'],
                'cardNumber'   => mb_substr($cardInfo['cardNumber'], -4),
                'logo'         => $this->getBankImg($cardInfo['bankCode']),
                'amount'       => $amount,
                'customAmount' => $customAmount
            );
            foreach($planInfo as $k=>$v){
                $detail = array();
                $detail['orderId']     = $v['orderId'];
                $detail['planTime']    = count($v['planInfo']);
                $detail['amount']      = number_format($v['planInfo'][0]['amount'], 2, '.', '');
                $detail['rate']        = bcmul($v['rate'], 100);
                $detail['feeTotal']    = number_format(bcsub($v['totalAmount'], $amount), 2, '.', '');
                $detail['fee']         = number_format($v['fee'], 2, '.', '');
                $detail['totalAmount'] = number_format($v['totalAmount'], 2, '.', '');
                //$detail['amount'] = count($v[0]['amount']);
                $res['planInfo'][]     = $detail;
            }
        }else{
            $res = $planInfo;
        }
        return $res;
    }

    /*
     * @desc    获取计划详情
     */
    public function getWisePlanDetail($uid, $mch_id, $orderId){
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }

        $orderPlanDetail = XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanTmp($orderId, $uid);
        //todo 判断计划失效时间
        if(!$orderPlanDetail){
            return new XbLib_WebError(4509);
        }

        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($orderPlanDetail['cid']);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }

        $res = array(
            'orderId'    => $orderId,
            'cardBank'   => $cardInfo['bank'],
            'cardNumber' => mb_substr($cardInfo['cardNumber'], -4),
            'logo'       => $this->getBankImg($cardInfo['bankCode']),
            'amount'     => $orderPlanDetail['amount'],
            'plantime'   => $orderPlanDetail['plan_time'],
            'feeAmount'  => bcsub($orderPlanDetail['fee_total'], $orderPlanDetail['amount'])
        );
        $plandetail = json_decode($orderPlanDetail['details'], true);
        $numFormat = XbLib_Var::$numFormat;
        foreach($plandetail as $k=>$v){
            $detail = array();
            if($v['time'] == 1){
                $res['reserved'] = $v['amount'];
                $startDate = date('Y-m-d', $v['date']);
            }
            $endDate = date('Y-m-d', $v['date']);
            $detail['time']    = $numFormat[$v['time']];
            $detail['date']    = date('Y-m-d H:i:s', $v['date']);
            $feeAmount = XbLib_Repayment_ChannelFunc::getWithdrawAmount($v['amount'], $orderPlanDetail['rate'], $orderPlanDetail['fee']);
            $detail['amount']  = bcsub($v['amount'], $feeAmount);
            $res['planInfo'][] = $detail;
        }
        $res['repaymentPeriod'] = $startDate.' - '.$endDate;
        return $res;
    }

    public function createWiseOrder($uid, $mch_id, $orderId, $district_id){
        $orderPlanDetail = XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanTmp($orderId, $uid);
        $time = time() - 600;
        if(!$orderPlanDetail){
            return new XbLib_WebError(4509);
        }elseif($time > $orderPlanDetail['create_time']){
            return new XbLib_WebError(4510);
        }

        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($orderPlanDetail['cid']);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        $level    = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($uid);
        $feeTotal = bcsub($orderPlanDetail['fee_total'], $orderPlanDetail['amount']);
        $detail   = json_decode($orderPlanDetail['details'], true);
        $res = XbModule_Repayment_Order::getInstance($mch_id)->createWiseOrder($uid, $orderPlanDetail['amount'], $orderPlanDetail['fee'], $feeTotal, $level['level'], $orderPlanDetail['rate'], $orderPlanDetail['cid'], $cardInfo['cardNumber'], $cardInfo['bankCode'], $cardInfo['bank'], $profile['realname'], $orderPlanDetail['plan_time'], 1, $orderPlanDetail['type'], $detail, $district_id);
        if($res){
            $wxdata = array(
                'uid'         => $uid,
                'orderamount' => number_format($orderPlanDetail['amount'], 2, '.', '').'元',
                'date'        => date('Y-m-d H:i:s'),
                'ordernumber' => $res
            );
//            XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(7, $wxdata);
            //优化推送消息
            $res_push = XbLib_PushMsg::getInstance()->wiseRepaymentPlanSuccess($uid,array('order_no'=>$res));

        }
        return $res ? (is_string($res) ? array('orderId' => $res, 'type' => 2) : $res) : false;
    }

    public function stopWisePlan($uid, $mch_id, $orderId){
        $orderPlanDetail = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByOrderId($orderId);
        if($orderPlanDetail['uid'] != $uid){
            return new XbLib_WebError(400);
        }
        $statusArr = array(0, 4);
        if(!in_array($orderPlanDetail['status'], $statusArr)){
            return new XbLib_WebError(4512);
        }
        if($orderPlanDetail['status'] = 0){
            $status = 5;
            $desc   = '用户取消执行，暂停时间：'.date('Y-m-d H:i:s');
        }elseif($orderPlanDetail['status'] = 4){
            $status = 6;
            $desc   = '用户暂停执行，暂停时间：'.date('Y-m-d H:i:s');
        }else{
            return new XbLib_WebError(4512);
        }
        $res = XbModule_Repayment_Order::getInstance($mch_id)->stopWisePlan($orderId, $status, $desc);
        return $res;
    }

    /**
     * @desc    获取还款订单
     */
    public function getRepaymentOrder($uid, $mch_id, $page){
        $page  = $page ? $page : 1;
        $num   = 10;
        $limit = ($page - 1)*$num;
        $orderNum  = XbModule_Repayment_Order::getInstance($mch_id)->countRepaymentOrder($uid);
        $amount    = XbModule_Repayment_Order::getInstance($mch_id)->getRepaymentOrderAmount($uid);
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getRepaymentOrder($uid, $limit, $num);
        $res = array(
            'num'         => $orderNum,
            'totalAmount' => $amount
        );
        if($orderInfo){
            foreach($orderInfo as $k=>$v){
                $detail = array();
                $detail['orderId']      = $v['order_id'];
                $detail['cardInfo']     = $v['repaybank'].'（'.mb_substr($v['repaycard'], -4).'）';
                $detail['logo']         = $this->getBankImg($v['repaycardcode']);
                $detail['amount']       = number_format($v['amount'], 2, '.', '');
                $detail['type']         = $v['type'];
                $detail['date']         = date('Y-m-d H:i:s', $v['create_time']);
                $res['repaymentInfo'][] = $detail;
            }
        }
        return $res;
    }

    /**
     * @desc    获取一键还款订单详情
     */
    public function getCommonOrderDetail($uid, $mch_id, $orderId){
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderInfo($orderId, 1);
        if(!$orderInfo) return new XbLib_WebError(4308);
        if($orderInfo['uid'] != $uid) return new XbLib_WebError(400);
        $res = array(
            'orderNo'    => $orderInfo['order_id'],
            'cardInfo'   => $orderInfo['repaybank'].'（'.mb_substr($orderInfo['repaycard'], -4).'）',
            'logo'       => $this->getBankImg($orderInfo['repaycardcode']),
            'amount'     => number_format($orderInfo['custom_amount'], 2, '.', ''),
            'payAmount'  => number_format($orderInfo['amount'], 2, '.', ''),
            'feeAmount'  => $orderInfo['fee'] > 0 ? number_format($orderInfo['fee'], 2, '.', '') : bcsub($orderInfo['amount'], $orderInfo['custom_amount']),
            'status'     => $orderInfo['status'],
            'createDate' => date('Y-m-d H:i:s', $orderInfo['create_time']),
            'payDate'    => $orderInfo['pay_time'] ? date('Y-m-d H:i:s', $orderInfo['pay_time']) : date('Y-m-d H:i:s', $orderInfo['create_time'])
        );
        return $res;
    }

    /**
     * @desc    获取智能还款订单详情
     */
    public function getWiseOrderDetail($uid, $mch_id, $orderId){
        if(!$orderId) return new XbLib_WebError(4308);
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderInfo($orderId, 2);
        if(!$orderInfo) return new XbLib_WebError(4308);
        if($orderInfo['uid'] != $uid) return new XbLib_WebError(400);
        $orderPlan = XbModule_Repayment_order::getInstance($mch_id)->getOrderPlanByOid($orderInfo['id']);
        if(!$orderPlan){
            return new XbLib_WebError(4308);
        }
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoByCardNumber($orderInfo['repaycard']);
        $planInfo = array();
        foreach($orderPlan as $v){
            $planInfo[$v['issue']][$v['plan_type']] = $v;
        }
        $res = array(
            'bank'              => $orderInfo['repaybank'],
            'logo'              => $this->getBankImg($orderInfo['repaycardcode']),
            'cardNumber'        => mb_substr($orderInfo['repaycard'], -4),
            'cid'               => $cardInfo ? $cardInfo['id'] : '',
            'status'            => $orderInfo['status'],
            'amount'            => $orderInfo['amount'],
            'repaymentNum'      => $orderInfo['plan_time'],
            'reservationAmount' => $orderInfo['plan_time'],
            'feeAmount'         => $orderInfo['fee'],
            'createDate'        => date('Y-m-d H:i:s', $orderInfo['create_time']),
        );
        $paidAmount = '0';
        $numFormat = XbLib_Var::$numFormat;
        foreach($planInfo as $k=>$v){
            $pay   = $v[1];
            if(!isset($v[2])){
                $repay = isset($planInfo[$k+1]) ? array('pay_time' => $planInfo[$k+1][1]['pay_time'], 'status' => 0) : array('pay_time' => $pay['pay_time'], 'status' => 0);
            }else{
                $repay = $v[2];
            }
            if($pay['issue'] == 1){
                $startDate = date('Y-m-d', $pay['pay_time']);
                $res['reservationAmount'] = $pay['amount'];
            }
            $endDate = date('Y-m-d', $pay['pay_time']);
            if($repay['status'] == 1){
                $paidAmount = bcadd($paidAmount, $repay['amount']);
            }
            $detail = array();
            $detail['id']             = $pay['order_id'];
            $detail['num']            = $numFormat[$pay['issue']];
            $detail['status']         = $pay['status'];
            $detail['date']           = date('Y-m-d H:i:s', $pay['pay_time']);
            $detail['amount']         = $pay['amount'];
            if(!isset($v[2])){
                $feeAmount = XbLib_Repayment_ChannelFunc::getWithdrawAmount($pay['amount'], $orderInfo['rate'], $orderInfo['single_fee']);
                $repayAmount = bcsub($pay['amount'], $feeAmount);
            }else{
                $repayAmount = $repay['amount'];
            }
            $detail['repayAmount']    = $repayAmount;
            $detail['transDate']      = date('Y-m-d H:i:s', $repay['pay_time']);
            $detail['transStatus']    = $repay['status'];
            $res['repaymentDetail'][] = $detail;
        }
        $res['repaymentPeriod']  = $startDate.' - '.$endDate;
        $res['paidAmount']       = $paidAmount;
        return $res;
    }

    /**
     * @desc 获取单张信用卡一键还款记录
     */
    public function getCardCommonOrder($uid, $mch_id, $cid, $page){
        $page  = $page ? intval($page) : 1;
        $limit = 10;
        $start = ($page-1)*$limit;
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }

        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByCard($uid, $cardInfo['cardNumber'], $start, $limit, 1);
        $res = array();
        $res['num'] = XbModule_Repayment_Order::getInstance($mch_id)->countOrderByCard($uid, $cardInfo['cardNumber'], 1);
        if($orderInfo){
            foreach($orderInfo as $k=>$v){
                $detail = array();
                $detail['orderId']   = $v['order_id'];
                $detail['date']      = date('Y-m-d H:i:s', $v['create_time']);
                $detail['amount']    = number_format($v['custom_amount'], 2, '.', '');
                $detail['feeAmount'] = number_format($v['fee'], 2, '.', '');
                $detail['status']    = $v['status'];
                $res['recordInfo'][] = $detail;
            }
        }
        return $res;
    }

    /**
     * @desc    获取用户单卡智能还款记录
     */
    public function getCardWiseOrder($uid, $mch_id, $cid, $page){
        $page  = $page ? intval($page) : 1;
        $limit = 10;
        $start = ($page-1)*$limit;
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }

        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByCard($uid, $cardInfo['cardNumber'], $start, $limit, 2);
        $res = array();
        $res['num'] = XbModule_Repayment_Order::getInstance($mch_id)->countOrderByCard($uid, $cardInfo['cardNumber'], 2);
        if($orderInfo){
            foreach($orderInfo as $k=>$v){
                $planDetail = XbModule_Repayment_Order::getInstance($mch_id)->getOrderPlanByOid($v['id']);
                $date = array();
                foreach($planDetail as $pk=>$pv){
                    $dateKey = date('Y-m-d', $pv['pay_time']);
                    $date[$dateKey] = 1;
                }
                $detail = array();
                $detail['orderId']    = $v['order_id'];
                $detail['date']       = date('Y-m-d H:i:s', $v['create_time']);
                $detail['amount']     = number_format($v['amount'], 2, '.', '');
                $detail['feeAmount']  = number_format($v['fee'], 2, '.', '');
                $detail['status']     = $v['status'];
                $detail['planDetail'] = count($date).'天'.$v['plan_time'].'笔';
                $res['recordInfo'][]  = $detail;
            }
        }
        return $res;
    }

    /**
     * @desc    删除信用卡还款信息
     */
    public function delRepaymentCard($cid, $uid, $mch_id){
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        $checkOrderPlan = XbModule_Repayment_Order::getInstance($mch_id)->checkUserPlanOrder($uid, $cardInfo['cardNumber']);
        if($checkOrderPlan > 0){
            return new XbLib_WebError(4513);
        }
        $res = XbModule_Account_CreditCard::getInstance()->delRepaymentInfo($uid, $cid);
        return $res;
    }

    /**
     * @desc    获取更改提醒接口
     */
    public function getRepaymentWarn($cid, $uid){
        $cardInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$cardInfo || $cardInfo['uid'] != $uid) return new XbLib_WebError(400);
        if($cardInfo['status'] != 1){
            return new XbLib_WebError(4502);
        }
        $res = array(
            'cid'           => $cid,
            'cardNumber'    => mb_substr($cardInfo['cardNumber'], -4),
            'statementDate' => $cardInfo['billDate'],
            'paymentDate'   => $cardInfo['payDate'],
            'status'        => $cardInfo['repaymentWarn']
        );
        return $res;
    }
}