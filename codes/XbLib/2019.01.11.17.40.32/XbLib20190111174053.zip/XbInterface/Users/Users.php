<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/6/5
 * Time: 下午7:51
 */
class XbInterface_Users_Users extends XbInterface_InterfaceBase{
    private static $obj = null;
    private $status = array(
        '1'=>'已获得',
        '2'=>'已使用',
        '4'=>'已撤回',
    );
    private $award_type = array(
        '1'=>'返现红包',
        '2'=>'抵现红包'
    );
    private $_url  = 'https://api.xiaobaijinfu.com';

    public function __construct(){
        $this->_init();
    }

    /**
     * 单例
     * @return null|XbInterface_Users_Users
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbInterface_Users_Users();
        }
        return self::$obj;
    }
    //获取用户申请信用卡列表
    public function getUserApplyBank($uid){
        $return = [];
        $res = XbModule_Account_Users::getInstance()->gerUserApplyBank($uid);
        $bank =array_flip(XbLib_Bank::$bankType);
        if($res){
            foreach($res as $key => $val){
                $arr['id']= $val['id'];
                $arr['bank']= $val['bank'];
                $arr['status']= $val['status'];
                $arr['apply_time']= date('Y-m-d H:i:s',$val['apply_time']);
                $arr['logo'] = $this->_url.'/static/img/bank/'.$bank[$val['bank']].'.png';
                $return[] =$arr;
            }
        }
        return $return;
    }
    //获取用户奖励
    public function getAward($uid){
        $return = [];
        $unused = [];
        $used   = [];
        $time   = time();
        $res = XbModule_Act_AwardItem::getInstance()->getAward($uid);
        if($res){
            foreach($res as $key => &$val){
                if($val['item_state'] == 1 && $val['deadline'] >= $time){
                    $unused['id']         = $val['id'];
                    $unused['uid']        = $val['uid'];
                    $unused['money']      = $val['money'];
                    $unused['dead_line']  = date('Y-m-d H:i:s',$val['deadline']);
                    $unused['item_state'] = $this->status[$val['item_state']];
                    $unused['award_id']   = $val['award_id'];
                    $unused['award_title']      = $val['title'];
                    $unused['title']      = $this->award_type[$val['award_type']];
                    $return['unused'][] = $unused;
                }else{
                    $used['id']         = $val['id'];
                    $used['uid']        = $val['uid'];
                    $used['money']      = $val['money'];
                    $used['dead_line']  = date('Y-m-d H:i:s',$val['deadline']);
                    $used['item_state'] = $val['item_state']==1?'已过期': $this->status[$val['item_state']];
                    $used['award_id']   = $val['award_id'];
                    $used['award_title']      = $val['title'];
                    $used['title']      = $this->award_type[$val['award_type']];
                    $return['used'][]    = $used;
                }
            }
        }
        return $return;
    }
}