<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/15
 * Time: 下午2:22
 */
class XbInterface_Order_Order extends XbInterface_InterfaceBase{
    private static $obj = null;
    protected $_url  = 'https://api.xiaobaijinfu.com';

    public function __construct(){
        $this->_init();
    }

    /**
     * 单例
     * @return null|XbInterface_Order_Order
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbInterface_Order_Order();
        }
        return self::$obj;
    }
    /**
     *@desc 创建订单
     * */
    public function createOrder($orderMoney,$cid,$channel,$channel_type,$user,$client_channel = ''){
        if(!XbLib_Verify::checkOrderMoney($orderMoney)){
            return new XbLib_WebError(4302);
        }
        $ccInfo = XbModule_Account_CreditCard::getInstance()->getInfoById($cid);
        if(!$ccInfo || $ccInfo['uid'] != $user['id']){
            return new XbLib_WebError(4304);
        }

        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($user['id']);
        if(empty($profile) || $profile['status'] != 3){
            return new XbLib_WebError(4207);
        }
        //用户等级信息
        $userLevelInfo = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($user['id']);

        //通道类型，以及通道信息
        $channel_data = array();
        $checkChannel = false;

        $channelInfo = XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($channel, 1);
        $checkTime   = XbLib_ChannelTools::checkChannelTime($channelInfo['time'], $channelInfo['week']);
        if(!$checkTime){
            return new XbLib_WebError(4310);
        }
        if($channelInfo){
            $userChannelCode = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($user['id'], $channelInfo['channel_id']);
            if(!$userChannelCode){
                return new XbLib_WebError(4306);
            }
            $checkChannel = true;
            $channel_data = array(
                'realname'        =>$profile['realname'],
                'idcardNumber'        =>$profile['idcardNumber'],
                'phone'             =>$ccInfo['telephone'],
                'bankcardNumber'  =>$profile['bankcardNumber'],
                'channel_key'     => $userChannelCode['channel_key'],
                'channel_code'     => $userChannelCode['channel_code'],
                'channel_id'       => $userChannelCode['channel_id'],
                'amount'           => $orderMoney,
                'creditcardNumber' => $ccInfo['cardNumber'],
                'fee'              => $channelInfo['fee'],
                'rate'             => $channelInfo['rate'],
                'channel_tag'      => $channelInfo['ccltype'],
                'maxnum_charge'    => $channelInfo['maxnum_charge'],
                'channel_day_max_charge' => $channelInfo['channel_day_max_charge'],
            );
        }

        if(empty($channel) || !$checkChannel){
            return new XbLib_WebError(4306);
        }

        $res =  XbModule_Account_Order::getInstance($user['mch_id'])->createOrder($user['id'], $orderMoney, $userLevelInfo['level'], $channelInfo['rate'], $ccInfo['bank'], $ccInfo['cardNumber'], $profile['bankcardNumber'], $channel, $channelInfo['channel_name'], $channel_type, $channel_data,$client_channel);
        if(!$res){
            return new XbLib_WebError(4307);
        }
        return $res;
    }
    /**
     * @desc 获取支付方式
     * */
    public function getPaymentInfo($user,$start,$limit,$type){
        $res = array();
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($user['id']);

        if($profile && $profile['status'] == 3){
            $res['debitCard']['bank']       = $profile['bank'];
            $res['debitCard']['cardNumber'] = '***'.substr($profile['bankcardNumber'],-4);
            $res['debitCard']['logo']       = $this->_url.'/static/img/bank/'.$profile['bankCode'].'.png';
        }else{
            $res['debitCard'] = null;
        }
        $creditCard = XbModule_Account_CreditCard::getInstance()->getAllCreditCard($user['id'],$start,$limit,$type);
        $res['creditCard'] = array();
        if($creditCard){
            foreach($creditCard as $v){
                $detail = array();
                $detail['id']         = $v['id'];
                $detail['bank']       = $v['bank'];
                $detail['cardNumber'] = '***'.substr($v['cardNumber'],-4);
                $detail['logo']       = $this->_url.'/static/img/bank/'.$v['bankCode'].'.png';
                $res['creditCard'][]  = $detail;
            }
        }
        $rate = 0;
        //获取用户费率通道
        if(!empty($user['phone'])){
            $user_level = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($user['id'])['level'];
            $levelRate = XbModule_Account_Level::getInstance()->getLevelRate($user['id'],$user_level);
            $rate = bcmul($levelRate['fee'], 100, 2);
        }
        $res['rate']   = $rate;
        $res['status'] = $profile ? $profile['status'] : 0;
        //获取是否可以参与活动
        $res['is_act'] = XbModule_Act_Activity::getInstance()->couldUserJoinWithdrawActivity($user['id']);
        return $res;
    }
    /**
     * @desc 订单详情
     * */
    public function orderDetail($user,$order_id){
        $res = [];
        if(empty($order_id)){
            return new XbLib_WebError(4308);
        }
        $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($user['id']);
        $orderInfo = XbModule_Account_Order::getInstance($user['mch_id'])->getOrderByOrderid($order_id);
        if(!$orderInfo){
            return new XbLib_WebError(4308);
        }

        $getAmount = $orderInfo['actual_amount'] ? $orderInfo['actual_amount'] : bcsub($orderInfo['amount'],$orderInfo['fee'],2);
        $res['getamount']    = $orderInfo['status'] == 1 ? $getAmount : 0;
        $res['amount']       = $orderInfo['amount'];
        $res['fee']           = $orderInfo['fee'];
        $res['act_fee']      = $orderInfo['act_fee'];
        $res['creditCard']   = $orderInfo['creditbank'].'(***'.substr($orderInfo['creditcard'],-4).')';
        $res['debitCard']    = $profile['bank'].'(***'.substr($orderInfo['debitcard'],-4).')';
        $res['orderNo']      = $orderInfo['order_id'];
        $res['channel_name'] = $orderInfo['channel_name'];
        if($orderInfo['status'] == 0) $status = '未支付';
        elseif($orderInfo['status'] == 1) $status = '已支付';
        elseif($orderInfo['status'] == 2) $status = '支付失败';
        $res['status']    = $status;
        $res['createDate']= date('Y-m-d H:i:s',$orderInfo['create_time']);
        $res['payDate']   = $orderInfo['pay_time'] ? date('Y-m-d H:i:s',$orderInfo['pay_time']) : '';
        //查看当前订单是否有未领取的红包如果有提示
        $act = XbModule_Act_AwardItem::getInstance()->getUserAwardByOrderId($order_id,$user['id']);
        $res['is_getaward'] = $act && $act['is_getaward'] ? 1:0;
        if($res['is_getaward']){
            $res['act_fee'] = $act['money'];
        }
        return $res;
    }
    /**
     * @desc 获取所有信用卡
     */
    public function getALlBanks(){
        //获取当前可用通道
        $channels = XbModule_Account_Channel::getInstance()->getChannel(1);
        if(!$channels){
            return new XbLib_WebError(400);
        }
        foreach($channels as $key => $val){
            $bank = [];
            //获取通道
            $banks =  XbModule_Account_Channel::getInstance()->getChannelBankList($val['channel_id'], 1);
            if($banks){
                foreach($banks as $kk => $vv){
                    $bank[] = $vv['bankCode'];
                    $channels[$key]['bank'] = $bank;
                    $channel_bank['bankCode'] = $vv['bankCode'];
                    $channel_bank['bank'] = $vv['bank'];
                    $channel_bank['img']  = $this->_url.'/static/img/bank/'.$vv['bankCode'].'.png';
                    $channels[$key]['banks'][]= $channel_bank;
                }
            }
            $date[$val['channel_id']] = explode('-',$val['time'])[1];
        }

        //时间排序
        arsort($date);
        foreach($date as $key => $val){
            foreach($channels as $kk => $vv){
                if($key == $vv['channel_id']){
                    if($vv['banks']){
                        $bank_data['time'] = $vv['time'];
                        $bank_data['banks'] = $vv['banks'];
                        $bank_data['bank'] = $vv['bank'];
                        $data[] = $bank_data;
                    }
                }
            }
        }

        if(!$data){
            return new XbLib_WebError(400);
        }
        static $arr = [];
        foreach($data as $key => &$val){
            $arr = array_merge($arr,$val['bank']);
            foreach ($data[$key+1]['bank'] as $kk => $vv){
                if(in_array($data[$key+1]['bank'][$kk],$arr)){
                    unset($data[$key+1]['bank'][$kk]);
                }
            }
            if(count($data[$key]['bank'])==0){
                unset($data[$key]);
            }
        }
        if(!$data){
            return new XbLib_WebError(400);
        }
        foreach($data as $key => &$val){
            foreach($val['banks'] as $kk => $vv){
                if(!in_array($vv['bankCode'],$val['bank'])){
                    unset($val['banks'][$kk]);
                }
            }
            $new_bank['time'] = $val['time'];
            $new_bank['banks'] = $val['banks'];
            $new_arr[]=$new_bank;
        }
        if(!$new_arr){
            return new XbLib_WebError(400);
        }

        return $new_arr;
    }
}
