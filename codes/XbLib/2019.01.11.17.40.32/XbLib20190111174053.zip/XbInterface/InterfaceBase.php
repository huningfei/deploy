<?php
/**
 * @desc    接口基础父类
 * @author  qien
 * @date    18.04.15
 */
class XbInterface_InterfaceBase{
    public $url;

    public function _init(){
        $this->getUrl();
    }

    /**
     * @desc    获取url
     */
    public function getUrl(){
        $port   = $_SERVER['SERVER_PORT'];
        $prefix = ($port == 443) ? 'https://' : 'http://';
        $this->url = $prefix.$_SERVER['HTTP_HOST'];
        return;
    }

    /**
     * @desc    获取银行图片地址
     * @param   string      $bankCode       银行code码
     * @return  string      $return         返回银行图片地址
     */
    public function getBankImg($bankCode){
        $dir = '/static/img/bank/';
        $img = '.png';
        return $this->url.$dir.$bankCode.$img;
    }
}