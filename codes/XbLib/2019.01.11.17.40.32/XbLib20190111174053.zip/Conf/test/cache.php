<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-10-27
 * UTF-8
 */

$cache = array (
		'memcache' => array (
				array (
						'host' => '127.0.0.1',
						'port' => '12360' ,
						'weight' => '1'
				)
		) ,
		'memcached' => array (
				array (
						'host' => '127.0.0.1',
						'port' => '12360',
						'weight' => '1'
				)
		)
);

return $cache;