<?php
/**
 *
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-10-27
 * UTF-8
 */
$default_w_host = '192.168.2.10';
$default_w_port = '3357';
$default_w_user = 'wdty';
$default_w_password = '123456';
$default_w_charset = 'utf8';

$default_r_host = '192.168.2.10';
$default_r_port = '3357';
$default_r_user = 'wdty';
$default_r_password = '123456';
$default_r_charset = 'utf8';

//$default_w_host = '127.0.0.1';
//$default_w_port = '3306';
//$default_w_user = 'xiaobai';
//$default_w_password = '123456';
//$default_w_charset = 'utf8';
//
//$default_r_host = '127.0.0.1';
//$default_r_port = '3306';
//$default_r_user = 'xiaobai';
//$default_r_password = '123456';
//$default_r_charset = 'utf8';

//服务数据库
$db['xb_account'] = array(
    'writer' => array(
        'host' => $default_w_host,
        'port' => $default_w_port,
        'user' => $default_w_user,
        'password' => $default_w_password,
        'database' => 'xb_account',
        'charset' => $default_w_charset
    ),
    'reader' => array(
        array(
            'host' => $default_r_host,
            'port' => $default_r_port,
            'user' => $default_r_user,
            'password' => $default_r_password,
            'database' => 'xb_account',
            'charset' => $default_r_charset
        )
    )
);
$db['xb_mis'] = array(
    'writer' => array(
        'host' => $default_w_host,
        'port' => $default_w_port,
        'user' => $default_w_user,
        'password' => $default_w_password,
        'database' => 'xb_mis',
        'charset' => $default_w_charset
    ),
    'reader' => array(
        array(
            'host' => $default_r_host,
            'port' => $default_r_port,
            'user' => $default_r_user,
            'password' => $default_r_password,
            'database' => 'xb_mis',
            'charset' => $default_r_charset
        )
    )
);

$db['xb_repayment'] = array(
    'writer' => array(
        'host' => $default_w_host,
        'port' => $default_w_port,
        'user' => $default_w_user,
        'password' => $default_w_password,
        'database' => 'xb_repayment',
        'charset' => $default_w_charset
    ),
    'reader' => array(
        array(
            'host' => $default_r_host,
            'port' => $default_r_port,
            'user' => $default_r_user,
            'password' => $default_r_password,
            'database' => 'xb_repayment',
            'charset' => $default_r_charset
        )
    )
);
$db['xb_act'] = array(
    'writer' => array(
        'host' => $default_w_host,
        'port' => $default_w_port,
        'user' => $default_w_user,
        'password' => $default_w_password,
        'database' => 'xb_act',
        'charset' => $default_w_charset
    ),
    'reader' => array(
        array(
            'host' => $default_r_host,
            'port' => $default_r_port,
            'user' => $default_r_user,
            'password' => $default_r_password,
            'database' => 'xb_act',
            'charset' => $default_r_charset
        )
    )
);
return $db;