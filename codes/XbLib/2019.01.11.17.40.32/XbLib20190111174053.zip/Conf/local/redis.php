<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */
$config = array(
		'host'=>'127.0.0.1',
		'port'=>'6379',
		'auth'=>'123456'
);

return $config;