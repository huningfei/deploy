<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-10-27
 * UTF-8
 */
$default_w_host = '192.168.2.207';
$default_w_port = '3357';
$default_w_user = 'xinjin';
$default_w_password = 'xinjin#@!';
$default_w_charset = 'utf8';

$default_r_host = '192.168.2.207';
$default_r_port = '3357';
$default_r_user = 'xinjin';
$default_r_password = 'xinjin#@!';
$default_r_charset = 'utf8';

//服务数据库
$db['xb_account'] = array(
		'writer' => array (
				'host' => $default_w_host,
				'port' => $default_w_port,
				'user' => $default_w_user,
				'password' => $default_w_password,
				'database' => 'xb_account',
				'charset' => $default_w_charset
		),
		'reader' => array (
				array (
					'host' => $default_r_host,
					'port' => $default_r_port,
					'user' => $default_r_user,
					'password' => $default_r_password,
					'database' => 'xb_account',
					'charset' => $default_r_charset
				)
		)
);

$db['xb_asset'] = array(
		'writer' => array (
				'host' => $default_w_host,
				'port' => $default_w_port,
				'user' => $default_w_user,
				'password' => $default_w_password,
				'database' => 'xb_asset',
				'charset' => $default_w_charset
		),
		'reader' => array (
				array (
					'host' => $default_r_host,
					'port' => $default_r_port,
					'user' => $default_r_user,
					'password' => $default_r_password,
					'database' => 'xb_asset',
					'charset' => $default_r_charset
				)
		)
);

$db['xb_bill'] = array(
		'writer' => array (
				'host' => $default_w_host,
				'port' => $default_w_port,
				'user' => $default_w_user,
				'password' => $default_w_password,
				'database' => 'xb_bill',
				'charset' => $default_w_charset
		),
		'reader' => array (
				array (
						'host' => $default_r_host,
						'port' => $default_r_port,
						'user' => $default_r_user,
						'password' => $default_r_password,
						'database' => 'xb_bill',
						'charset' => $default_r_charset
				)
		)
);


$db['xb_base'] = array(
		'writer' => array (
				'host' => $default_w_host,
				'port' => $default_w_port,
				'user' => $default_w_user,
				'password' => $default_w_password,
				'database' => 'xb_base',
				'charset' => $default_w_charset
		),
		'reader' => array (
				array (
						'host' => $default_r_host,
						'port' => $default_r_port,
						'user' => $default_r_user,
						'password' => $default_r_password,
						'database' => 'xb_base',
						'charset' => $default_r_charset
				)
		)
);

return $db;