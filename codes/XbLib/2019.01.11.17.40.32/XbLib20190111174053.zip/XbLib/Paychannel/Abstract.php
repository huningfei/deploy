<?php
/**
 * @desc    支付通道抽象类
 * @author  qien
 * @date    18.01.10
 */
abstract class XbLib_Paychannel_Abstract{

    protected function _init($config){

    }

    /**
     * @desc    加密签名类，加密方式：将key以ASCII排序，将key=value使用&链接，如果值为空不参与加密
     * @param   array   $data   需要加密的数据
     * @param   string  $key    通道key
     * @return  string  $return 返回加密后的数据
     */
    protected function sign($data){
        $key = $this->signKey;
        foreach($data as $k=>$v){
            if($v === '' || $v === null || $v === false){
                unset($data[$k]);
            }else{
                $data[$k] = $k.'='.$v;
            }
        }
        ksort($data);
        $dataStr = implode('&', $data);
        $signStr = $dataStr.'&key='.$key;
        return md5($signStr);
    }

    /**
     * @desc    生成加密随机字符串，使用RandomLib类库生成
     * @param   int     $num        生成位数
     * @return  string  $return     返回随机字符串
     */
    protected function getNonceStr($num){
        $factory   = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        $nonceStr  = $generator->generateString($num, "abcdefghijklmnopqrstuvwxyz1234567890");
        return $nonceStr;
    }

    /**
     * @desc    加密敏感信息，3DES加密方式
     * @return  string  $return     返回加密以后的参数
     */
    protected function encrypt($info, $key, $base64encode = false){
        $des = new XbLib_STD3Des($key);
        $res = $des->encrypt($info);
        if($base64encode) $res = base64_encode($res);
        return $res;
    }

    /**
     * @desc    判断用户银行卡是否符合此通道
     * @param   string  $bankCode   银行代码
     * @return  boolen  $return     返回判断情况
     */
    public function checkChannelBank($bankCode){
        if(!$this->bank || isset($this->bank[$bankCode])) return true;
        return false;
    }
}