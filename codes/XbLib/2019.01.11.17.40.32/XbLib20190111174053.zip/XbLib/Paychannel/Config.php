<?php
/**
 * @desc    支付通道配置文件
 * @author  qien
 * @date    18.01.10
 */
class XbLib_Paychannel_Config{

    public static function getConfig($channel, $env){
        switch($channel){
            case 'xingjie':
                $config = self::xingjieConfig();
                break;
            case 'yibao':
                $config = self::yibaoConfig();
                break;
            case 'fujianyangtao':
                $config = self::fujianyangtaoConfig();
                break;
            case 'fujianliulian':
                $config = self::fujianliulianConfig();
                break;
            case 'fujianyingtao':
                $config = self::fujianyingtaoConfig();
                break;
            case 'fujianhuolongguo':
                $config = self::fujianhuolongguoConfig();
                break;
            case 'fujianboluo':
                $config = self::fujianboluoConfig();
                break;
            case 'fujianyingtaojx':
                $config = self::fujianyingtaojxConfig();
                break;
            case 'fujianyingtaojxb':
                $config = self::fujianyingtaojxbConfig();
                break;
            default :
                break;
        }
        return $config[$env];
    }

    /**
     * @desc    星洁支付通道配置
     * @return  array       $return     返回配置信息
     */
    public static function xingjieConfig(){
        return array(
            'rls' => array(
                'url'       => 'https://pay.xjpay.cc',
                'key'       => 'cfb5c9822efd4d688a16a64b8aa836d9',
                'appId'     => '10058834',
                'interface' => array(
                    'userProfile' => '/api/debit',
                    'order'        => '/api/order',
                    'bill'         => '/api/bill'
                )
            ),
            'local' => array(
                'url'       => 'https://pay.xjpay.cc',
                'key'       => 'cfb5c9822efd4d688a16a64b8aa836d9',
                'appId'     => '10058834',
                'interface' => array(
                    'userProfile' => '/api/debit',
                    'order'        => '/api/order',
                    'bill'         => '/api/bill'
                )
            )
        );
    }

    /**
     * @desc    易宝config
     */
    public static function yibaoConfig(){
        return array(
            'rls' => array(
                'url'       => 'https://skb.yeepay.com/skb-app/',
                'key'       => '98c8612fUrHNe4oi1q2Q1830Co4AWiU47526kmHpc703119B3BcX0963Ic8K',
                'appId'     => '10020588320'
            ),
            'local' => array(
                'url'       => 'https://skb.yeepay.com/skb-app/',
                'key'       => '98c8612fUrHNe4oi1q2Q1830Co4AWiU47526kmHpc703119B3BcX0963Ic8K',
                'appId'     => '10020588320'
            )
        );
    }
    /**
     * @desc    福建米联（杨桃商旅）config
     */
    public static function fujianyangtaoConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => 'C25F94032AABEDD277012D688B347163',
                'appId'             => '70001258'
            ),
            'local' => array(
                'merchantUrl'       => 'http://220.160.118.218:8382',
                'payUrl'            => 'http://220.160.118.218:8281',
                'host'              => 'http://220.160.118.218:8280/WeChatPay',
                'key'               => '5A3E094AFB415D41E050007F01000EE3',
                'appId'             => 'CSRZ0004'
            ),

        );
    }
    /**
     * @desc    福建米联（榴莲商旅）config
     */
    public static function fujianliulianConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => 'BC2DB50A9C10F36F55D6A05A3B0876A3',
                'appId'             => '70001257'
            ),
            'local' => array(
                'merchantUrl'       => 'http://220.160.118.218:8382',
                'payUrl'            => 'http://220.160.118.218:8281',
                'host'              => 'http://220.160.118.218:8280/WeChatPay',
                'key'               => '5A3E094AFB415D41E050007F01000EE3',
                'appId'             => 'CSRZ0004'
            ),
        );
    }
    /**
     * @desc    福建米联（樱桃商旅）config
     */
    public static function fujianyingtaoConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => 'D6E01F71502386E1E8D338D45CD9789C',
                'appId'             => '70001297'
            ),
            'local' => array(
                'merchantUrl'       => 'http://220.160.118.218:8382',
                'payUrl'            => 'http://220.160.118.218:8281',
                'host'              => 'http://220.160.118.218:8280/WeChatPay',
                'key'               => '5A3E094AFB415D41E050007F01000EE3',
                'appId'             => 'CSRZ0004'
            ),
        );
    }
    /**
     * @desc    福建米联（火龙果商旅）config
     */
    public static function fujianhuolongguoConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '8D79DCA0CAF865CAC1EDF2B3D225C518',
                'appId'             => '70001334'
            ),
            'local' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '8D79DCA0CAF865CAC1EDF2B3D225C518',
                'appId'             => '70001334'
            ),
        );
    }
    /**
     * @desc    福建米联（菠萝商旅）config
     */
    public static function fujianboluoConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '8930FC23617E004AC022EAFCFEFC31FD',
                'appId'             => '70001354'
            ),
            'local' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '8930FC23617E004AC022EAFCFEFC31FD',
                'appId'             => '70001354'
            ),
        );
    }

    /**
     * @desc    福建米联（樱桃精选商旅）config
     */
    public static function fujianyingtaojxConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => 'B9DED162B021F7450662A1DB9BFA4F3A',
                'appId'             => '70001373'
            ),
            'local' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => 'B9DED162B021F7450662A1DB9BFA4F3A',
                'appId'             => '70001373'
            ),
        );
    }

    /**
     * @desc    福建米联（樱桃精选b商旅）config
     */
    public static function fujianyingtaojxbConfig(){
        return array(
            'rls' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '2DCAF87F09A2F23D59EFCC937C6AE6DB',
                'appId'             => '70001384'
            ),
            'local' => array(
                'merchantUrl'       => 'http://222.76.210.177:9006',
                'payUrl'            => 'http://npsapi.mylandpay.com',
                'host'              => 'http://222.76.210.177:9002/WeChatPay',
                'key'               => '2DCAF87F09A2F23D59EFCC937C6AE6DB',
                'appId'             => '70001384'
            ),
        );
    }
}