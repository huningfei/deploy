<?php

/**
 * 福建米联通道对接
 *
 *
 */
class XbLib_Paychannel_Adapter_Fujianmilianyingtao extends XbLib_Paychannel_Adapter_Fujianmilian implements XbLib_Paychannel_Interface
{
    public static $obj;

    public function __construct($config){
        parent::__construct($config);
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}