<?php

/**
 * 福建米联通道对接
 *
 *
 */
class XbLib_Paychannel_Adapter_Fujianmilianyangtao extends XbLib_Paychannel_Adapter_Fujianmilian implements XbLib_Paychannel_Interface
{
    public static $obj;
    
    /**
     * 支持的信用卡银行
     *
     * @var array
     */
    protected static $_supportedBankCode = [
        //键值为银行在小白系统中的code
        'ICBC'    => '工商银行',
        'CCB'     => '建设银行',
        'BOC'     => '中国银行',
        'CIB'     => '兴业银行',
        'CMBC'    => '民生银行',
        'SPDB'    => '浦发银行',
        'CEB'     => '光大银行',
        'SPABANK' => '平安银行',
        'PSBC'    => '邮储银行',
        'GDB'     => '广发银行',
        
        
        'ABC'     => '农业银行',
        'COMM'    => '交通银行',
        'CITIC'   => '中信银行',
        'HXBANK'  => '华夏银行',
        'CMB'     => '招商银行',
        'BJBANK'  => '北京银行',
        'HZCB'    => '杭州银行',
        'NJCB'    => '南京银行',
        
        //因缺少数据不能支持的银行
        /*
                        花旗银行
                        上海银行
                        天津银行
                        温州银行
                        广州银行
                        大连银行
                        锦州银行
                        重庆银行
                        哈尔滨银行
                        兰州银行
                        南昌银行
                        龙江银行
                        江苏银行
                        上海农村商业银行
                        重庆农村商业银行
        */
    ];
    
    public function __construct($config){
        parent::__construct($config);
    }
    
    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}