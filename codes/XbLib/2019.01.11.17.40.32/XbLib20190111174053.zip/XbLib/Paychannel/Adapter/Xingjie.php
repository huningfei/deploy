<?php
/**
 * @desc    星洁支付通道
 * @author  qien
 * @date    18.01.16
 */
class XbLib_Paychannel_Adapter_Xingjie extends XbLib_Paychannel_Abstract implements XbLib_Paychannel_Interface{
    protected   $sign;      //签名数据
    private     $url;       //访问url
    private     $interface; //接口
    private     $key;       //加密key
    private     $appId;     //通道id
    private     $data;      //发送的数据
    public static $obj;     //单例
    private     $header = array('Content-Type:application/json;charset=UTF-8');

    function __construct($config){
        $this->url       = $config['url'];
        //$this->interface = $config['interface'];
        $this->key       = $config['key'];
        $this->appId     = $config['appId'];
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Paychannel_Adapter_Xingjie($config);
        }
        return self::$obj;
    }

    /**
     * @desc    加密函数
     */
    public function sign($data){
        $data = $this->buildSignData($data);
        if(isset($data['customerInfo'])) $data['customerInfo'] = $this->customerInfo($data['customerInfo']);
        $this->data = $data;
        $this->data['sign'] = parent::sign($data, $this->key);
        return $this;
    }

    public function setData($data){
        $this->data = $data;
        return $this;
    }

    /**
     * @desc    验证签名
     * @param   array   $data   需要签名参数
     * @param   string  $sign   验证的加密签名
     * @return  boolen  $return 返回验证结果
     */
    public function checkSign($data, $sign){
        //$data['appId'] = $this->appId;
        $checkSign = parent::sign($data, $this->key);
        return $checkSign == $sign;
    }

    /**
     * @desc    组装加密参数
     * @param   int     $data           加密数据
     * @param   boolen  $isCheckSign    是否是检验加密
     * @return  array   $return
     */
    public function buildSignData($data, $isCheckSign = false){
        if(!$isCheckSign){
            $data['appId'] = $this->appId;
            $data['nonceStr'] = $this->getNonceStr();
        }
        return $data;
    }

    /**
     * @desc    处理用户信息，然后加密处理
     * @param   array   $customerInfo       用户数据
     * @return  string  $return             返回加密以后的用户数据
     */
    public function customerInfo($customerInfo){
        $customerInfo = implode('|', $customerInfo);
        return $this->encrypt($customerInfo, $this->key, true);
    }

    /**
     * @desc    创建用户信息
     * @return  array   $return     返回结果
     */
    public function createUserProfile(){
        if(!$this->data){
            return false;
        }
        $url = $this->url.$this->interface['userProfile'];
        $this->data = json_encode($this->data);
        $res = XbLib_CurlHttp::postNew($url, $this->data, $this->header);
        if(!$res['isSuccess']){
            $res = json_encode($res);
            $log = '错误信息：'.$res.'。传输日志：'.$this->data;
            XbFunc_Log::write('xingjieChannel', '用户创建错误！'.$log);
        }
        return $res;
    }

    /**
     * @desc    更新用户信息-现阶段需求，结算卡不能更改，只能更改费率
     * @param   int         $type       修改类型，1为M02：修改结算卡，2为：M03：修改费率
     * @return  boolen      $return     返回执行结果
     */
    public function updateUserProfile(){
        if(!$this->data){
            return false;
        }
        $url = $this->url.$this->interface['userProfile'];
        $this->data = json_encode($this->data);
        $res = XbLib_CurlHttp::put($url, $this->data, $this->header);
        if(!$res['isSuccess']){
            $res = json_encode($res);
            $log = '错误信息：'.$res.'。传输日志：'.$this->data;
            XbFunc_Log::write('xingjieChannel', '修改用户信息错误！'.$log);
        }
        return $res;
    }
}