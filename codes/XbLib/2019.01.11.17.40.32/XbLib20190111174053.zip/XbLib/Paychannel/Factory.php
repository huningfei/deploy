<?php
/**
 * @desc    支付通道工厂类
 * @author  qien
 * @date    18.01.16
 */
class XbLib_Paychannel_Factory{
	private $adapter        = null;
	private $channel_config = null;
	
	/**
	 * 获得 payChannelFactory
	 * @param string $pay_adapter
	 * @throws Exception
	 */
	function __construct($pay_adapter){
		$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
		$env = empty($env) ? 'local' : ($env != 'rls' ? 'local' : $env);
		$config = XbLib_Paychannel_Config::getConfig($pay_adapter, $env);
		if(!$config){
			throw new Exception('can not found the pay_config env:'.$env);
		}
		$this->adapter        = $pay_adapter;
		$this->channel_config = $config;
	}
	
	/**
	 * 
	 * @return Ambigous <NULL,XbLib_Paychannel_Abstract,XbLib_Paychannel_Interface>
	 */
	public function getPaychannelAdapter(){
		$adapter = null;
		switch ($this->adapter){
			case 'xingjie':
				$adapter = XbLib_Paychannel_Adapter_Xingjie::getInstance($this->channel_config);
				break;
            case 'yibao':
                $adapter = XbLib_Paychannel_Adapter_Yibao::getInstance($this->channel_config);
                break;
            case 'fujianyangtao':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianyangtao::getInstance($this->channel_config);
                break;
            case 'fujianliulian':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianliulian::getInstance($this->channel_config);
                break;
            case 'fujianyingtao':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianyingtao::getInstance($this->channel_config);
                break;
            case 'fujianhuolongguo':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianhuolongguo::getInstance($this->channel_config);
                break;
            case 'fujianboluo':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianboluo::getInstance($this->channel_config);
                break;
            case 'fujianyingtaojx':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianyingtaojx::getInstance($this->channel_config);
                break;
            case 'fujianyingtaojxb':
                $adapter = XbLib_Paychannel_Adapter_Fujianmilianyingtaojxb::getInstance($this->channel_config);
                break;
			default:
                break;
		}
		return $adapter;
	}
}
