<?php
class XbLib_Jpushappxiaoxi{

    private static $obj= null;

    //小白信用卡安卓
    private $appkey="";
    private $master_secret="";
    //小白信用卡ios
    private $iosappkey="";
    private $iosmaster_secret="";
    private $is_product = '';

    public function __construct(){
        require_once   __DIR__ . '/JPush/autoload.php';
        $file_path = $this->_getSetLogPath();

        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
        $env = empty($env) ? 'local' : $env;
        if($env=="local" || $env=="test")
        {
            //小白信用卡安卓
            $this->androidappkey           = "659ec83077ac2b7056921b3e";
            $this->androidmaster_secret    = "c354616b154b1e25c848f0eb";
            //小白信用卡ios
            $this->iosappkey        = "92657e11752d22008e2eed40";
            $this->iosmaster_secret = "963806543232730fe6693407";
            $this->is_product       = false;

        }elseif($env=="rls"){
            //小白信用卡安卓
            $this->androidappkey           = "659ec83077ac2b7056921b3e";
            $this->androidmaster_secret    = "c354616b154b1e25c848f0eb";
            //小白信用卡ios
            $this->iosappkey        = "92657e11752d22008e2eed40";
            $this->iosmaster_secret = "963806543232730fe6693407";
            $this->is_product       = true;
        }
    }

    public static function getInstance(){
        if(is_null(self::$obj)){
            self::$obj = new self();
        }
        return self::$obj;
    }

    private function _getSetLogPath(){
        $log_path =  LIBRARY_DIR.'/../XbLogs/JPushappxiaoxi/';
        if( !file_exists($log_path) ){
            @mkdir($log_path,0755);
        }
        $file_path = $log_path . date('Y-m-d') . '.log';
        if( !file_exists($file_path) ){
            $fp=fopen("{$file_path}", "w+");
            fclose($fp);
        }
        return $file_path;
    }

    /**
     * 推送个人消息
     * @param $uid 要推送的用户Id
     * @param $content 推送的内容
     * @param array $extras
     * @param string $title
     * @param bool $is_product　是否生产环境
     * @param bool $is_print　是否打印数据
     * @param bool $is_validate 是否检验数据
     * @return array|bool|int
     */
    public function send_notification_single($uid, $bid, $type, $replace = false, $is_print = false, $is_validate = false){
        $phone = '';
        if($bid){
            $inviter = XbModule_Account_Users::getInstance()->getUserById($bid);
            $phone =  substr_replace($inviter['phone'],'****',3,4);
        }
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
//        $user['phone'] = 15231231287;
        $userphone = $user['phone'];
//        $userphone ='15231231287 ';
        $message = XbModule_Account_JpushApp::$message;
        if(!$message[$type]){
            throw new Exception('模板错误');
        }
        if($replace){
            $message[$type] = $this->replaceField($message[$type], $replace, $type);
        }
        $title   = $message[$type]['title'];
        $content = str_replace('phone', $phone, $message[$type]['content']);

        $url   = $message[$type]['url'];
        $isLogin = $message[$type]['isLogin'];
        $extras  = array(
            'openurl'=>"{$url}",
            'isLogin'=>"{$isLogin}"
        );
        //ios与安卓配置各推送一遍
        $this->appkey        = $this->androidappkey;
        $this->master_secret = $this->androidmaster_secret;
        $re_push = $this->push($userphone, $title, $content, $extras ,$is_print, $is_validate);
        $this->appkey        = $this->iosappkey;
        $this->master_secret = $this->iosmaster_secret;
        $re_push = $this->push($userphone, $title, $content, $extras ,$is_print, $is_validate);
        XbModule_Account_JpushApp::getInstance()->addJpush($uid, $title, $content, $type, $bid);
        return $re_push;
    }

    public function send_app($userphone, $msg, $replace = false, $is_print = false, $is_validate = false){
        $extras  = array(
            'openurl'=>"message",
            'isLogin'=>"true"
        );
        $title = $msg['title'];
        $content = $msg['content'];
        //ios与安卓配置各推送一遍
        $this->appkey        = $this->androidappkey;
        $this->master_secret = $this->androidmaster_secret;
        $re_push = $this->push($userphone, $title, $content, $extras ,$is_print, $is_validate);
        $this->appkey        = $this->iosappkey;
        $this->master_secret = $this->iosmaster_secret;
        $re_push = $this->push($userphone, $title, $content, $extras ,$is_print, $is_validate);
        return $re_push;
    }

//    public function send_znx($uid, $msg, $type){
//        $res = XbModule_Account_JpushApp::getInstance()->addJpush($uid, $msg['title'], $msg['content'], $type, 0);
//        return $res;
//    }

    /**
     * @desc    推送消息
     */
    public function push($userphone, $title, $content, $extras, $is_print, $is_validate){
        $file_path = $this->_getSetLogPath();
        $appkey        = $this->appkey;
        $master_secret = $this->master_secret;
        $re_push = array();
        $code = '200';
        $pushmodel=  new  \JPush\Client($appkey, $master_secret,$file_path);
        $push=$pushmodel->push()
            ->addAlias($userphone)
            ->setPlatform('all')
            ->setNotificationAlert($content)
            ->iosNotification($content, array(
                'extras' => $extras
            ))
            ->androidNotification($content, array(
                'title' => $title,
                'extras' => $extras
            ))
            ->message($content,array(
                'title' => $title,
                'extras' => $extras
            ))
            ->options(array(
                'apns_production' => $this->is_product,
            ));

        if($is_print){
            $push->printJSON();
        }else{
            try{
                if($is_validate){
                    $re_push =  $push->validate();
                }else{
                    $re_push = $push->send();
                }
            }catch (\JPush\Exceptions\APIConnectionException $e){
                $code = '401';
                $re_push['code'] = $e->getCode();
                $re_push['message'] = $e->getMessage();
            }catch (\JPush\Exceptions\APIRequestException $e){
                $code = '402';
                $re_push['code'] = $e->getCode();
                $re_push['message'] = $e->getMessage();
                $re_push['http_code'] = $e->getHttpCode();
            }
        }
        return array( 'code' => $code,'data' => $re_push );
    }

    public function replaceField($data, $replace, $type){
        switch($type){
            case 'wiseSingleRepayment' :
                $data['title']   = str_replace('amount', $replace['amount'], $data['title']);
                $data['content'] = str_replace('amount', $replace['amount'], $data['content']);
                $data['title']   = str_replace('cardNumber', $replace['cardNumber'], $data['title']);
                $data['content'] = str_replace('cardNumber', $replace['cardNumber'], $data['content']);
                break;
            case 'wiseRepaymentSuccess' :
                $data['title']   = str_replace('cardNumber', $replace['cardNumber'], $data['title']);
                $data['content'] = str_replace('cardNumber', $replace['cardNumber'], $data['content']);
                break;
            case 'repaymentDate' :
                $data['content'] = str_replace('cardNumber', $replace['cardNumber'], $data['content']);
                break;
            case 'commonRepayment' :
                $data['title']   = str_replace('amount', $replace['amount'], $data['title']);
                $data['content'] = str_replace('amount', $replace['amount'], $data['content']);
                $data['title']   = str_replace('cardNumber', $replace['cardNumber'], $data['title']);
                $data['content'] = str_replace('cardNumber', $replace['cardNumber'], $data['content']);
                break;
            case 'repaymentBillDate' :
                $data['content'] = str_replace(array('cardNumber', 'cardBank'), array($replace['cardNumber'], $replace['cardBank']), $data['content']);
                break;
            case 'repaymentPayDate' :
                $data['content'] = str_replace(array('cardNumber', 'cardBank'), array($replace['cardNumber'], $replace['cardBank']), $data['content']);
                break;
            case 'awardarrive' :
                $data['title'] = str_replace('name', $replace['name'], $data['title']);
                $data['title'] = str_replace('money', $replace['money'], $data['title']);
                $data['content'] = str_replace('name', $replace['name'], $data['content']);
                $data['content'] = str_replace('money', $replace['money'], $data['content']);
                break;
            default:
                break;
        }
        return $data;
    }

//    /**
//     * 推送消息
//     * @param $content 推送的内容
//     * @param array $extras
//     * @param string $title
//     * @param bool $is_product　是否生产环境
//     * @param bool $is_print　是否打印数据
//     * @param bool $is_validate 是否检验数据
//     * @return array|bool|int
//     */
//    public function send_notification_all($type,$content,$extras = array(),$title = '',$is_print = false,$is_validate = false){
//
//        //$uid="1001271";
//
//        //天眼安卓
//        if($type==1)
//        {
//            $appkey=$this->appkey;
//            $master_secret=$this->master_secret;
//        } //天眼ios
//        else if($type==2)
//        {
//            $appkey=$this->iosappkey;
//            $master_secret=$this->iosmaster_secret;
//        }
//        //理财
//        else if($type==3)
//        {
//            $appkey=$this->licaiappkey;
//            $master_secret=$this->licaimaster_secret;
//            //$uid="13811701421";
//        }
//        //记呗
//        else if($type==4)
//        {
//            $appkey=$this->jibeiappkey;
//            $master_secret=$this->jibeimaster_secret;
//        }
//        //随手花
//        else if($type==5)
//        {
//            $appkey=$this->suishouhuaappkey;
//            $master_secret=$this->suishouhuamaster_secret;
//        }
//
//        $re_push = array();
//        $code = '200';
//
//        $file_path = $this->_getSetLogPath();
//        $pushmodel=  new  \JPush\Client($appkey, $master_secret,$file_path);
//
//        $push = $pushmodel
//            ->push()
//            ->addAllAudience()
//            //->addAlias($uid)
//            ->setPlatform('all')
//            ->setNotificationAlert($content)
//            ->iosNotification($content, array(
//                'extras' => $extras
//            ))
//            ->androidNotification($content, array(
//                'title' => $title,
//                'extras' => $extras
//            ))
//            ->message($content,array(
//                'title' => $title,
//                'extras' => $extras
//            ))
//            ->options(array(
//                'apns_production' => self::IS_PRODUCT,
//            ));
//
//        if($is_print){
//            $push->printJSON();
//        }else{
//            try{
//                if($is_validate){
//                    $re_push =  $push->validate();
//                }else{
//                    $re_push = $push->send();
//                }
//            }catch (\JPush\Exceptions\APIConnectionException $e){
//                $code = '401';
//                $re_push['code'] = $e->getCode();
//                $re_push['message'] = $e->getMessage();
//                TyFunc_Log::write('jpush_appxiaoxi','exception1_ty_uid:',json_encode($re_push));
//            }catch (\JPush\Exceptions\APIRequestException $e){
//                $code = '402';
//                $re_push['code'] = $e->getCode();
//                $re_push['message'] = $e->getMessage();
//                $re_push['http_code'] = $e->getHttpCode();
//                TyFunc_Log::write('jpush_appxiaoxi','exception2_ty_uid:',json_encode($re_push));
//            }
//        }
//
//
//        return array( 'code' => $code,'data' => $re_push );
//    }

    /**获取送达结果
     * @param $type
     * @param $msgIds
     */
//    public function getReceived($type,$msgIds)
//    {
//        //安卓
//        if($type==1)
//        {
//            $appkey=$this->appkey;
//            $master_secret=$this->master_secret;
//        } //天眼ios
//        else if($type==2)
//        {
//            $appkey=$this->iosappkey;
//            $master_secret=$this->iosmaster_secret;
//        }
//
//        $alias=$msgIds;
//        if(is_array($msgIds))
//        {
//            $alias=join(",",$msgIds);
//        }
//        $url="https://report.jpush.cn/v3/received?msg_ids=".$alias;
//        //初始化
//        $ch = curl_init();
//        //设置选项，包括URL
//        curl_setopt($ch, CURLOPT_URL,$url);
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//        curl_setopt($ch, CURLOPT_TIMEOUT,5);
//        curl_setopt($ch, CURLOPT_HEADER, 0);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
//        curl_setopt($ch, CURLOPT_USERPWD, $appkey.":".$master_secret);
//        //执行并获取HTML文档内容
//        $output = curl_exec($ch);
//        //释放curl句柄
//        curl_close($ch);
//        //打印获得的数据
//       return $output;
//    }
}
