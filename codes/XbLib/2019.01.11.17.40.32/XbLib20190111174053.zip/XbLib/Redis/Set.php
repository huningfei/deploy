<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */
class XbLib_Redis_Set extends XbLib_Redis_Base {
	function __construct() {
	}
	/**
	 * 增加一个set数据
	 * @param unknown $key
	 * @param unknown $value
	 */
	public static function sAdd($key, $value) {
		self::_init ();
		return self::$_redis->sAdd ( $key, $value );
	}

	/**
	 * 获得set数据
	 * @param unknown $key
	 */
	public static function sMembers($key) {
		self::_init ();
		return self::$_redis->sMembers ( $key );
	}

	/**
	 * 移除一个set数据
	 * @param unknown $key
	 * @param unknown $value
	 */
	public static function sRem($key, $value) {
		self::_init ();
		return self::$_redis->sRem ( $key, $value );
	}

	/**
	 * 获得集合中的元素数量
	 * @param unknown $key
	 */
	public static function sCard($key){
		self::_init();
		return self::$_redis->scard($key);
	}
}