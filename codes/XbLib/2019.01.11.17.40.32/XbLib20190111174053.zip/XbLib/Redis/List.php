<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-29
 * UTF-8
 */
class XbLib_Redis_List extends XbLib_Redis_Base {
	function __construct() {
	}

	/**
	 * 从队列的左边入队一个或多个元素
	 *
	 * @param unknown_type $key
	 * @param array $value
	 */
	public static function lPush($key, $value) {
		self::_init ();
		return self::$_redis->LPUSH ( $key, $value );
	}

	/**
	 * 从队列的右边入队一个元素
	 *
	 * @param unknown_type $key
	 * @param unknown_type $value
	 */
	public static function rPush($key, $value) {
		self::_init ();
		return self::$_redis->RPUSH ( $key, $value );
	}

	/**
	 * 当队列存在时，从队到左边入队一个元素
	 *
	 * @param unknown_type $key
	 * @param unknown_type $value
	 */
	public static function lPushX($key, $value) {
		self::_init ();
		return self::$_redis->LPUSHX ( $key, $value );
	}

	/**
	 * 从队列的右边入队一个元素，仅队列存在时有效
	 *
	 * @param unknown_type $key
	 * @param unknown_type $value
	 */
	public static function rPushX($key, $value) {
		self::_init ();
		return self::$_redis->RPUSHX ( $key, $value );
	}

	/**
	 * 从队列的左边出队一个元素
	 *
	 * @param unknown_type $key
	 */
	public static function lPop($key) {
		self::_init ();
		return self::$_redis->LPOP ( $key );
	}

	/**
	 * 从队列的右边出队一个元素
	 *
	 * @param unknown_type $key
	 */
	public static function rPop($key) {
		self::_init ();
		return self::$_redis->RPOP ( $key );
	}

	/**
	 * 获得队列(List)的长度
	 *
	 * @param unknown_type $key
	 */
	public static function lLen($key) {
		self::_init ();
		return self::$_redis->LLen ( $key );
	}

	/**
	 * 获取一个元素，通过其索引列表
	 *
	 * @param unknown_type $key
	 * @param int $index
	 */
	public static function lIndex($key, $index) {
		self::_init ();
		return self::$_redis->LINDEX ( $key, $index );
	}

	/**
	 * 从列表中获取指定返回的元素
	 *
	 * @param unknown_type $key
	 * @param int $start
	 * @param int $end
	 */
	public static function lRange($key, $start, $end) {
		self::_init ();
		return self::$_redis->LRANGE ( $key, $start, $end );
	}

	/**
	 * 裁剪队列
	 * @param unknown $key
	 * @param unknown $start
	 * @param unknown $end
	 */
	public static function lTrim($key,$start,$end){
		self::_init();
		return self::$_redis->ltrim($key,$start,$end);
	}
}