<?php
class XbLib_PushMsg
{
    private static $obj = null;
    private $msgTemplate = array();
    private $host = 'https://m.xiaobaijinfu.com';

    public function __construct(){
        $this->msgTemplate = XbLib_Var::$msgTemplate;
    }

    public static function getInstance(){
        if(is_null(self::$obj)){
            self::$obj = new self();
        }
        return self::$obj;
    }


    //替换模板中的占位符
    public function replaceField($template, $replace) {
        if (empty($replace)){
            return $template;
        }
        if (!empty($template['app'])) {
            foreach ($replace as $k => $v) {
                $template['app'] = str_replace($k, $v,$template['app']);
            }
        }
        if (!empty($template['wx'])) {
           foreach ($template['wx'] as $key => &$value) {
               foreach ($replace as $k => $v) {
                   $value = str_replace($k, $v,$value);
               }
           }
        }
        return $template;
    }

    //注册成功
    public function reg($uid) {
        //模板类型
        $template_type = 'reg';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        //不需要替换,直接输出模板
        $template = $this->msgTemplate[$template_type];

        try{
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);
            //            throw new Exception('测试消息失败');
        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：注册成功', $uid);
        }

        return true;
    }

    //邀请的用户注册成功
    public function inviteReg($uid, $replace) {
        $template_type = 'inviteReg';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        if($replace['bid']){
            $b_user = XbModule_Account_Users::getInstance()->getUserById($replace['bid']);
            $replace['__phone'] =  substr_replace($b_user['phone'],'****',3,4);
        }

        $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

        try{
            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type, $replace['bid']);
        }catch (Exception $e){
            $user['inviteUid'] = $replace['bid'];
            $log = json_encode($user,JSON_UNESCAPED_UNICODE);
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：邀请人用户', $log);
        }
        return true;

    }

    //邀请的用户完成实名认证
    public function inviteAuth($uid, $replace) {
        $template_type = 'inviteAuth';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        if($replace['bid']){
            $b_user = XbModule_Account_Users::getInstance()->getUserById($replace['bid']);
            $replace['__phone'] =  substr_replace($b_user['phone'],'****',3,4);
        }

        $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

        try{
            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type, $replace['bid']);
        }catch (Exception $e){
            $user['inviteUid'] = $replace['bid'];
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:inviteAuth', $b_user['id']);

        }
        return true;

    }

    //邀请的用户完成一笔收款
    public function profit($uid, $replace) {
        $template_type = 'profit';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        if($replace['bid']){
            $b_user = XbModule_Account_Users::getInstance()->getUserById($replace['bid']);
            $replace['__phone'] =  substr_replace($b_user['phone'],'****',3,4);
        }

        $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

        try{
            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type, $replace['bid']);
        }catch (Exception $e){
            $user['inviteUid'] = $replace['bid'];
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：邀请的用户完成一笔收款。type:profit', $b_user['id']);

        }
        return true;

    }
    //邀请的用户完成一笔还款
    public function repaymentProfit($uid, $replace) {
        $template_type = 'repaymentProfit';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        if($replace['bid']){
            $b_user = XbModule_Account_Users::getInstance()->getUserById($replace['bid']);
            $replace['__phone'] =  substr_replace($b_user['phone'],'****',3,4);
        }

        $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

        try{
            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type, $replace['bid']);
        }catch (Exception $e){
            $user['inviteUid'] = $replace['bid'];
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：邀请的用户完成一笔还款。type:profit', $b_user['id']);

        }
        return true;

    }
    //实名认证失败
    public function authFail($uid) {
        $template_type = 'authFail';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);


        try{
            $replace = array(
                '__name' => $userProfile['realname'],
                '__phone'=> $user['phone'],
            );
            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'SHI_MING';
            $url = $this->host . '/wechat/getUserinfo?type=8';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:authFail', $uid);
        }

        return true;
    }

    //实名认证成功
    public function authSuccess($uid) {
        $template_type = 'authSuccess';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $replace = array(
                '__name' => $userProfile['realname'],
                '__phone'=> $user['phone'],
            );
            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'SHI_MING';
            $url = $this->host . '/wechat/getUserinfo?type=7';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:authSuccess', $uid);
        }

        return true;
    }

    //一键还款成功
    public function commonRepaymentSuccess($uid, $replace) {
        $template_type = 'commonRepaymentSuccess';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $order =  XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderByOrderId($replace['order_id']);
            //极光&站内
            $amount = number_format($order['amount'], 2, '.', '');
            $amountActual = bcsub($order['amount'], $order['fee'], 2);
            $cardNumber = substr($order['repaycard'], -4, 4);
            $date = $order['create_time'] ? $order['create_time'] : time();

            $replace = array(
                '__amountActual' => $amountActual,
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s',$date),
                '__orderNumber'  => $order['order_id'],
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], 'commonRepayment');

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：单笔提现。type:wiseSingleRepayment', $uid);
        }
        return true;

    }

    //一键还款失败
    public function commonRepaymentFail($uid, $replace) {
        $template_type = 'commonRepaymentFail';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $order =  XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderByOrderId($replace['order_id']);
            //极光&站内
            $amount = number_format($order['amount'], 2, '.', '');
            $amountActual = bcsub($order['amount'], $order['fee'], 2);
            $cardNumber = substr($order['repaycard'], -4, 4);
            $date = $order['create_time'] ? $order['create_time'] : time();

            $replace = array(
                '__amountActual' => $amountActual,
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s',$date),
                '__orderNumber'  => $order['order_id'],
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
//            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
//            $res = XbModule_Account_JpushApp::getInstance()->$this->send_znx($uid, $template['app'], 'commonRepayment');

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：单笔提现。type:wiseSingleRepayment', $uid);
        }
        return true;

    }

    //智能还款计划定制成功
    public function wiseRepaymentPlanSuccess($uid, $replace) {
        $template_type = 'wiseRepaymentPlanSuccess';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $order =  XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderInfo($replace['order_no']);

            //极光&站内
            $amount = number_format($order['amount'], 2, '.', '');
            $cardNumber = substr($order['repaycard'], -4, 4);
            $date = $order['create_time'] ? $order['create_time'] : time();

            $replace = array(
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s'),
                '__orderNumber'  => $order['order_id'],
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：智能还款计划。type:commonRepaymentSuccess', $uid);
        }
        return true;

    }

    //完成一笔智能还款
    public function wiseSingleRepayment($uid, $replace) {
        $template_type = 'wiseSingleRepayment';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $order_plan = XbModule_Repayment_OrderPlan::getInstance($user['mch_id'])->getOrderPlanById($replace['order_plan_id']);
            $order = XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderById($order_plan['oid']);

            $amount = number_format($order_plan['amount'], 2, '.', '');
            $amountActual = bcsub($order_plan['amount'], $order_plan['fee'], 2);
            $cardNumber = substr($order['repaycard'], -4, 4);
            $date = $order_plan['plan_time'] ? $order_plan['plan_time'] : time();

            $replace = array(
                '__amountActual' => $amountActual,
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s',$date),
                '__orderNumber'  => $order_plan['order_id'],
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：单笔提现。type:wiseSingleRepayment', $uid);
        }
        return true;
    }

    //完成全部智能还款
    public function wiseRepaymentSuccess($uid, $replace) {
        $template_type = 'wiseRepaymentSuccess';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            $order_plan = XbModule_Repayment_OrderPlan::getInstance($user['mch_id'])->getOrderPlanById($replace['order_plan_id']);
            $order = XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderById($order_plan['oid']);

            $amount = number_format($order['amount'], 2, '.', '');
            $amountActual = bcsub($order['amount'], $order['fee'], 2);
            $cardNumber = substr($order['repaycard'], -4, 4);
            $date = $order['create_time'] ? $order['create_time'] : time();

            $replace = array(
                '__amountActual' => $amountActual,
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s',$date),
                '__orderNumber'  => $order_plan['order_id'],
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

//            throw new Exception('测试消息失败');
        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：完成计划。type:wiseRepaymentSuccess', $uid);
        }
        return true;


    }

    //暂停智能还款
    public function wiseRepaymentStop($uid, $replace) {
        $template_type = 'wiseRepaymentStop';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);

        try{
            if(!empty($replace['order_plan_id'])) {
                $order_plan = XbModule_Repayment_OrderPlan::getInstance($user['mch_id'])->getOrderPlanById($replace['order_plan_id']);
                $order = XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderById($order_plan['oid']);

                $amount = number_format($order_plan['amount'], 2, '.', '');
                $amountActual = bcsub($order_plan['amount'], $order_plan['fee'], 2);
                $cardNumber = substr($order['repaycard'], -4, 4);
                $date = $order_plan['plan_time'] ? $order_plan['plan_time'] : time();
                $orderId = $order_plan['order_id'];
            } else if (!empty($replace['order_id'])) {
                $order = XbModule_Repayment_Order::getInstance($user['mch_id'])->getOrderById($replace['order_id']);

                $amount = number_format($order['amount'], 2, '.', '');
                $amountActual = bcsub($order['amount'], $order['fee'], 2);
                $cardNumber = substr($order['repaycard'], -4, 4);
                $date = $order['create_time'] ? $order['create_time'] : time();
                $orderId = $order['order_id'];
            }

            $replace = array(
                '__amountActual' => $amountActual,
                '__amount'       => $amount,
                '__cardNumber'   => $cardNumber,
                '__name'         => $userProfile['realname'],
                '__date'         => date('Y-m-d H:i:s',$date),
                '__orderNumber'  => $orderId,
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：暂停还款。type:wiseRepaymentStop', $uid);
        }
        return true;


    }

    //账单日提醒
    public function repaymentBillDate($uid, $replace) {
        $template_type = 'repaymentBillDate';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        try{
            $card = XbModule_Account_CreditCard::getInstance()->getInfoById($replace['card_id']);
            $replace = array(
                '__cardNumber' => substr($card['cardNumber'], -4, 4),
                '__cardBank'   => $card['bank'],
                '__billDate'   => XbLib_Repayment_ChannelFunc::getCreditCardDate($card['billDate'], 1),
                '__payDate'    => XbLib_Repayment_ChannelFunc::getCreditCardDate($card['payDate'], 2),
                'uid'        => $uid,
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'ZHI_NENG_TI_XING';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

            throw new Exception('测试消息失败');
        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：还款日提醒。type:repaymentPayDate', $uid);
        }
        return true;

    }

    //还款日提醒
    public function repaymentPayDate($uid, $replace) {
        $template_type = 'repaymentPayDate';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        try{
            $card = XbModule_Account_CreditCard::getInstance()->getInfoById($replace['card_id']);
            $replace = array(
                '__cardNumber' => substr($card['cardNumber'], -4, 4),
                '__cardBank'   => $card['bank'],
                '__billDate'   => XbLib_Repayment_ChannelFunc::getCreditCardDate($card['billDate'], 1),
                '__payDate'    => XbLib_Repayment_ChannelFunc::getCreditCardDate($card['payDate'], 2),
                'uid'        => $uid,
            );

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'ZHI_NENG_TI_XING';
            $url = $this->host . '/wechat/getUserinfo?type=10';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：账单日提醒。type:repaymentBillDate', $uid);
        }
        return true;

    }

    //编辑储蓄卡提醒
    public function bankcardUpdateFail($uid) {
        //模板类型
        $template_type = 'bankcardUpdateFail';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        try
        {
            //不需要替换,直接输出模板
            $template = $this->msgTemplate[$template_type];

            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);
        }
        catch (Exception $e)
        {
            XbFunc_Log::write('JPushappxiaoxi','推送消息失败：修改用户状态。type:bankcardUpdateFail', $uid);
        }
        return true;
    }

    //红包到期提醒
    public function awardremind($uid, $replace) {
        $template_type = 'awardremind';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        try{
            $award = XbModule_Act_AwardItem::getInstance()->getAwardByItemId($replace['item_id']);

            $replace = array(
                '__money'   => $award['money'],
                '__date'    => date('Y.m.d H:i',time()),
                '__name'    => $award['title'],
                '__type'    => $award['act_type'] == 1?'办卡返现':'收款免费',
            );
            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'AWARD_REMIND';
            $url = $this->host . '/wechat/getUserinfo?type=11';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：红包到期提醒。type:awardremind item_id'.$replace['item_id']);
        }
        return true;

    }

    //红包到账提醒
    public function awardarrive($uid, $replace) {
        $template_type = 'awardarrive';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        try{
            $award = XbModule_Act_AwardItem::getInstance()->getAwardByItemId($replace['item_id']);

            $replace = array(
                '__money'   => (string)round($award['money'],2),
                '__date'    => date('Y.m.d H:i',time()),
                '__name'    => $award['title'],
                '__type'    => $award['act_type'] == 1?'办卡返现':'收款免费',
            );
            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            //极光推送
            $res = XbLib_Jpushappxiaoxi::getInstance()->send_app($user['phone'], $template['app']);
            //站内信
            $res = XbModule_Account_JpushApp::getInstance()->send_znx($uid, $template['app'], $template_type);

            //微信
            $template_id = 'AWARD_ARRIVE';
            $url = $this->host . '/wechat/getUserinfo?type=11';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send_wx($user['wx_openid'], $template['wx'], $template_id, $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：红包到账提醒。type:awardarrive item_id'.$replace['item_id']);
        }
        return true;
    }
    //微信绑定手机号成功
    public function bindWx($uid) {
        $template_type = 'bindWx';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);

        try{
            $replace['__phone'] = $user['phone'];
            $replace['__date'] = date('Y-m-d H:i:s', $user['create_time']);

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);
            $template_id = 'ZHU_CE_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo';

            $res = XbLib_WechatTools_SendMsg::getInstance()->send($user['wx_openid'], $template_id, $template['wx'], $url);
        }catch (Exception $e){
            XbFunc_Log::write('WxMsgxiaoxi','推送消息失败：实名认证用户', $uid);
        }
        return true;
    }

    //取现成功
    public function orderPayment($uid, $replace) {
        $template_type = 'orderPayment';
        $user = XbModule_Account_Users::getInstance()->getUserById($uid);
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($uid);
        $mch_id = $user['mch_id'];

        try{
            if(!empty($replace['order_id'])){
                $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderById($replace['order_id']);
            } else if (!empty($replace['axf_order_no'])) {
                $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($replace['axf_order_no']);
            }

            $replace['__name'] = $userProfile['realname'];
            $replace['__amount'] = $order['amount'];
            $replace['__date'] = date('Y-m-d H:i:s', $order['create_time']);
            $replace['__orderNumber'] = $order['order_id'];

            $template = $this->replaceField($this->msgTemplate[$template_type], $replace);

            $template_id = 'ZHANG_DAN_CHENG_GONG';
            $url = $this->host . '/wechat/getUserinfo?type=9';
            $res = XbLib_WechatTools_SendMsg::getInstance()->send($user['wx_openid'], $template_id, $template['wx'], $url);

        }catch (Exception $e){
            XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：取现提醒。type:orderPayment order_id'.$replace['order_id']);
        }
        return true;
    }
}