<?php
/**
 * @desc 	平安银行代付系统
 */
class XbLib_PingAnPay{
    //标记为******的都需要配置，如果修改配置的话，请参考文档修改配置项，如果不需要填，这留空位
    public $version        = 'A001';                   //报文头(4位)
    public $system         = '01';                     //目标系统(2位)
    public $charset        = '02';                     //字符集UTF8(2位)
    public $protocol       = '02';                     //通讯协议 http(2位)
    public $account;                                   //外联客户代码*********(20位)
    public $messagelenth;                              //接收报文长度*********(10位)
    public $tradeCode;                                 //交易码*********(6位)
    public $operator       = '     ';                  //操做员代码(5位)
    public $type           = '01';                     //服务类型(2位)
    public $date;                                      //交易日期yyyymmddhhmmss*********(14位)
    public $orderId;                                   //请求方系统流水号*********(20位)
    public $returnCode     = '000000';                 //返回码(6位)
    public $returnDesc     = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';   //返回描述(100位)
    public $followTag      = ' ';                      //后续包标志(1位)
    public $followTime     = '   ';                    //后续包请求次数(3位)
    public $signTag        = ' ';                      //签名标识(1位)
    public $signType       = ' ';                      //签名数据包格式(1位)
    public $signAlgorithm  = '            ';           //签名算法(12位)
    public $signLength     = '0000000000';             //签名数据长度(10位)
    public $fileCount      = '0';                      //附件数目(1位)
    static private $obj;
    static private $url    = 'http://127.0.0.1:7072';
    private $message;
    private $body;
    private $accountNo;                                 //签约账号
    private $tradeType;                                 //交易类型
    function __construct(){
        //获取环境
        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : '');
        $env = empty($env) ? 'local' : $env;
        $this->env = $env;
        if($env=="rls"){
            $this->account   = '00201240000000041000';
            $this->accountNo = '15000092160969';
        }else{
            $this->account   = '00901020000000011000';
            $this->accountNo = '11014609385000';
        }
    }

    /**
     * @desc    实例化类
     */
    static public function getInstance(){
        if(!self::$obj){
            self::$obj = new XbLib_PingAnPay();
        }
        return self::$obj;
    }

    /**
     * @desc    设置请求类型
     * @param   int     $type   设置类型
     * @return  object  $retrun $this
     */
    public function setType($type){
        switch($type){
            case 1 :
                $this->tradeCode = 'KHKF03';
                break;
            case 2 :
                $this->tradeCode = 'KHKF04';
                break;
            case 3 :
                $this->tradeCode = 'KHKF01';
                break;
            case 4 :
                $this->tradeCode = 'KHKF02';
                break;
            default:
                $this->tradeCode = '000000';
                break;
        }
        $this->tradeType = $type;
        return $this;
    }

    /**
     * @desc    组织请求消息 报文头|报文消息
     * @param   array   $data   设置数据，订单号
     * @return  object  $return 返回this
     */
    public function buildMessage($data){
        if($this->tradeType == 1){
            $this->requestSingleTradeBody($data);
        }elseif($this->tradeType == 2){
            $this->checkSingleTradeBody($data);
        }
        $this->setMessageHeader($data['orderNo']);
        return $this;
    }

    public function request(){
        $sendMessage = $this->message.$this->body;
        $header = array('Content-Type","text/xml; charset=UTF-8');
        $res = $this->curlPost(self::$url, $sendMessage, $header);
        $return['headerStatus'] = $this->parseMessageHeader($res);
        $return['bodyMsg'] = $this->parseMessageBody($res);
        return $return;
    }

    /*
     * @desc    组织设置报文头
     * @param   */
    public function setMessageHeader($orderNo){
        $this->messagelenth = str_pad(strlen($this->body), 10, '0', STR_PAD_LEFT);
        $this->orderId      = $orderNo;
        $this->date         = date('YmdHis');
        /*组装报文头*/
        $this->message = $this->version.$this->system.$this->charset.$this->protocol.$this->account.$this->messagelenth.$this->tradeCode.$this->operator.$this->type.$this->date.$this->orderId.$this->returnCode.$this->returnDesc.$this->followTag.$this->followTime.$this->signTag.$this->signType.$this->signAlgorithm.$this->signLength.$this->fileCount;
    }

    /**
     * @desc    设置单笔交易body xml格式
     * @param   array   $data       需要传入的信息
     * @return  empty   $return
     */
    public function requestSingleTradeBody($data){
        $mark = $data['mark'] ? $data['mark'] : '';
        $this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><OrderNumber>'.$data['orderNo'].'</OrderNumber><AcctNo>'.$this->accountNo.'</AcctNo><BusiType>00000</BusiType><CorpId></CorpId><CcyCode>RMB</CcyCode><TranAmount>'.$data['amount'].'</TranAmount><InAcctNo>'.$data['bankCardNo'].'</InAcctNo><InAcctName>'.$data['username'].'</InAcctName><InAcctBankName></InAcctBankName><InAcctBankNode></InAcctBankNode><Mobile></Mobile><Remark>'.$mark.'</Remark></Result>';
    }

    /**
     * @desc    设置单笔交易body xml格式
     * @param   array   $data       需要传入的信息
     * @return  empty   $return
     */
    public function checkSingleTradeBody($data){
        $this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><OrderNumber>'.$data['orderNo'].'</OrderNumber><AcctNo>'.$this->accountNo.'</AcctNo></Result>';
    }

    /**
     * @desc    发送http请求 @note:因设置是xml通讯，故无法调用CurlHttp类
     * @return  object  $return     返回请求结果
     */
    public function curlPost($url, $postData, $header){
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_HTTPHEADER => $header,
        ));
        $res = curl_exec($ch);
        curl_close($ch);
        return $res;
    }

    /**
     * @desc    解析报文头，获取报文头状态
     */
    public function parseMessageHeader($result){
        $status = trim(substr($result, 93, 100));
        return $status;
    }

    /**
     * @desc    解析Xml，返回解析后的类
     */
    public function parseMessageBody($result){
        $xml = substr($result, 222);
        return $xml ? json_decode(json_encode(simplexml_load_string($xml)), true) : array();
    }
}