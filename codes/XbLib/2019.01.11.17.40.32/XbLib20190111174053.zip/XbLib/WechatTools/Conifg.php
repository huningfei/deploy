<?php

/**
 *
 * @author Abel
 *         email:abel.zhou@hotmail.com
 *         2015年12月16日
 *         UTF-8
 */
class XbLib_WechatTools_Conifg{
    /**
     *微信配置
     */
    public static $_xiaobai_share = array(
        'rls' => array(
            'token'           => 'xiaobai', //填写你设定的key
            'encodingaeskey'  => '7ecejQ8zTkmJ1g8nRgOKMzrLA8bgiyxkpmPQMfwfQRK', //填写加密用的EncodingAESKey
            'appid'           => 'wx9259dfc3b3f2ff9c', //填写高级调用功能的app id
            'appsecret'       => 'e6e80a16921907a0eb6322184a25a7ad', //填写高级调用功能的密钥
            'partnerid'       => '', //财付通商户身份标识
            'partnerkey'      => '', //财付通商户权限密钥Key
            'paysignkey'      => '' //商户签名密钥Key
        ),
        // 暂时修改test为local
        'test' => array(
            'token'           => 'xiaobaitest', //填写你设定的key
            'encodingaeskey'  => '5ad4W3iEvE1IARSuEGNVOrYppNkNZ0ZehbPPFZhyN1F', //填写加密用的EncodingAESKey
            'appid'           => 'wx734a9cc543b58c0e', //填写高级调用功能的app id
            'appsecret'       => '386d564ed0d6ce4bd6c87733b6d9d24d', //填写高级调用功能的密钥
            'partnerid'       => '', //财付通商户身份标识
            'partnerkey'      => '', //财付通商户权限密钥Key
            'paysignkey'      => '' //商户签名密钥Key
        ),
    );

    /**
     * 接口相关配置
     */
    public static $_interfaces = array(
        //url相关地址配置
        'url' => array(
            //菜单操作相关
            'menu_create'	        => 'https://api.weixin.qq.com/cgi-bin/menu/create', //创建菜单
            'menu_select'	        => 'https://api.weixin.qq.com/cgi-bin/menu/get',	//查询菜单
            'menu_delete'	        => 'https://api.weixin.qq.com/cgi-bin/menu/delete', //更新菜单

            //模版消息接口
            'template_get_industry' => 'https://api.weixin.qq.com/cgi-bin/template/get_industry?',//获取设置的行业信息
            'template_get_id'       => 'https://api.weixin.qq.com/cgi-bin/template/api_add_template?',//获得模板ID
            'template_send'         => 'https://api.weixin.qq.com/cgi-bin/message/template/send?',//发送模板消息

            //基础接口
            'access_token'  => 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&',	//获取token
            'check_access_token' => 'https://api.weixin.qq.com/cgi-bin/getcallbackip?' //验证access_token 是否有效[]
        ),

    );

    /**
     * 微信消息推送模板
     * @var array
     */
    public static $_templateid = array(
        // 线上测试配置
        'rls' => array(
            'ZHU_CE_CHENG_GONG'     => '8EQcnuXYftstyjE-ESjrhy4If4sYylqf8tbzPjdX8zs',  //注册成功
            'SHI_MING'              => 'wr_AOzfxd2GhSDgh8i-z1ZFgOjv7WBQHYSTKg4gm2W0',  //实名消息
//            'YAO_QING_CHENG_GONG'   => '',  //邀请成功
            'ZHANG_DAN_CHENG_GONG'  => 'iuoNrhrNYRdGNwMQmva03qVv6qa2F6gftXQp4MI3Umo',  //账单成功
            'ZHANG_DAN_SHI_BAI'     => 'Tq6qJsy-zLhPbwVcarPOIfF1mKt93ZXoQNr_9snCRlU',  //账单失败
            'ZHI_NENG_ZHANG_DAN'    => 'TPvQB8dcnYkJ2cNSHjtvX7eoqTHY9KgdGpcFSCgKDzw',  //智能账单
            'AWARD_REMIND'          => '1-4eMN8QIlO6oDfmtw_rzsw5HvOnacvYT4VM6WtP5T8',  //红包过期提醒
            'AWARD_ARRIVE'          => 'ECLaiige17VZxz3Z_dBhaM7X_lN6VjPGQeTsJxBwoI8',   //红包到账提醒
            'ZHI_NENG_TI_XING'      => 'BM86pxgGjq2sF8npWUYvueSyEstbkhZFXpg5fnUnLB8',  //还款提醒
        ),

        // 暂时修改test为local
        'test' => array(
            'ZHU_CE_CHENG_GONG'     => 'uXGJ3HffrtoD6za5UUmV6ykSux9doRpD15tcmTVtsgo',  //注册成功
            'SHI_MING'              => 'dFxWtVcbk5KJtxThYKbZjrNzfVxc556jcEInVUam3dM',  //实名消息
            'YAO_QING_CHENG_GONG'   => '',  //邀请成功
            'ZHANG_DAN_CHENG_GONG'  => 'wA-phj_ClOxzqd6qY0SApwHwgZr-aer7h0lL1z2Gdq4',  //账单成功
            'ZHANG_DAN_SHI_BAI'     => 'Qqvrzh5xq7Ptfmi7q2Jrrp0rY10grktbUKLH6Pa-ODY',  //账单失败
            'ZHI_NENG_ZHANG_DAN'    => 'Qqvrzh5xq7Ptfmi7q2Jrrp0rY10grktbUKLH6Pa-ODY',  //智能账单
            'AWARD_REMIND'          => 'niTiIfgRDEOvZkoQNnzi6-16qOTEL1ImiK-cwtICYp8',  //红包过期提醒
            'AWARD_ARRIVE'          => '6gmnWPx1xiuryV-LVyRO1CoSz8agxxhlN8gRvolrkCY',   //红包到账提醒
            'ZHI_NENG_TI_XING'      => 'iUtHY1--gkSiQ1VnyVKLJGiO5xsiVh3fazlPgTlg46A',  //还款提醒
        ),
    );

    /**
     * redis相关配置
     */
    public static $_redis_key = array(
        'access_token_key'	=> 'weixin_api_access_token_key', //access_token存储位置
    );

    /**
     * 获取内外网配置信息
     * @param unknown $key 环境变量关键字
     */
    public static function get_certification_information($key){
        $env = self::get_run_enviment();
        return self::$_xiaobai_share[$env][$key];
    }

    /**
     * 获取内外网配置环境
     */
    public static function get_run_enviment(){
        $env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : (defined('SHELL_VARIABLE') ? SHELL_VARIABLE : 'rls');
        $env = isset(self::$_xiaobai_share[$env]) ? $env : 'rls';
        return $env;
    }
}
