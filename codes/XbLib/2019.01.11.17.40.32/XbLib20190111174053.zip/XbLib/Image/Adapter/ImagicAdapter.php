<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-8-24
 * UTF-8
 */

class XbLib_Image_Adapter_ImagicAdapter extends XbLib_Image_Abstract{
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::getImgObj()
	*/
	protected function loadImgObj($img_path) {
		// TODO Auto-generated method stub
		$this->img = new imagick( $img_path );
	}

	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::thumb()
	*/
	public function thumb($width, $height, $color=array()) {
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		$dst_width = 0;
		$dst_height = 0;
		$dst_x = 0;
		$dst_y = 0;
		
		// 无填充颜色 留白
		if (! empty ( $color )) {
			$file_extend = $this->image_mime_filter[$this->imagesize['mime']];
			$rgb = "rgb({$color['red']},{$color['green']},{$color['blue']})";
			$imp = new ImagickPixel($rgb);
			$dst_img =  new Imagick();
			$dst_img->newImage($width, $height,$imp, $file_extend);
			$dst_width = $width;
			$dst_height = $height;
		}
		
		// 原图比需要的扁 按照宽度缩放 否则 按照高度比缩放
		if ($this->imagesize [0] / $this->imagesize [1] > $width / $height) {
			//重新计算高度
			$height = intval ( $width / $this->imagesize [0] * $this->imagesize [1] );
				
		} else {
			$width = intval ( $height / $this->imagesize [1] * $this->imagesize [0] );
		}
		$this->width = $width;
		$this->height = $height;
		
		$this->img->thumbnailimage($width, $height);
		
		//合并画布画布
		if(!empty($color)){
			if($dst_height > $height){
				//调整高度居中位置
				$dst_y = intval(($dst_height - $height)/2);
			}
			if($dst_width > $width){
				//调整高度居中位置
				$dst_x = intval(($dst_width - $width)/2);
			}
			$dst_img->compositeimage($this->img, imagick::COMPOSITE_OVER, $dst_x, $dst_y);
			$this->img = $dst_img;
		}
		
	}
	
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::rotate()
	*/
	public function rotate($angle) {
		// TODO Auto-generated method stub
		$this->img->rotateimage('black', $angle);
		if (empty ( $this->img )) {
			return false;
		}
		// 重置长宽
		$this->imagesize [0] = $this->img->getimagewidth();
		$this->imagesize [1] = $this->img->getimageheight();
		return true;
	}
	
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::watermark()
	 * 未测试
	*/
	public function watermark($waterFilePath) {
		// TODO Auto-generated method stub
		$water_img = new Imagick($waterFilePath);
		if(empty($water_img)){
			return false;
		}
	}
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::output()
	 */
	public function output() {
		// TODO Auto-generated method stub
		header ( "content-type: {$this->imagesize ['mime']}" );
		echo $this->img;
	}

	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::save()
	 */
	public function save($newPath) {
		// TODO Auto-generated method stub
		return $this->img->writeimage($newPath);
	}
	/* (non-PHPdoc)
	 * @see XbLib_Image_Abstract::destroyImgResource()
	 */
	public function destroyImgResource() {
		// TODO Auto-generated method stub
		//释放资源
		$this->img->destroy();
	}



}