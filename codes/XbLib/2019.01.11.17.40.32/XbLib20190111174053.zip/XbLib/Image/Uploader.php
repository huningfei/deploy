<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-8-25
 * UTF-8
 */
class XbLib_Image_Uploader{
	private static $obj = null;
	private static $code_arr = array(
			'.jpg' => 255216,
			'.png' => 13780,
			'.gif' => 7173
	);
	
	/**
	 * 封闭构造
	 */
	private function __construct(){
		
	}
	
	/**
	 * 单例获取
	 * @return XbLib_Image_Uploader
	 */
	public static function getInstance(){
		if(empty(self::$obj)){
			self::$obj = new XbLib_Image_Uploader();
		}
		return self::$obj;
	}
	
	
	/**
	 * 上传文件
	 * @param unknown $savePath
	 * @return boolean|Ambigous <boolean, string>
	*/
	public function upload($savePath,&$real_filename='',&$real_extend=''){
		if(empty($savePath))
		{
			return false;
		}
		$imageData = $_POST['image_data'];

		$res = false;
		if(empty($imageData)){
			$res = $this->saveUploadImage($savePath,$real_filename,$real_extend);
		}else{
			$res = $this->saveBase64Image($savePath,$imageData,$real_filename,$real_extend);
		}
		return $res;
	}
	
	/**
	 * 存储Base64图片
	 * @param string $savePath
	 * @param string $imageData
	 * @return string|boolean
	 */
	private function saveBase64Image($savePath,$imageData,&$real_filename,&$real_extend){
		$imageData = base64_decode($imageData);
		if(empty($imageData)){
			return flase;
		}
	
		$file_name = $_POST['file_name'];
		if(empty($file_name)){
			$file_name = md5($imageData.rand(0, 9999));
		}
	
		//解析文件类型
		$binarr = unpack ( 'C2chars', $imageData );
		$file_extend = '';
		foreach ( self::$code_arr as $extend => $code ) {
			if ($code == $binarr ['chars1'] . $binarr ['chars2']) {
				$file_extend = $extend;
				break;
			}
		}
		if(empty($file_extend)){
			return false;
		}
	
		if(!file_exists($savePath)){
			if(!@mkdir($savePath,0777,true)){
				XbFunc_Log::write("SysImageError", "Can not make dir",$savePath);
				return false;
			}
		}
		$realpath = $savePath.'/'.$file_name.$file_extend;
		$real_filename = $file_name;
		$real_extend = $file_extend;
		//输出文件
		try {
			$file = fopen ( $realpath, "w" );
			fwrite ( $file, $imageData );
			fclose ( $file );
		} catch (Exception $e) {
			XbFunc_Log::write("SysImageError", "Can not make image file.",$e->getCode()."[{$e->getMessage()}]");
			return false;
		}
        return $file_name.$file_extend;
	}
	
	/**
	 * H5/Flash 上传
	 * @param string $savePath
	 * @return boolean
	 */
	private function saveUploadImage($savePath,&$real_filename,&$real_extend){
		$img_data = $_FILES['file']['tmp_name'];

		$size = getimagesize($img_data);
		$file_type = $size['mime'];
		if (!in_array($file_type, array('image/jpg', 'image/jpeg', 'image/pjpeg', 'image/png', 'image/gif'))) {
			return false;
		}
		$file_extend='';
		switch($file_type) {
			case 'image/jpg' :
			case 'image/jpeg' :
			case 'image/pjpeg' :
				$file_extend = '.jpg';
				break;
			case 'image/png' :
				$file_extend = '.png';
				break;
			case 'image/gif' :
				$file_extend = '.gif';
				break;
		}
		$file_name = md5(time().rand(0, 99999));

		if(!file_exists($savePath)){
			if(!@mkdir($savePath,0755,true)){
				XbFunc_Log::write("SysImageError", "Can not make dir",$savePath);
				return false;
			}
		}
		$realpath = $savePath.'/'.$file_name.$file_extend;
        //mv文件
        if(!@move_uploaded_file( $img_data, $realpath )){
            return false;
        }
        return $file_name.$file_extend;
	}
	
    //上传文件
    public function uploadxls($savePath){
        $img_data = $_FILES['file']['tmp_name'];


        $file_type = $_FILES['file']['type'];
        if (!in_array($file_type, array('application/octet-stream', 'application/vnd.ms-excel'))) {
            return false;
        }
        $file_extend='';
        switch($file_type) {
            case 'application/octet-stream' :
            case 'application/vnd.ms-excel' :
                $file_extend = '.xls';
                break;
        }
        $file_name = md5(time().rand(0, 99999));

        if(!file_exists($savePath)){
            if(!@mkdir($savePath,0755,true)){
                XbFunc_Log::write("SysImageError", "Can not make dir",$savePath);
                return false;
            }
        }
        $realpath = $savePath.'/'.$file_name.$file_extend;
        //mv文件
        if(!@move_uploaded_file( $img_data, $realpath )){
            return false;
        }
        return $file_name.$file_extend;
    }
}