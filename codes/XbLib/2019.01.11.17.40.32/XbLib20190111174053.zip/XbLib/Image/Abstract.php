<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-8-24
 * UTF-8
 */
abstract class XbLib_Image_Abstract{
	protected $process_img = null;
	protected $img = null;
	protected $imagesize = null;
	protected $image_mime_filter = array(
			'image/jpg' => 'jpg',
			'image/jpeg' => 'jpg',
			'image/pjpeg' => 'jpg',
			'image/png' => 'png',
			'image/gif' => 'gif'
	);
	protected $width = 0;
	protected $height = 0;
	
	
	/**
	 * 加载Image
	 * @param string $img_path
	 * @return boolean
	 */
	public function loadImage($img_path){
		if(!file_exists($img_path)){
			return false;
		}
		$imagesize = getimagesize($img_path);
		
		if(!isset($this->image_mime_filter[$imagesize['mime']])){
			return false;
		}
		$this->imagesize = $imagesize;
		$this->loadImgObj($img_path);
		if(empty($this->img)){
			return false;
		}
		return true;
	}
	
	/**
	 * 缩放
	 * @param unknown $width
	 * @param unknown $height
	 * @param array $color array('red'=>?,'green'=>?,'blue'=>?)
	 */
	abstract public function thumb($width,$height,$color=array());
	
	/**
	 * 旋转
	 * @param unknown $angle
	 */
	abstract public function rotate($angle);
	
	/**
	 * 水印
	 * @param unknown $waterFilePath
	 */
	abstract public function watermark($waterFilePath);
	
	/**
	 * 输出到网页
	 */
	abstract public function output();
	
	/**
	 * 保存
	 * @param unknown $newPath
	 * @return boolean
	 */
	abstract public function save($newPath);
	
	/**
	 * 释放资源
	 */
	abstract public function destroyImgResource();
	
	/**
	 * 加载Image对象
	 * @param unknown $img_path
	 */
	abstract protected function loadImgObj($img_path);
	
}