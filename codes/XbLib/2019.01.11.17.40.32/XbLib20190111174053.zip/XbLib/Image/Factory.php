<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-8-24
 * UTF-8
 */
class XbLib_Image_Factory{
	
	private function __construct(){
		
	}
	
	/**
	 * 获取图像适配器
	 * @throws Exception
	 * @return XbLib_Image_Abstract
	 */
	static function getImgAdapter(){
		if(extension_loaded('imagick')){
			return new XbLib_Image_Adapter_ImagicAdapter();
		}
		if(extension_loaded('gd')){
			return new XbLib_Image_Adapter_GdAdapter();
		}
		throw new Exception("Can not found the graphic lib.");
	}
	
	
}