<?php
/**
 * @desc    通道相关工具，如：验证时间，验证通道剩余额度，验证用户在本通道剩余额度
 */
class XbLib_ChannelTools{
    private static $obj;

    /**
     * 单例
     * @return null|XbLib_ChannelTools
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_ChannelTools();
        }
        return self::$obj;
    }

    /**
     * @desc    验证通道交易时间
     * @date    string  $channelDate    通道交易时间
     * @date    string  $week           通道交易时间
     * @return  boolen  $return         true|false
     */
    public static function checkChannelTime($channelDate, $week){
        $w    = date('w');
        $weekArr = explode(',', $week);
        if(!in_array($w, $weekArr)) return false;
        $time    = time();
        $date    = date('Y-m-d');
        $timeArr = explode('-', $channelDate);
        $start   = strtotime($date.' '.$timeArr[0]);
        $end     = strtotime($date.' '.$timeArr[1]) + 60;
        if($time < $start || $time > $end){
            return false;
        }
        return true;
    }

    /**
     * @desc    计算手续费金额
     */
    public static function computeFee($amount, $rate, $fee){
        $rateAmount  = bcmul($amount, $rate, 2);
        $rateAmount1 = bcmul($amount, $rate, 4);
        if(bccomp($rateAmount1, $rateAmount, 4) == 1) $rateAmount = bcadd($rateAmount,'0.01', 2);
        return bcadd($rateAmount, $fee, 2);
    }

    /**
     * @desc    根据刷卡金额，计算平台总共得到多少钱
     */
    public static function countIncome($amount, $rate, $channel_rate, $fee, $channel_fee){
        $rateSub = bcsub($rate, $channel_rate, 4);
        $income  = bcmul($amount, $rateSub, 4);
        $feeSub  = bcsub($fee, $channel_fee, 4);
        $income  = bcadd($income, $feeSub, 4);
        return bcmul($income, 10000, 0);
    }
    public function checkChannelDayLimit(){
        /**/
    }

    public function handleImg(){

    }
    /**
     * @desc 校验通道是否支持此信用卡
     * */
    public  function checkChannelBank($channel_id,$bankCode,$bankType){
        $data['bankCode'] = $bankCode;
        $data['type'] = $bankType;
        //获取通道ID
        $channel_id =XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($channel_id)['channel_id'];
        $checkRes = XbLib_ChannelFunc_Channel::getInstance()->getChannelBankList($channel_id,$data);
        return $checkRes;
    }
}