<?php

/*
 * YIDUN_CAPTCHA_ID  验证码id
 * YIDUN_CAPTCHA_SECRET_ID  验证码密钥对id
 * YIDUN_CAPTCHA_SECRET_KEY  验证码密钥对key
 */

return array(
    'rls' => array(
        'YIDUN_CAPTCHA_ID'       => '8868ffbdca8346cf9171669f74e659d9',
        'YIDUN_CAPTCHA_SECRET_ID'       => '904e4fb3466d285e5d938b6825dd8778',
        'YIDUN_CAPTCHA_SECRET_KEY'     => 'e1768700150b4e4fe15cd6ef5bd1011a'
    ),
    'test' => array(
        'YIDUN_CAPTCHA_ID'       => '8868ffbdca8346cf9171669f74e659d9',
        'YIDUN_CAPTCHA_SECRET_ID'       => '904e4fb3466d285e5d938b6825dd8778',
        'YIDUN_CAPTCHA_SECRET_KEY'     => 'e1768700150b4e4fe15cd6ef5bd1011a'
    ),
    'local' => array(
        'YIDUN_CAPTCHA_ID'       => '8868ffbdca8346cf9171669f74e659d9',
        'YIDUN_CAPTCHA_SECRET_ID'       => '904e4fb3466d285e5d938b6825dd8778',
        'YIDUN_CAPTCHA_SECRET_KEY'     => 'e1768700150b4e4fe15cd6ef5bd1011a'
    )
);