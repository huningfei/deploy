<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-10
 * UTF-8
 */
class XbLib_Msg_Config{
	public static $ip_count = 50;
	public static $same_mobile_interval = 60;
	public static $same_mobile_count = 5;
	private static $type = array(
			"reg",
			"login",
			"changePwd",
            "binding",
	        "cardbind",
	        "awardremind",
	        "withdraw",
	        "changePhone"
	);

    /**
     * @param $type
     * @return bool|string
     */
	public static function getText($type){
		if(empty($type) || !in_array($type, self::$type)){
			return false;
		}
		
		$msg = "";
		switch ($type){
			case "reg":
				$msg = "【小白信用卡】注册验证码code，请及时输入完成验证，切勿泄露给他人。";
				break;
            case "login":
                $msg = "【小白信用卡】登录验证码code，请及时输入完成验证，切勿泄露给他人。";
                break;
            case "changePwd":
                $msg = "【小白信用卡】您本次找回密码的短信验证码为code，请及时输入完成验证，如非本人请忽略。";
                break;
            case "binding":
                $msg = "【小白信用卡】您本次完善手机号的短信验证码为code，请及时输入完成验证，如非本人请忽略。";
                break;
            case "cardbind":
                $msg = "【小白信用卡】您本次完善储蓄卡信息的短信验证码为code，请及时输入完成验证，如非本人请忽略。";
                break;
            case "awardremind":
                $msg = "【小白信用卡】Hi,您在小白卡管家账户中有一张money元红包明天就失效了，快去个人中心-我的奖励 领取吧！";
                break;
            case "withdraw":
                $msg = "您于time申请的money元的提现已到账，银行卡后四位为card。【小白卡管家】";
                break;
            case "changePhone":
                $msg = "【小白信用卡】更换手机号验证码code，请及时输入完成验证，切勿泄露给他人。";
                break;
			default:
				
		}
		
		return $msg;
	}
	
	
}