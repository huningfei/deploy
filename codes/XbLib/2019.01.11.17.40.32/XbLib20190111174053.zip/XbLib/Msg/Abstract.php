<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-10
 * UTF-8
 */
abstract class XbLib_Msg_Abstract{
	private static $ip_count = "SPAM_IP_SENDMSG_DIFF_COUNT_";
	private static $same_mobile_interval="SPAM_MOBILE_SENDMSG_INTERVAL_";
	private static $same_mobile_count="SPAM_MOBILE_SENDMSG_COUNT_";
	protected $channel = NULL;
	
	/**
	 * 检查一个spam
	 * @param unknown $ip
	 * @param unknown $mobile
	 * @return XbLib_WebError|boolean
	 */
	protected function checkSpam($ip,$mobile){
		$cache_factory = new XbCache_Factory();
		$cache_adapter = $cache_factory->getCacheAdapter();
		$ip=ip2long($ip);
		//计算统一ip发送短信总数量
		$ip_count_key = self::$ip_count.$ip;
		$count = $cache_adapter->get($ip_count_key);

		if($count>XbLib_Msg_Config::$ip_count){
			return new XbLib_WebError(4901);
		}
		//计算相同手机号的发送数量
		$same_mobile_count_key = self::$same_mobile_count.$mobile;
		$same_mobile_count = $cache_adapter->get($same_mobile_count_key);
		if($same_mobile_count>XbLib_Msg_Config::$same_mobile_count){
			return new XbLib_WebError(4902);
		}
		//手机号发送间隔
		$same_mobile_interval_key = self::$same_mobile_interval.$mobile;
		$same_mobile = $cache_adapter->get($same_mobile_interval_key);
		if(!empty($same_mobile)){
			return new XbLib_WebError(4903);
		}
		return true;
	}
	
	/**
	 * 增加一个spam
	 * @param unknown $ip
	 * @param unknown $mobile
	 * @return boolean
	 */
	protected function addSpam($ip,$mobile){
		$cache_factory = new XbCache_Factory();
		$cache_adapter = $cache_factory->getCacheAdapter();
		$now = time();
		$expire = strtotime(date("Y-m-d",strtotime("+1 day"))) - $now;
		$ip = ip2long($ip);
		//计算统一ip发送短信总数量
		$ip_count_key = self::$ip_count.$ip;
		$count = $cache_adapter->get($ip_count_key);
		$cache_adapter->set($ip_count_key, $count+1,$expire);

		//计算相同手机号的发送数量
		$same_mobile_count_key = self::$same_mobile_count.$mobile;
		$same_mobile_count = $cache_adapter->get($same_mobile_count_key);
		$cache_adapter->set($same_mobile_count_key, $same_mobile_count+1, $expire);
		
		//手机号发送间隔
		$same_mobile_interval_key = self::$same_mobile_interval.$mobile;
		$same_mobile = $cache_adapter->get($same_mobile_interval_key);
		$cache_adapter->set($same_mobile_interval_key, $now, XbLib_Msg_Config::$same_mobile_interval);
		return true;
	}
	
	/**
	 * 发送msg
	 * @param unknown $client_ip
	 * @param unknown $mobile
	 * @param unknown $msg
	 * @return XbLib_WebError|boolean
	 */
	function sendMsg($client_ip,$mobile,$msg){
		$res = $this->checkSpam($client_ip, $mobile);
		if($res instanceof XbLib_WebError){
			return $res;
		}
		//发送短信
		$res = $this->work($mobile,$msg);
		if(empty($res)){
			XbFunc_Log::write("SendMsg", "Failed","短消息发送失败,渠道：{$this->channel}");
			return false;
		}
		//增加spam
		$this->addSpam($client_ip, $mobile);
		return true;
	}
	
	/**
	 * 执行发送
	 * @param unknown $mobile
	 * @param unknown $msg
	 * @return boolean
	 */
	abstract function work($mobile,$msg); 
	
}