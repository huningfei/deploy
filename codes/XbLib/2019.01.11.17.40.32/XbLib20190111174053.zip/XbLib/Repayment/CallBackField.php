<?php
/**
 * @desc    支付通道回调
 * @author  yurong
 * @date    18.03.25
 */
class XbLib_Repayment_CallBackField{
    private static $obj;
    //易宝结算回调状态
    private static $yibao_sett_status = array(
        'RECEIVED'   =>1,//已接收
        'PROCESSING' =>2,//处理中
        'SUCCESSED'  =>3,//打款成功
        'FAILED'     =>4,//打款失败
        'REFUNED'    =>5,//已退款
        'CANCELLED'  =>6//已撤销
    );


    /*
     * */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Repayment_CallBackField();
        }
        return self::$obj;
    }
    /**
     *@desc  樱桃还款回调接口
     * @param  array $data   待处理数据
     * @param  int   $type   还款类型1：智能；2：一键
     */
    public function yingtaoCallBackField($data,$type){
        if( !$data) return false;
        XbFunc_Log::write('repaymentCallback','樱桃支付回调数据：'.$data);
        //根据通道对数据进行重组
        $datas = $this->checkData($data);//对数据先首次处理
        $new_data = $this->fujianmilianGetData($datas,$type);//对数据二次处理

        if($new_data['code'] != 200)return false;
        //通过channel_code 获取uid
//        $new_data['uid'] = XbModule_Repayment_UsersChannel::getInstance()->getUserId($new_data['channel_code'])['uid'];
        $userChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserId($new_data['channel_code']);
        if(!$userChannel) return false;
        $new_data['uid'] = $userChannel['uid'];
        $new_data['channel_key'] = $userChannel['channel_key'];
        //获取mch_id
        $mch_id = XbModule_Account_Users::getInstance()->getUserById($new_data['uid'])['mch_id'];
        if($type==1){
            $orderPlan =  XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanByOrderId($new_data['externalld']);
            if(!$orderPlan) return false;
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($orderPlan['oid']);
            if(!$order) return false;
            $new_data['oid'] =$orderPlan['oid'];
            $res = XbModule_Repayment_Order::getInstance($mch_id)->intelCallBackField($new_data);
            if($res && $orderPlan['issue'] == $order['plan_time']){
                $withdrawRes = XbModule_Repayment_Order::getInstance($mch_id)->orderPlanWithdraw($orderPlan, $order, $orderPlan['channel_id'], $orderPlan['channel_name']);
                if(!$withdrawRes){
                    XbFunc_Log::write('execRepaymentPlanError', '订单计划执行失败：代付提现失败'.json_encode($orderPlan));
                }
            }
        }else{
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByOrderId($new_data['externalld']);
            if(!$order) return false;
            $new_data['oid'] =$order['id'];
            //发起代付接口
            //创建结算订单号
            $new_data['orderId']    =  substr(XbModule_Account_OrderCode::getInstance()->getOrderCode(),0,18);
            $new_data['repaycardcode'] = $order['repaycardcode'];
            $new_data['repaycard'] = $order['repaycard'];
            $new_data['repaybank'] = $order['repaybank'];
            $new_data['realname'] = $order['realname'];
            $new_data['channel_id'] = $order['channel_id'];
            $new_data['day']        = date('d');
            $settRes = $this->withdraw($new_data);
            //由于通道原因，调用代付以及直接记录，后续查询业务有没有完成
            $new_data['play_status'] = (isset($settRes['code']) && $settRes['code'] == '0000') ? 1 : 3;
            $res = XbModule_Repayment_Order::getInstance($mch_id)->oneKeyCallBackField($new_data);
            /*if($settRes && ($settRes['code'] == '0000' || $settRes['code'] == '0100')){
                $new_data['play_status'] = $settRes['code'] == '0000' ? 1 : 3;
                $res = XbModule_Repayment_Order::getInstance($mch_id)->oneKeyCallBackField($new_data);
            }else{
                return false;
            }*/

        }
        if($res){
            return $res;
        }

        return false;
    }
    /**
     *@desc  杨桃还款回调接口
     * @param  array $data   待处理数据
     * @param  int   $type   还款类型1：智能；2：一键
     */
    public function yangtaoCallBackField($data,$type){
        if( !$data) return false;
        XbFunc_Log::write('repaymentCallback','杨桃支付回调数据：'.$data);
        //根据通道对数据进行重组
        $datas = $this->checkData($data);//对数据先首次处理

        $new_data = $this->fujianmilianGetData($datas,$type);//对数据二次处理

        if($new_data['code'] != 200)return false;
        //通过channel_code 获取uid
        $new_data['uid'] = XbModule_Repayment_UsersChannel::getInstance()->getUserId($new_data['channel_code'])['uid'];
        if(!$new_data['uid']) return false;
        //获取mch_id
        $mch_id = XbModule_Account_Users::getInstance()->getUserById($new_data['uid'])['mch_id'];
        if($type==1){
            $orderPlan =  XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanByOrderId($new_data['externalld']);
            if(!$orderPlan) return false;
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($orderPlan['oid']);
            if(!$order) return false;
            $new_data['oid'] =$orderPlan['oid'];
        }else{
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByOrderId($new_data['externalld']);
            if(!$order) return false;
            $new_data['oid'] =$order['id'];
        }

        $res = XbModule_Repayment_Order::getInstance($mch_id)->CallBackField($new_data,$type);
        if($res){
            return $res;
        }
        return false;
    }
    /**
     * @desc 发起代付请求
     * */
    public function withdraw($new_data){
        $data['order_id']       = $new_data['orderId'];
        $data['amount']         = (float)sprintf("%.2f",$new_data['after_amount']);
        $data['fee']            = $new_data['single_fee'];
        $data['channel_code']   = $new_data['channel_code'];
        $data['channel_key']    = $new_data['channel_key'];
        $data['bankCode']       = $new_data['repaycardcode'];
        $data['bankCardNumber'] = $new_data['repaycard'];
        $data['bank']           = $new_data['repaybank'];
        $data['realname']       = $new_data['realname'];
        $data['day']            = $new_data['day'];
        $res = XbLib_Repayment_Channel::getInstance()->settlement($new_data['channel_id'],$data);
        return $res;
    }
    /**
     * @desc 重组福建米联支付回调数据
     * @param  array $data   待处理数据
     * @param  int   $type   还款类型1：智能；2：一键
     * @return array $arr    返回重组数据
     * */
    public function fujianmilianGetData($data,$type){
        $arr = [];
        $arr['order_id'] = $data['ORDER_ID'];
        $arr['externalld'] = $data['ORDER_ID'];
        $arr['pay_time'] = $data['PAYCH_TIME'];
        $arr['pay_amount'] = $data['PAY_AMOUNT'];
        $arr['code'] = $data['RESP_CODE']=='0000'?200:$data['RESP_CODE'];
        $arr['status'] = $data['RESP_CODE']=='0000'?1:2;
        $arr['msg'] = $data['RESP_DESC'];
        $arr['channel_code'] = $data['USER_ID'];
        //计算实际到账金额以及手机费
        $uid = XbModule_Repayment_UsersChannel::getInstance()->getUserId($arr['channel_code'])['uid'];

        $mch_id = XbModule_Account_Users::getInstance()->getUserById($uid)['mch_id'];
        if($type==1){
            $orderPlan = XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanByOrderId($arr['externalld']);
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($orderPlan['oid']);
            $arr['paytime'] = $orderPlan['create_time'];
        }else{
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByOrderId($arr['externalld']);
            $arr['paytime'] = $order['create_time'];
        }


        $arr['rate'] = $order['rate'];
        $arr['fee'] = XbLib_Repayment_ChannelFunc::getWithdrawAmount($arr['pay_amount'], $order['rate'], $order['single_fee']);
        $arr['single_fee'] = $order['single_fee'];
        $arr['after_amount'] = $arr['pay_amount'] - $arr['fee'] ;
        return $arr;
    }

    //雅酷酷宝支付回调
    public function yakukubaoCallBackField($type, $data){
        $status_arr = array(
            'WAIT_PAY'      => 0,//等待付款(系统不会异步通知)
            'PAY_FINISHED'  => 1,//已付款(系统会异步通知)
            'TRADE_FAILED'	=> 2,//交易失败(系统会异步通知)
            'TRADE_FINISHED'=> 1,//交易结束(系统会异步通知）支付成功
            'TRADE_CLOSED'  => 2,//交易关闭 (系统会异步通知) 超时未支付
        );

        $datas = $this->checkData($data);//对数据先首次处理
        $status   = $status_arr[$datas['trade_status']];
        $order_id = $datas['outer_trade_no'];

        if ($type == 1){
            //一键还款
            $res_order_index = XbModule_Repayment_OrderIndex::getInstance()->getOrderIndexByOrderId($order_id);
            $callback_data['pay_time']  = strtotime($datas['gmt_payment']);
            $callback_data['serial_no'] = $datas['inner_trade_no'];
            $callback_data['msg']       = $datas['trade_status'];

            $res = XbModule_Repayment_Order::getInstance($res_order_index['order_table_num'])->yakuOneKeyCallBackField($status, $res_order_index, $callback_data);
        }elseif($type == 2){
            //智能还款
            $mch_id = 2;
            $orderPlan =  XbModule_Repayment_OrderPlan::getInstance($mch_id)->getOrderPlanByOrderId($order_id);
            if(!$orderPlan) return false;
            //获取主订单信息
            $order = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($orderPlan['oid']);
            if(!$order) return false;
            $new_data['uid'] = $orderPlan['uid'];
            $new_data['oid'] = $orderPlan['oid'];
            $new_data['order_id'] = $order_id;
            $new_data['status'] = $status;
            $new_data['fee'] = XbLib_Repayment_ChannelFunc::getWithdrawAmount($orderPlan['amount'],$order['rate'], $order['single_fee']);
            $new_data['after_amount'] = bcsub($orderPlan['amount'],$new_data['fee'],2);

            $res = XbModule_Repayment_Order::getInstance($mch_id)->intelCallBackField($new_data);
            if($res && $orderPlan['issue'] == $order['plan_time']){
                $withdrawRes = XbModule_Repayment_Order::getInstance($mch_id)->orderPlanWithdraw($orderPlan, $order, $orderPlan['channel_id'], $orderPlan['channel_name']);
                if(!$withdrawRes){
                    XbFunc_Log::write('execRepaymentPlanError', '订单计划执行失败：代付提现失败'.json_encode($orderPlan));
                }
            }
        }

        return $res;

    }

    //雅酷酷宝代付回调
    public function yakukubaoCallBackSettlement($type,$data) {
        $status_arr = array(
            'SUCCESS'       => 1,//成功(系统会异步通知)
            'FAILED'        => 2,//失败(系统会异步通知)
            'PROCESSING'	=> 0,//处理中(系统不会异步通知)
            'RETURNT_TICKET'=> 2,//银行退票(系统会异步通知)
        );
        $datas = $this->checkData($data);//对数据先首次处理

        $status   = $status_arr[$datas['withdraw_status']];
        $order_id = $datas['outer_trade_no'];

        $res_order_play = XbModule_Repayment_Order::getInstance()->getPlayOrderByPlayNo($order_id);
        $res_order_index = XbModule_Repayment_OrderIndex::getInstance()->getOrderIndexByOrderId($res_order_play['order_no']);

        $res = XbModule_Repayment_Order::getInstance($res_order_index['order_table_num'])->yakuOneKeyCallBackSettlement($status, $res_order_index, $res_order_play, $callback_data);

        return $res;
    }

    /**
     *@desc 订单查询
     */
    public function tradeRevice($data){
        $res = XbLib_ChannelFunc_Channel::getInstance()->transfer($data['channel_id'],$data);
        return $res;
    }
    public function checkData($data){
        if(!is_null(json_decode($data))){
            $new_data = json_decode($data,true);
        }else if(strpos($data,'&')){
            $datas = urldecode($data);
            parse_str($datas,$new_data);
        }else if(is_array($data)){
            $new_data = $data;
        }else{
            $new_data = $data;
        }
        return $new_data;
    }
}