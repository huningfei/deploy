<?php
/**
 * @desc    还款通道调用
 * @author  qien
 * @date    18.04.13
 */
class XbLib_Repayment_Channel{
    private static $obj;
    private $channelObj = array();
    private $channel = array(
//        1 => 'milianYingtao'
//        2 => 'milianYangtao'
        5 => 'YaKuKuBao'
    );

    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Repayment_Channel();
        }
        return self::$obj;
    }

    public function getChannelObj($channel){
        if(!isset($channelObj[$channel])){
            $channelFactory = new XbLib_Repaymentchannel_Factory($channel);
            $channelObj[$channel] = $channelFactory->getRepaymentchannelAdapter();
        }
        return $channelObj[$channel];
    }

    /**
     * @desc    注册各通道
     * @param   array   $data       用户信息
     * @return  array   $return     返回注册状态
     */
    public function signUp($data){
        $return = array(
            'code'        => 200,
            'msg'         => '',
            'channelInfo' => array()
        );
        foreach($this->channel as $k=>$v){
            $channelInfo = XbModule_Repayment_Channel::getInstance()->getChannelByChannelid($k);
            if($channelInfo){
                $channelObj = $this->getChannelObj($v);
                if(!$channelObj->checkChannelBank($data['bankCardCode'])) continue;
                $signUpInfo = $channelObj->buildSignData($data)->signUp();
                if($signUpInfo){
                    $channel_key = isset($signUpInfo['channel_key']) ? $signUpInfo['channel_key'] : '';
                    $return['channelInfo'][] = array('channel_id' => $k, 'channel_code' => $signUpInfo['channel_code'], 'channel_key' => $channel_key);
                }
            }
        }
        return $return;
    }

    /**
     * @desc    用户注册通道
     * @param   int     $channel_id     通道channel_id
     * @param   array   $data           下单数据
     * @return  array   $return         返回下单资料
     */
    public function userSignUp($channel_id, $data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $res = $channelObj->buildSignData($data)->signUp();
        return $res;
    }

    /**
     * @desc    用户下单
     * @param   int     $channel_id     通道channel_id
     * @param   array   $data           下单数据
     * @return  array   $return         返回下单资料
     */
    public function createOrder($channel_id, $data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $res = $channelObj->buildSignData($data)->transaction();
        return $res;
    }

    /**
     *@desc 结算接口
     */
    public function settlement($channel_id,$data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->withdraw();
        return $result;
    }

    /**
     *@desc 订单查询
     */
    public function checkOrder($channel_id,$data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->checkOrder();
        return $result;
    }

    /**
     *@desc     查询用户余额
     */
    public function getBalance($channel_id,$data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->getBalance();
        return $result;
    }

    /**
     *@desc 支付查询
     */
    public function queryOrder($channel_id,$data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->queryOrder();
        return $result;
    }

    /**
     *@desc 代付查询
     */
    public function queryPayOrder($channel_id,$data){
        if(!isset($this->channel[$channel_id])) return false;
        $channelObj = $this->getChannelObj($this->channel[$channel_id]);
        $result = $channelObj->buildSignData($data)->queryPayOrder();
        return $result;
    }
}