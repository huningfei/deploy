<?php
/**
 * Solo检索
 * @author NengZhi
 * 2014-10-9
 * UTF-8
 */
class XbLib_SolrSearch {

	private static $obj = null;
	/**
	 * URL
	 * @var unknown
	 */
	private $url = 'http://127.0.0.1:8080/solr/collection1/select?';
	
	/**
	 * 获取单例对象
	 * @param string $hl
	 * @param number $timeout
	 * @return TyLib_SolrSearch
	 */
	public static function getInstance(){
		if(is_null(self::$obj)){
			self::$obj = new XbLib_SolrSearch();
		}
		
		return self::$obj;
	}
	
	
	/**
	 * 设定条件
	 * @param unknown $str 要查询的关键词
	 * @param unknown $type 查询类型 @valueType: wt,thread,article
	 * @param unknown $typeData 数据用途(1相关,2搜索)
	 * @param unknown $custom 自定义条件
	 * @param unknown $start 起始位置
	 * @param unknown $limit 获得条数
	 * @param boolean $hl 是否高亮
     * @return array()   
	 */
	public function setParam($str, $typeData, $type, $start, $limit,$hl=true, $custom) {
		$arr = array ();
		$norm_query = preg_replace ( '/[\+|\-|\&|\||\!|\(|\)|\{|\}|\[|\]|\^|"|\~|\*|\?|\:|\\\\|\/]/', '', $str );
		$arr ['start'] = $start;
		$arr ['rows'] = $limit;
        $arr['wt'] = 'json';
        $arr['indent'] = 'true';
        $arr['defType'] = 'edismax';
        $arr['q.alt'] = "type:$type";
		$arr ['fq'] = "type:$type";
        if($type == 'wt' or $type == 'thread'){
            if($typeData == 1){
              $arr ['qf'] = 'subject';  
            }else{
              $arr ['hl.fl'] = 'subject message';
              $arr ['qf'] = 'subject message';  
            }
        }
        if($type == 'article'){
            if(typeData == 1){
              $arr ['qf'] = 'title';  
            }else{
              $arr ['hl.fl'] = 'title summary';
              $arr ['qf'] = 'title summary';  
            }
        }
		if ($hl) {
			$arr ['hl'] = 'true';
			$arr ['hl.requireFieldMatch'] = 'false';
			$arr ['hl.usePhraseHighlighter'] = 'true';
			$arr ['hl.highlightMultiTerm'] = 'true';
			$arr ['hl.simple.pre'] = '<em class="c_color">';
			$arr ['hl.simple.post'] = '</em>';
		}
		$encode = mb_detect_encoding($norm_query);
		if($encode != 'UTF-8'){
			$norm_query = mb_convert_encoding ( $norm_query, 'UTF-8', $encode );
		}
		$arr ['q'] = $norm_query;
		
		$url = $this->url . $custom . http_build_query ($arr);
		return $this->curlHttp($url);
	}
	
	/**
	 * 提交 并获得数据
	 * 别忘了time out
	 */
	private function curlHttp($url) {
		$ch = curl_init ();
		curl_setopt ($ch, CURLOPT_URL, $url);
		curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_TIMEOUT,2);
		curl_setopt ($ch, CURLOPT_HEADER, 0);
		$output = curl_exec ($ch);
		curl_close ($ch);
		$contentData = json_decode($output,true);
        return $contentData['response'];
	}
}
