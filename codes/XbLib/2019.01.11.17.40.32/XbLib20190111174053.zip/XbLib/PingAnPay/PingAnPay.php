<?php
/**
 * @desc 	平安银行代付系统
 */
class XbLib_PingAnPay_PingAnPay {
	// 标记为******的都需要配置，如果修改配置的话，请参考文档修改配置项，如果不需要填，这留空位
	public $version = 'A001'; // 报文头(4位)
	public $system = '01'; // 目标系统(2位)
	public $charset = '02'; // 字符集UTF8(2位)
	public $protocol = '02'; // 通讯协议 http(2位)
	public $account; // 外联客户代码*********(20位)
	public $messagelenth; // 接收报文长度*********(10位)
	public $tradeCode; // 交易码*********(6位)
	                   // public $operator = ' '; //操做员代码(5位)
	public $operator = '00000'; // 操做员代码(5位)
	public $type = '01'; // 服务类型(2位)
	public $date; // 交易日期yyyymmddhhmmss*********(14位)
	public $orderId; // 请求方系统流水号*********(20位)
	public $returnCode = '000000'; // 返回码(6位)
	public $returnDesc = '0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'; // 返回描述(100位)
	                                                                                                                             // public $followTag = ' '; //后续包标志(1位)
	public $followTag = '0'; // 后续包标志(1位)
	                         // public $followTime = ' '; //后续包请求次数(3位)
	public $followTime = '000'; // 后续包请求次数(3位)
	                            // public $signTag = ' '; //签名标识(1位)
	public $signTag = '0'; // 签名标识(1位)
	                       // public $signType = ' '; //签名数据包格式(1位)
	public $signType = '0'; // 签名数据包格式(1位)
	                        // public $signAlgorithm = ' '; //签名算法(12位)
	public $signAlgorithm = '000000000000'; // 签名算法(12位)
	public $signLength = '0000000000'; // 签名数据长度(10位)
	public $fileCount = '0'; // 附件数目(1位)
	private static $obj;
	private static $url = 'http://127.0.0.1:7072';
	private $message;
	private $body;
	private $accountNo; // 签约账号
	private $tradeType; // 交易类型
	
	/**
	 * 构造方法
	 */
	function __construct() {
		// 获取环境
		$env = getenv ( 'RUNTIME_ENVIROMENT' ) ? getenv ( 'RUNTIME_ENVIROMENT' ) : (defined ( 'SHELL_VARIABLE' ) ? SHELL_VARIABLE : '');
		$env = empty ( $env ) ? 'local' : $env;
		$this->env = $env;
		//if ($env == "rls") {
			$this->account   = '00201240000000041000';
			$this->accountNo = '15000092160969';
		/*} else {
			$this->account   = '00901020000000011000';
			$this->accountNo = '11014609385000';
		}*/
	}
	
	/**
	 * 实例化类
	 */
	static public function getInstance() {
		if (! self::$obj) {
			self::$obj = new XbLib_PingAnPay_PingAnPay ();
		}
		return self::$obj;
	}
	
	/**
	 * 获取签约账号
	 */
	public function getAccountNo() {
		return $this->accountNo;
	}
	
	/**
	 * 设置请求类型
	 *
	 * @param int $type
	 *        	设置类型
	 * @return object $retrun $this
	 */
	public function setType($type) {
		switch ($type) {
			case 1 :
				$this->tradeCode = 'KHKF03'; // 单笔付款申请
				break;
			case 2 :
				$this->tradeCode = 'KHKF04'; // 单笔付款结果查询
				break;
			case 3 :
				$this->tradeCode = 'KHKF01'; // 批量付款文件提交
				break;
			case 4 :
				$this->tradeCode = 'KHKF02'; // 批量付款结果查询
				break;
			case 11 :
				$this->tradeCode = 'FILE01'; // FILE01 文件上传接口
				break;
			case 12 :
				$this->tradeCode = 'FILE02'; // FILE02 文件上传和下载进度查询
				break;
			case 13 :
				$this->tradeCode = 'FILE03'; // FILE03 文件下载
				break;
			default :
				$this->tradeCode = '000000';
				break;
		}
		$this->tradeType = $type;
		return $this;
	}
	
	/**
	 * 组织请求消息 报文头|报文消息
	 *
	 * @param array $data
	 *        	设置数据，订单号
	 * @return object $return 返回this
	 */
	public function buildMessage($data) {
		if ($this->tradeType == 1) {
			// 单笔付款申请
			$this->requestSingleTradeBody ( $data );
			$this->setMessageHeader ( $data ['orderNo'] );
		} elseif ($this->tradeType == 2) {
			// 单笔付款结果查询
			$this->checkSingleTradeBody ( $data );
			$this->setMessageHeader ( $data ['orderNo'] );
		} elseif ($this->tradeType == 3) {
			// 批量付款文件提交
			$this->requestBatchTradeBody ( $data );
			$this->setMessageHeader ( $data ['BatchNo'] );
		} elseif ($this->tradeType == 4) {
			// 批量付款结果查询
			$this->checkBatchTradeBody ( $data );
			$this->setMessageHeader ( $data ['BatchNo'] );
		} elseif ($this->tradeType == 11) {
			// FILE01 文件上传接口
			$this->uploadBody ( $data );
			$this->setMessageHeader ( $data ['TradeSn'] );
		} elseif ($this->tradeType == 12) {
			// FILE02 文件上传和下载进度查询
			$this->uploadQueryBody ( $data );
			$this->setMessageHeader ( $data ['TradeSn'] );
		} elseif ($this->tradeType == 13) {
			// FILE03 文件下载
			$this->downloadBody ( $data );
			$this->setMessageHeader ( $data ['TradeSn'] );
		}
		return $this;
	}
	
	/**
	 * 请求
	 */
	public function request() {
		$sendMessage = $this->message . $this->body;
		$header = array (
				'Content-Type","text/xml; charset=UTF-8'
		);
		$res = $this->curlPost ( self::$url, $sendMessage, $header );
		$res = $this->conversion_coding ( $res, 'utf-8' );
		XbFunc_Log::write ( 'pingan', 'request-' . $this->tradeCode, $res );
		if (empty ( $res )) {
            XbFunc_Log::write ( 'pingan', 'request', self::$url );
            XbFunc_Log::write ( 'pingan', 'request', $sendMessage );
            XbFunc_Log::write ( 'pingan', 'request', json_encode ( $header ) );
		}
		$return ['returnCode'] = $this->parseReturnCode ( $res );
		$return ['headerStatus'] = $this->parseMessageHeader ( $res );
		$return ['bodyMsg'] = $this->parseMessageBody ( $res );
        XbFunc_Log::write ( 'pingan', 'response-' . $this->tradeCode, json_encode($return) );
		return $return;
	}
	
	/*
	 * @desc 组织设置报文头
	 * @param
	 */
	public function setMessageHeader($orderNo) {
		$this->messagelenth = str_pad ( strlen ( $this->body ), 10, '0', STR_PAD_LEFT );
		$this->orderId = $orderNo;
		$this->date = date ( 'YmdHis' );
		/* 组装报文头 */
		$this->message = $this->version . $this->system . $this->charset . $this->protocol . $this->account . $this->messagelenth . $this->tradeCode . $this->operator . $this->type . $this->date . $this->orderId . $this->returnCode . $this->returnDesc . $this->followTag . $this->followTime . $this->signTag . $this->signType . $this->signAlgorithm . $this->signLength . $this->fileCount;
	}
	
	/**
	 * 单笔付款申请（xml格式）
	 */
	public function requestSingleTradeBody($data) {
		$mark = $data ['mark'] ? $data ['mark'] : '';
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><OrderNumber>' . $data ['orderNo'] . '</OrderNumber><AcctNo>' . $this->accountNo . '</AcctNo><BusiType>00000</BusiType><CorpId></CorpId><CcyCode>RMB</CcyCode><TranAmount>' . $data ['amount'] . '</TranAmount><InAcctNo>' . $data ['bankCardNo'] . '</InAcctNo><InAcctName>' . $data ['username'] . '</InAcctName><InAcctBankName></InAcctBankName><InAcctBankNode></InAcctBankNode><Mobile></Mobile><Remark>' . $mark . '</Remark></Result>';
	}
	
	/**
	 * 单笔付款结果查询（xml格式）
	 */
	public function checkSingleTradeBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><OrderNumber>' . $data ['orderNo'] . '</OrderNumber><AcctNo>' . $this->accountNo . '</AcctNo></Result>';
	}
	
	/**
	 * 批量付款文件提交（xml格式）
	 */
	public function requestBatchTradeBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><BatchNo>' . $data ['BatchNo'] . '</BatchNo><AcctNo>' . $this->accountNo . '</AcctNo><BusiType>00000</BusiType><CorpId></CorpId><TotalNum>' . $data ['TotalNum'] . '</TotalNum><TotalAmount>' . $data ['TotalAmount'] . '</TotalAmount><FileName>' . $data ['FileName'] . '</FileName><RandomPwd>' . $data ['RandomPwd'] . '</RandomPwd><HashData></HashData><SignData></SignData></Result>';
	}
	
	/**
	 * 批量付款结果查询（xml格式）
	 */
	public function checkBatchTradeBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><BatchNo>' . $data ['BatchNo'] . '</BatchNo><AcctNo>' . $this->accountNo . '</AcctNo></Result>';
	}
	
	/**
	 * FILE01 文件上传接口（xml格式）
	 */
	public function uploadBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><TradeSn>' . $data ['TradeSn'] . '</TradeSn><FileName>' . $data ['FileName'] . '</FileName><FilePath>/home/yx/sites/pinganFile</FilePath></Result>';
	}
	
	/**
	 * FILE02 文件上传和下载进度查询（xml格式）
	 */
	public function uploadQueryBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><TradeSn>' . $data ['TradeSn'] . '</TradeSn></Result>';
	}
	
	/**
	 * FILE03 文件下载（xml格式）
	 */
	public function downloadBody($data) {
		$this->body = '<?xml version="1.0" encoding="UTF-8"?><Result><TradeSn>' . $data ['TradeSn'] . '</TradeSn><FileName>' . $data ['FileName'] . '</FileName><FilePath>' . $data ['FilePath'] . '</FilePath><RandomPwd>' . $data ['RandomPwd'] . '</RandomPwd></Result>';
	}
	
	/**
	 * 发送http请求 @note:因设置是xml通讯，故无法调用CurlHttp类
	 *
	 * @return object $return 返回请求结果
	 */
	public function curlPost($url, $postData, $header) {
		$ch = curl_init ();
		curl_setopt_array ( $ch, array (
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => $postData,
				CURLOPT_HTTPHEADER => $header
		) );
		$res = curl_exec ( $ch );
		curl_close ( $ch );
		return $res;
	}
	
	/**
	 * 解析报文头，获取返回码
	 */
	public function parseReturnCode($result) {
		$code = trim ( substr ( $result, 87, 6 ) );
		return $code;
	}
	
	/**
	 * 解析报文头，获取报文头状态
	 */
	public function parseMessageHeader($result) {
		$status = trim ( substr ( $result, 93, 100 ) );
		return $status;
	}
	
	/**
	 * 解析Xml，返回解析后的类
	 */
	public function parseMessageBody($result) {
		// $xml = substr ( $result, 222 );
		$xml = substr ( $result, strpos ( $result, '<?xml' ) );
		if (substr ( $xml, 20, 14 ) == 'encoding="GBK"') {
			$xml = iconv ( 'utf-8', 'gbk', $xml );
		}
		return $xml ? json_decode ( json_encode ( simplexml_load_string ( $xml ) ), true ) : array ();
	}
	
	/**
	 * 数据转码
	 */
	public function conversion_coding($str, $code) {
		$encode = mb_detect_encoding ( $str, array (
				'UTF-8',
				'GBK',
				'GB2312',
				'BIG5',
				'ASCII'
		) );
		if ($encode == $code or ! $encode) {
			return $str;
		}
		if (! is_string ( $str )) {
			return $str;
		}
		if ($encode === 'GB2312' or $encode === 'GBK') {
			$encode = $encode . '//IGNORE';
		}
		return iconv ( $encode, $code, $str );
	}
}