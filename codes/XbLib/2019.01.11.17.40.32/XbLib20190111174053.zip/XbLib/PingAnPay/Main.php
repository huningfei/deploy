<?php
/**
 * 2017-03-07
 * UTF-8
 */
class XbLib_PingAnPay_Main {
    public static $obj=null;

    /**
     * 实例化类
     */
    static public function getInstance() {
        if (! self::$obj) {
            self::$obj = new XbLib_PingAnPay_Main ();
        }
        return self::$obj;
    }

	/**
	 * 平安银行批量支付 - 处理步骤1
	 * 文件上传接口(FILE01)
	 */
	public function createFile($data) {
		// 判断订单号和列表是否为空
		if (empty($data ['TradeSn']) || empty($data ['TradeList'])) {
			return false;
		}
        $TotalAmount = '0';
		foreach ( $data ['TradeList'] as $row ) {
			$lineStr [] = $row ['Order_id'] . '|::|' . $row ['InAcctNo'] . '|::|' . $row ['InAcctName'] . '|::||::||::||::|' . $row ['TranAmount'] . '|::|' . $row ['Remark'] . '|::||::|' . $row ['Mobile']; // 明细行字段 20160325201300001|::|6226090000000048|::|张三|::||::||::||::|150.00|::|厦门木材有限公司代付工资|::||::|18100000000
			$TotalAmount = bcadd($TotalAmount, $row ['TranAmount'], 2);
		}
		$TotalNum = count ( $lineStr );
		$TotalAmount = number_format ( $TotalAmount, 2, '.', '' );
		// 写入的内容
		$accountNo = XbLib_PingAnPay_PingAnPay::getInstance ()->getAccountNo();
		$content = $accountNo . '|::|' . $TotalNum . '|::|' . $TotalAmount . PHP_EOL; // 汇总行字段 11014609385000|::|3|::|500.00
		foreach ( $lineStr as $key => $hang ) {
			$content .= $key + 1 != $TotalNum ? $hang . PHP_EOL : $hang;
		}
		// 创建文件夹，并给777的权限（所有权限）
		$path = '/home/yx/sites/pinganFile/';
		if (! is_dir ( $path )) {
			mkdir ( $path, 0777 );
		}
		// 写入的文件
		$attachment = $data ['TradeSn'] . '.txt';
		$file = $path . $attachment;
		$content = XbLib_Function::getInstance ()->conversion_coding ( $content, 'GBK' );
		file_put_contents ( $file, $content );
		$content = file_get_contents ( $file );
		if (empty($content)) {
            return false;
		}
		// FILE01 文件上传接口
		$data = array (
				'TradeSn'  => $data ['TradeSn'],
				'FileName' => $attachment
		);
		$res_file01 = XbLib_PingAnPay_PingAnPay::getInstance ()->setType ( 11 )->buildMessage ( $data )->request ();
		if ($res_file01 ['returnCode'] != '000000') {
			if (empty($res_file01 ['returnCode'])) {
                return false;
			} else {
                return false;
			}
		}
		return array( $res_file01 ['returnCode'], array (), str_replace ( ':', '', $res_file01 ['headerStatus'] ) );
	}
	
	/**
	 * 平安银行批量支付 - 处理步骤2
	 * 文件上传和下载进度查询(FILE02) -> 批量付款文件提交(KHKF01)
	 */
	public function payment($data) {
		// 判断data是否为空
		if (empty($data)) {
			return false;
		}
		// 判断订单号是否为空
		if (empty($data ['TradeSn']) || empty($data ['NewTradeSn']) || empty($data ['TotalNum']) || empty($data ['TotalAmount'])) {
            return false;
		}
		// FILE02 文件上传和下载进度查询
		$sendData = array (
				'TradeSn' => $data ['TradeSn']
		);
		$res_file02 = XbLib_PingAnPay_PingAnPay::getInstance ()->setType ( 12 )->buildMessage ( $sendData )->request ();
		if ($res_file02 ['returnCode'] != '000000' || empty ( $res_file02 ['bodyMsg'] ['RandomPwd'] )) {
			if (empty($res_file02 ['returnCode'])) {
                return false;
			} else {
                return false;
			}
		}
		if(strpos($res_file02['bodyMsg']['Code'], 'U') !== false){
            return array('code' => '201', 'message' => '文件上送中，请稍后重试');
        }elseif ($res_file02['bodyMsg']['Code'] != 'F0') {
            return false;
		}
		// KHKF01 批量付款文件提交
		$sendData = array (
				'BatchNo'     => $data ['NewTradeSn'],      // 批次号
				'TotalNum'    => $data ['TotalNum'],        // 总笔数
				'TotalAmount' => $data ['TotalAmount'],     // 总金额
				'Remark'      => '',                        // 批次备注
				'FileName'    => $res_file02 ['bodyMsg'] ['FileName'],  // 文件名称
				'RandomPwd'   => $res_file02 ['bodyMsg'] ['RandomPwd']
		);
		$res_KHKF01 = XbLib_PingAnPay_PingAnPay::getInstance ()->setType ( 3 )->buildMessage ( $sendData )->request ();
		if ($res_KHKF01 ['returnCode'] != '000000') {
			return false;
		}
		return array( $res_KHKF01 ['returnCode'], array (), str_replace ( ':', '', $res_KHKF01 ['headerStatus'] ) );
	}
	
	/**
	 * 平安银行处理步骤3
	 * 批量付款文结果查询(KHKF02) -> 文件下载(FILE03)
	 */
	public function getQueryResult($data) {
		// 判断data是否为空
		if (empty($data)) {
			return false;
		}
		if (empty($data ['TradeSn']) || empty($data ['NewTradeSn'])) {
			return false;
		}
		// KHKF02 批量付款文结果查询
		$sendData = array (
				'BatchNo' => $data ['TradeSn']
		);
		$res_KHKF02 = XbLib_PingAnPay_PingAnPay::getInstance ()->setType ( 4 )->buildMessage ( $sendData )->request ();
		if ($res_KHKF02 ['returnCode'] != '000000') {
			return false;
		}
		if ($res_KHKF02 ['bodyMsg'] ['BatchStt'] == 30) {
            return array( 'code' => '401',  'message' => '订单打款失败，请联系技术处理' );
		} else if ($res_KHKF02 ['bodyMsg'] ['BatchStt'] == 40) {
            return array( 'code' => '402',  'message' => '订单正在处理中' );
		}
		// FILE03 文件下载
		$sendData = array (
				'TradeSn'   => $data ['NewTradeSn'],                    // 新的批次号，供FILE03下载使用
				'FileName'  => $res_KHKF02 ['bodyMsg'] ['FileName'],
				'FilePath'  => '/home/yx/sites/pinganFile/',
				'RandomPwd' => $res_KHKF02 ['bodyMsg'] ['RandomPwd']
		);
		$res_FILE03 = XbLib_PingAnPay_PingAnPay::getInstance ()->setType ( 13 )->buildMessage ( $sendData )->request ();
		if ($res_FILE03 ['returnCode'] != '000000') {
			return false;
		}
		sleep(10);
		// 写入的文件
		$attachment = $res_KHKF02 ['bodyMsg'] ['FileName'];
		$path = '/home/yx/sites/pinganFile/';
		$file = $path . $attachment;
		$content = file_get_contents ( $file );
		$content = XbLib_PingAnPay_PingAnPay::getInstance ()->conversion_coding ( $content, 'utf-8' );
		$contentArr = explode ( PHP_EOL, $content );
		$summary = array_shift ( $contentArr );
		// 汇总行字段
		$summaryArr = explode ( '|::|', $summary );
		$syntheticData ['TotalNum'] = $summaryArr [0]; // 总笔数
		$syntheticData ['TotalAmount'] = $summaryArr [1]; // 总金额
		$syntheticData ['SuccessNum'] = $summaryArr [2]; // 成功笔数
		$syntheticData ['SuccessAmount'] = $summaryArr [3]; // 成功金额
		$syntheticData ['FailureNum'] = $summaryArr [4]; // 失败笔数
		$syntheticData ['FailureAmount'] = $summaryArr [5]; // 失败金额
		$syntheticData ['AbnormalNum'] = $summaryArr [6]; // 异常笔数
		$syntheticData ['AbnormalAmount'] = rtrim($summaryArr [7]);
		// 明细行字段
		$detailArr = $contentArr;
		foreach ( $detailArr as $key => $row ) {
			$rowArr = explode ( '|::|', $row );
			$syntheticData ['detail'] [$key] ['Order_id'] = $rowArr [0]; // 总笔数
			$syntheticData ['detail'] [$key] ['InAcctNo'] = $rowArr [1]; // 总笔数
			$syntheticData ['detail'] [$key] ['InAcctName'] = $rowArr [2]; // 总笔数
			$syntheticData ['detail'] [$key] ['TranAmount'] = $rowArr [3]; // 总笔数
			$syntheticData ['detail'] [$key] ['Poundage'] = $rowArr [4]; // 总笔数
			$syntheticData ['detail'] [$key] ['ReturnCode'] = $rowArr [5]; // 总笔数
			$syntheticData ['detail'] [$key] ['ReturnMessage'] = $rowArr [6]; // 总笔数
		}
		if (empty ( $summaryArr ) || empty ( $detailArr )) {
			return array( 'code' => '401',  'message' => '文件格式异常，请及时联系技术处理' );
		}
		return $syntheticData;
	}
}