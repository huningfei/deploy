<?php
/**
* @author znz
* 2017年08月28日
* UTF-8
*/
class XbLib_WechatTool_Config{
	/**
	 * 微信配置信息
	 * @var unknown
	 */
	private static $_certification_information = array(
			'local' => array(
					'token'=>'xiaobai', //填写你设定的key
					'encodingaeskey'=>'7ecejQ8zTkmJ1g8nRgOKMzrLA8bgiyxkpmPQMfwfQRK', //填写加密用的EncodingAESKey
					'appid'=>'wx9259dfc3b3f2ff9c', //填写高级调用功能的app id
					'appsecret'=>'e6e80a16921907a0eb6322184a25a7ad', //填写高级调用功能的密钥
					'partnerid'=>'', //财付通商户身份标识
					'partnerkey'=>'', //财付通商户权限密钥Key
					'paysignkey'=>'' //商户签名密钥Key
			),
			'rls' => array(
					'token'=>'xiaobai', //填写你设定的key
					'encodingaeskey'=>'7ecejQ8zTkmJ1g8nRgOKMzrLA8bgiyxkpmPQMfwfQRK', //填写加密用的EncodingAESKey
					'appid'=>'wx9259dfc3b3f2ff9c', //填写高级调用功能的app id
					'appsecret'=>'e6e80a16921907a0eb6322184a25a7ad', //填写高级调用功能的密钥
					'partnerid'=>'', //财付通商户身份标识
					'partnerkey'=>'', //财付通商户权限密钥Key
					'paysignkey'=>'' //商户签名密钥Key
			)
	);
	/**
	 * 获取配置信息
	 * @param unknown $key
	 */
	public static function get_certification_information($key){
		$env = getenv('RUNTIME_ENVIROMENT') ? getenv('RUNTIME_ENVIROMENT') : 'local';
		$env = isset(self::$_certification_information[$env]) ? $env : 'local';
		return self::$_certification_information[$env][$key];
	}
	/**
	 * 接口地址
	 * @var unknown
	 */
	public static $_interfaces = array(
		//菜单操作相关
		'menu_create'	=> 'https://api.weixin.qq.com/cgi-bin/menu/create', //创建菜单
		'menu_select'	=> 'https://api.weixin.qq.com/cgi-bin/menu/get',	//查询菜单
		'menu_delete'	=> 'https://api.weixin.qq.com/cgi-bin/menu/delete', //更新菜单
		
		//模版消息接口
        'template_get_industry'      => 'https://api.weixin.qq.com/cgi-bin/template/get_industry?',//获取设置的行业信息
        'template_get_id'            => 'https://api.weixin.qq.com/cgi-bin/template/api_add_template?',//获得模板ID
        'template_send'              => 'https://api.weixin.qq.com/cgi-bin/message/template/send?',//发送模板消息

        //基础接口
		'access_token'  => 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&',	//获取token
		'check_access_token' => 'https://api.weixin.qq.com/cgi-bin/getcallbackip?' //验证access_token 是否有效
		
	);
	
	public static $_redis_key = array(
		'access_token_key'	=> 'weixin_api_access_token_key', //access_token存储位置
	);
}
