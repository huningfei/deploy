<?php
/**
 * 微信模版消息应用
 * Encodings: UTF-8
 * User: znz
 * Date: 2018/3/28
 * Time: 上午11:21
 */

class XbLib_WechatTool_TemplateMessage extends XbLib_WechatTool_main{

    private static $obj= null;

    private static $templateId = array(
        'ZHU_CE_CHENG_GONG'     => '8EQcnuXYftstyjE-ESjrhy4If4sYylqf8tbzPjdX8zs',  //注册成功
        'SHI_MING'              => 'wr_AOzfxd2GhSDgh8i-z1ZFgOjv7WBQHYSTKg4gm2W0',  //实名消息
        'ZHANG_DAN_CHENG_GONG'  => 'iuoNrhrNYRdGNwMQmva03qVv6qa2F6gftXQp4MI3Umo',  //账单
        'ZHANG_DAN_SHI_BAI'     => 'Tq6qJsy-zLhPbwVcarPOIfF1mKt93ZXoQNr_9snCRlU',  //账单失败
        'ZHI_NENG_ZHANG_DAN'    => 'TPvQB8dcnYkJ2cNSHjtvX7eoqTHY9KgdGpcFSCgKDzw',  //智能账单

    );

    public static function getInstance(){
        if(is_null(self::$obj)){
            self::$obj = new XbLib_WechatTool_TemplateMessage();
        }
        return self::$obj;
    }

    /**
     * @param $touser
     * @param $template_id
     * @param $data
     * @param $url
     * @return Ambigous|bool
     */
    private function send($touser, $template_id, $data, $url){

        $templateInfo = array(
            'touser'    => $touser,
            'template_id' => self::$templateId[$template_id],
            'data'  => $data,
        );
        if($url){
            $templateInfo['url'] = $url;
        }
        $templateInfo = json_encode($templateInfo);
        return $this->send_http('template_send', $templateInfo);
    }
/******************以下为模版消息对应格式***************************/

    /**
     * 注册成功通知模版
     * @param $touser
     * @param $mobile
     * @param $regData
     * @param $url
     * @return Ambigous|bool
     */
    public function register($touser, $mobile, $regData, $url){

        $data = array(
            'first'     => array('value'=>'欢迎来到小白用卡管家，您在这里可以轻松完成信用卡取现、还款，取现超低费率1秒到账，邀请其他用户更可坐享分润~','color'=>'#173177'),
            'keyword1'  => array('value'=>$mobile),
            'keyword2'  => array('value'=>$regData),
            'remark'    => array('value'=>'感谢您对小白用卡管家支持，快来取现吧~','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHU_CE_CHENG_GONG', $data, $url);
    }

    /**
     * 实名成功
     * @param $touser   用户微信openid
     * @param $name     用户实名
     * @param $mobile   用户手机号
     * @param $url      跳转页面
     * @return Ambigous|bool
     */
    public function realNameSuccess($touser, $nickname, $mobile, $url){

        $data = array(
            'first'     => array('value'=>'恭喜您实名认证成功','color'=>'#173177'),
            'keyword1'  => array('value'=>$nickname),
            'keyword2'  => array('value'=>$mobile),
            'remark'    => array('value'=>'您提交的实名资料已成功通过审核，快来取现吧！','color'=>'#173177'),
        );
        return $this->send($touser, 'SHI_MING', $data, $url);
    }

    /**
     * 实名失败
     * @param $touser   用户ID
     * @param $name
     * @param $mobile
     * @param $url
     * @return Ambigous|bool
     */
    public function realNameFail($touser, $nickname, $mobile, $url = ''){

        $data = array(
            'first'     => array('value'=>'很遗憾您实名认证失败','color'=>'#173177'),
            'keyword1'  => array('value'=>$nickname),
            'keyword2'  => array('value'=>$mobile),
            'remark'    => array('value'=>'您提交的实名认证资料未通过审核，点击重新认证','color'=>'#173177'),
        );

        return $this->send($touser, 'SHI_MING', $data, $url);
    }

    /**
     * 取现成功
     * @param $touser   用户ID
     * @param $name
     * @param $orderAmount  金额
     * @param $date         时间
     * @param $orderNumber  订单号
     * @param $url
     * @return Ambigous|bool
     */
    public function orderPayment($touser, $name, $orderAmount, $date, $orderNumber, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的取现订单已成功到账','color'=>'#173177'),
            'keyword1'  => array('value'=>'取现支付'),
            'keyword2'  => array('value'=>$name),
            'keyword3'  => array('value'=>$orderAmount, 'color'=>'#FF4040'),
            'keyword4'  => array('value'=>$date),
            'keyword5'  => array('value'=>$orderNumber),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
    }

    /**
     * 一键还款成功
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function onekeyRepaymentSuccess($touser, $name, $orderAmount, $date, $orderNumber, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的一键还款订单支付成功','color'=>'#173177'),
            'keyword1'  => array('value'=>'一键还款支付'),
            'keyword2'  => array('value'=>$name),
            'keyword3'  => array('value'=>$orderAmount, 'color'=>'#FF4040'),
            'keyword4'  => array('value'=>$date),
            'keyword5'  => array('value'=>$orderNumber),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
    }
    /**
     * 一键还款失败
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function onekeyRepaymentFail($touser, $date, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的一键还款订单支付失败','color'=>'#173177'),
            'keyword1'  => array('value'=>'一键还款支付'),
            'keyword2'  => array('value'=>$date),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_SHI_BAI', $data, $url);
    }
    /**
     * 智能还款计划制定成功
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function intelligenceRepaymentPlanSuccess($touser, $orderAmount, $date, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的智能还款订单制定成功','color'=>'#173177'),
            'keyword1'  => array('value'=>$date),
            'keyword2'  => array('value'=>$orderAmount),
            'keyword3'  => array('value'=>'智能还款',),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHI_NENG_ZHANG_DAN', $data, $url);
    }
    /**
     * 智能还款成功
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function intelligenceRepaymentSuccess($touser, $name, $orderAmount, $date, $orderNumber, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的智能还款订单还款成功一笔','color'=>'#173177'),
            'keyword1'  => array('value'=>'智能还款'),
            'keyword2'  => array('value'=>$name),
            'keyword3'  => array('value'=>$orderAmount, 'color'=>'#FF4040'),
            'keyword4'  => array('value'=>$date),
            'keyword5'  => array('value'=>$orderNumber),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
    }
    /**
     * 智能还款失败
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function intelligenceRepaymentFail($touser, $date, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的智能还款订单还款失败，还款计划已终止','color'=>'#173177'),
            'keyword1'  => array('value'=>'智能还款'),
            'keyword2'  => array('value'=>$date),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_SHI_BAI', $data, $url);
    }
    /**
     * 智能还款订单已完成
     * @param $touser
     * @param $name
     * @param $orderAmount
     * @param $date
     * @param $orderNumber
     * @param $url
     * @return Ambigous|bool
     */
    public function intelligenceRepaymentAllSuccess($touser, $name, $orderAmount, $date, $orderNumber, $url){
        $data = array(
            'first'     => array('value'=>'您好，您的智能还款订单已完成','color'=>'#173177'),
            'keyword1'  => array('value'=>'智能还款'),
            'keyword2'  => array('value'=>$name),
            'keyword3'  => array('value'=>$orderAmount, 'color'=>'#FF4040'),
            'keyword4'  => array('value'=>$date),
            'keyword5'  => array('value'=>$orderNumber),
            'remark'    => array('value'=>'点击查看详情','color'=>'#173177'),
        );

        return $this->send($touser, 'ZHANG_DAN_CHENG_GONG', $data, $url);
    }

}