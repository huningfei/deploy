<?php

class XbLib_WechatTool_main{
    
    private $_access_token = null;
    public  $_logs = null;
    private $_error_code = 200;
    
    public function __construct(){
        //获取access_token
        $this->get_access_token();
        if($this->_error_code !== 200){
            return $this;
        }
    }
    public function get_error_code(){
        return $this->_error_code;
    }
    /**
     * 接口请求统一入口
     * @param string $url_identification 配置文件中 接口地址KEY
     * @param array|string $parameter
     * @return boolean|Ambigous <boolean, mixed>
     */
    public function send_http($url_identification, $parameter = array(), $mode = 'post'){
        //获取请求初始地址
        if(!isset(XbLib_WechatTool_Config::$_interfaces[$url_identification])){
            return false;
        }
        $url = XbLib_WechatTool_Config::$_interfaces[$url_identification];
        //开始请求
        return $this->curl_http($url, $parameter, $mode);
    }
    
    
    
    /**
     * 获取access_token
     * @return boolean
     */
    private function get_access_token(){
        //获取access_token
        $access_token = XbLib_Redis_String::Get(XbLib_WechatTool_Config::$_redis_key['access_token_key']);
        if($access_token){
            //验证是否有效
            $url = XbLib_WechatTool_Config::$_interfaces['check_access_token'] . "access_token={$access_token}";
            $result = $this->curl_http($url, array(), 'get');
            $json = @json_decode($result,true);
            if(empty($json) or !isset($json['errcode'])){
                $this->_access_token = $access_token;
                return true;
            }
        }
        //获取新的access_token
        $url = XbLib_WechatTool_Config::$_interfaces['access_token'];
        $url .=  'appid=' . XbLib_WechatTool_Config::get_certification_information('appid');
        $url .= '&secret=' . XbLib_WechatTool_Config::get_certification_information('appsecret');
        $result = $this->curl_http($url, array(), 'get');
        $result = json_decode($result,true);
        if (empty($result) or !isset($result['errcode'])) {
            //设置redis token
            XbLib_Redis_String::Set(XbLib_WechatTool_Config::$_redis_key['access_token_key'], $result['access_token']);
            $this->_access_token = $result['access_token'];
            return true;
        }
        $this->_error_code = 301;
        return false;
    }
    /**
     * 发送请求 (POST)
     * @param unknown $url
     * @param unknown $param
     * @return boolean
     */
    private function curl_http($url, $param, $mode){
        if(is_array($param) and !empty($param)){
            foreach($param as $key=>$val){
                $param[] = $key.'='.urlencode(trim($val));
            }
            $param = join('&', $param);
        }
        if($this->_access_token){
            $url .= stripos($url,'?') !== FALSE ? '&access_token=' : '?access_token=';
            $url .= $this->_access_token;
        }
        $curl_obj = curl_init();
        curl_setopt($curl_obj, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl_obj, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl_obj, CURLOPT_SSLVERSION, 1);
        
        curl_setopt($curl_obj, CURLOPT_URL, $url);
        curl_setopt($curl_obj, CURLOPT_RETURNTRANSFER, 1 );
        if($mode === 'post'){
            curl_setopt($curl_obj, CURLOPT_POST,TRUE);
            curl_setopt($curl_obj, CURLOPT_POSTFIELDS,$param);
        }
        $sContent = curl_exec($curl_obj);
        $aStatus = curl_getinfo($curl_obj);
        curl_close($curl_obj);
        if(intval($aStatus["http_code"]) != 200){
            XbFunc_Log::write('wechat_http_error', 'REQUEST_ERROR', $url . '?' . $param . '----STATUS---' .json_encode($aStatus). '----CONTENT----' .json_encode($sContent));
            return false;
        }
        return $sContent;
    }
}