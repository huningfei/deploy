<?php
	/**
	 * @desc 	验证数据格式
	 */
    class XbLib_Verify{
        /*
         * @desc    验证手机号
         * @param   int     $phone  手机号
         * @return  boolen  $return
         */
        public static function checkPhone($phone){
            $check = preg_match('#^13[\d]{9}$|^14[5,6,7,8,9]{1}\d{8}$|^15[^4]{1}\d{8}$|^16[6]{1}\d{8}$|^17[0,1,2,3,4,5,6,7,8]{1}\d{8}$|^18[\d]{9}$|^19[8,9]{1}\d{8}$#', $phone);
            return $check ? true : false;
        }

        /*
         * @desc    验证身份证号
         * @param   int     $phone  手机号
         * @return  boolen  $return
         */
        public static function checkIdcard($cardNumber){
            switch(strlen($cardNumber)) {
                case 18:
                    $check = preg_match('/^\d{6}([12]\d{3})(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}([0-9xX])$/', $cardNumber);
                    break;
                case 15:
                    $check = preg_match('/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$/', $cardNumber);
                    break;
                default:
                    $check = false;
                    break;
            }

            return $check ? true : false;
        }
        
        public function checkRealNameBindingCard($realname, $idcard, $cardNumber, $phone = ':ignore', $verification_code = '') {
            if(empty($realname)){
                return new XbLib_WebError(4201);
            }
            if(empty($idcard) || !XbLib_Verify::checkIdcard($idcard)){
                return new XbLib_WebError(4202);
            }
            if(empty($cardNumber)){
                return new XbLib_WebError(4203);
            }
            
            if ($phone != ':ignore') {
                if (!XbLib_Verify::checkPhone($phone))
                {
                    return new XbLib_WebError(4101);
                }
                
                $coder = new XbLib_Verification_PhoneCode();
                $coder->set("cardbind", $phone);
                //校验验证码是否正确
                if (empty($verification_code) || !$coder->checkCode($verification_code)) {
                    return new XbLib_WebError(4104);
                }
            }
        }

        /**
         * @desc    检查注册数据
         * @return  error   $return
         */
        public function checkSignup($phone, $password, $verification_code, $channel, $sub_channel = "", $invite_phone = ""){
            if(!self::checkPhone($phone)){
                return new XbLib_WebError(4101);
            }
            if(empty($channel) || empty($sub_channel)){
                return new XbLib_WebError(5000);
            }

            if(empty($password)){
                return new XbLib_WebError(4106);
            }

            if (strlen($password) < 6 || strlen($password) > 30) {
                return new XbLib_WebError(4106);
            }

            $coder = new XbLib_Verification_PhoneCode();
            $coder->set("reg", $phone);
            //校验验证码是否正确
            if (empty($verification_code) || !$coder->checkCode($verification_code)) {
                return new XbLib_WebError(4104);
            }

            //检查手机号是否重复
            $user_b = XbModule_Account_Users::getInstance()->getUserByPhone($phone);
            if (!empty($user_b)) {
                return new XbLib_WebError(4102);
            }

            //检查邀请
            if(!empty($invite_phone)){
                if (!self::checkPhone($invite_phone)) {
                    return new XbLib_WebError(4107);
                }
            }
        }

        /**
         * @desc    检查金额是否正确
         * @param   int     $money      金额3-5位数字
         * @return  boolen  $return
         */
        public static function checkOrderMoney($money){
            $check = preg_match('/^\d{3,5}$/',$money);
            return $check ? true : false;
        }
        /**
         * @desc    检查绑定数据是否正确
         * @return  error   $return
         */
        public function checkBindingPhone($phone, $verification_code){
            if(!self::checkPhone($phone)){
                return new XbLib_WebError(4101);
            }

            $coder = new XbLib_Verification_PhoneCode();
            $coder->set("binding", $phone);
            //校验验证码是否正确
            if (empty($verification_code) || !$coder->checkCode($verification_code)) {
                return new XbLib_WebError(4104);
            }

        }

        /**
         * @desc    填写银行信息时，检查是否支持此银行
         */
        public static function checkChannelBank($cardCode){
            $channelBank = XbLib_Var::$channelBank;
            if(isset($channelBank[$cardCode])){
                return true;
            }
            return false;
        }

        /**
         * @desc    检查数据是否是数字
         * @param   int     $check      需要检查的参数
         * @param   int     $min        最小位数
         * @param   int     $max        最大位数
         * @return  boolen  $return
         */
        public static function checkInt($check, $min, $max){
            $check = preg_match('/^\d{'.$min.','.$max.'}$/', $check);
            return $check ? true : false;
        }

        /**
         * @desc    检查信用卡账单日
         * @param   int     $billDate       账单日
         * @param   int     $payDate        支付日
         * @return  boolen  $return         返回判断结果
         */
        public static function checkDate($billDate, $payDate){
            $day = date('d');
            if($billDate >= $payDate){
                $t = date('t');
                if($day <= $payDate){
                    $day += $t;
                }
                $payDate += $t;
            }
            if($day < $billDate || $day > ($payDate -2)){
                return false;
            }
            return $payDate - $day - 1;
        }
    }