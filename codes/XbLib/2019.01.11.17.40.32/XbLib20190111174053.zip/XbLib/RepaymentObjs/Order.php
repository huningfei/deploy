<?php
/**
 * 订单类
 */
class XbLib_RepaymentObjs_Order{
    private static $obj;

    public $user = null;
    public $channel = null;
    public $order = null;
    public $param = array();

    /**
     * 封闭构造
     * XbLib_RepaymentObjs_Order constructor.
     */
    private function __construct(){
    }

    /**
     * 单例
     * @return null|XbLib_RepaymentObjs_Order
     */
    public static function getInstance(){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_RepaymentObjs_Order();
        }
        return self::$obj;
    }

    /**
     * @desc    获取支付通道
     * @return  object  $return     获取支付通道
     */
    public function getChannelGallery($channel_id){
        switch ($channel_id){
            case 5:
                $gallery = XbLib_Repayment_Channel::getChannelObj('YaKuKuBao');
                break;
            default:
                break;
        }
        return $gallery;
    }


    /**
     * @desc    用户进件
     * @return  array  $return     用户进件
     */
    public function userSignUp($channel_id, $uid){
        if (empty($channel_id) || empty($uid)){
            return new XbLib_WebError(400,'通道或用户信息错误');
        }
        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($uid);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        if (!$user->info || ($user->info['status'] != 3)) {
            return new XbLib_WebError(400,'用户身份信息错误');
        }

        $this->param['order_id']         = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['bind_order_id']    = XbModule_Account_OrderCode::getInstance()->getOrderCode();

        return $this;
    }

    /**
     * @desc    一键还款支付计算
     * @return  array  $return     一键还款支付计算
     */
    public function userCreateOrder($channel_id, $uid, $cid, $amount, $merchant_id){
        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($uid);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        $stime = strtotime(date('Y-m-d 09:00:00'));
        $etime = strtotime(date('Y-m-d 20:30:00'));
        $time  = time();
        if($time < $stime || $time> $etime){
//            return new XbLib_WebError(4514);
        }

        //判断通道是否开启
        if($channel->info['status'] != 1){
            return new XbLib_WebError(4504);
        }

        //判断下单时间
        if(!XbLib_ChannelTools::checkChannelTime($channel->info['time'], $channel->info['week'])){
            return new XbLib_WebError(4310);
        }

        //判断金额
        if(!XbLib_Verify::checkInt($amount, 3, 11)){
            return new XbLib_WebError(4302);
        }

        //判断信用卡信息
        $user->getUserCard($cid);
        if(!$user->card || $user->card['status'] != 1){
            return new XbLib_WebError(4502);
        }
        if($user->card['uid'] != $user->uid){
            return new XbLib_WebError(400,'用户身份与信用卡不匹配');
        }

        //获取用户等级
        $user->getUserChannel($channel->channel_id);
        if (!$user->channel_level['rate']){
            return new XbLib_WebError(400,'用户等级信息错误');
        }
        if (!$user->channel_code['channel_code']){
            return new XbLib_WebError(400,'用户通道code错误');
        }

        //计算还款金额
        $pay_amount = XbLib_Repayment_ChannelFunc::getCommonFee($user->channel_level['rate'], $amount, $user->channel_level['fee']);


        //判断还款金额
        if($pay_amount < $channel->info['mininum_charge'] || $pay_amount > $channel->info['maxnum_charge']){
            return new XbLib_WebError(4505);
        }

        //选择商户
        if($channel_id == 5){
            if(empty($merchant_id)){
                return new XbLib_WebError(400,'请选择商户');
            }
            $res_merchant = XbModule_Account_Merchant::getInstance()->selectMerchant(20, '', $merchant_id);
            if(empty($res_merchant['merchant_no'])){
                return new XbLib_WebError(400,'选择的商户不存在');
            }
            $this->param['merchant_no'] = $res_merchant['merchant_no'];
        }
        $this->param['amount']     = $amount;
        $this->param['pay_amount'] = $pay_amount;
        $this->param['rate']       = $this->user->channel_level['rate'];
        $this->param['order_id']   = $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['time']       = time();
        $this->param['notify_type']= 1;

        return $this;
    }

    /**
     * @desc    一键支付还款回调计算
     * @return  array  $return     一键支付还款回调计算
     */
    public  function userCreatePayOrder($order_index){

        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($order_index['uid']);
        $this->order = $order = XbModule_Repayment_Order::getInstance($order_index['order_table_num'])->getOrderInfo($order_index['order_id']);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($order['channel_id']);

        //获取信用卡信息
        $user->getUserCard($this->order['repaycard_id']);

        //获取用户等级
        $user->getUserChannel($channel->channel_id);

        $this->param['custom_amount'] = $this->order['custom_amount'];
        $this->param['single_fee']    = $this->order['single_fee'];
        $this->param['order_id']   = $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $this->param['time']       = time();
        $this->param['fee'] = XbLib_Repayment_ChannelFunc::getWithdrawAmount($order['amount'], $order['rate'], $order['single_fee']);//打款手续费
        $this->param['notify_type']     = 2;

        return $this;
    }

    /**
     * @desc    一键支付还款完成订单
     * @return  array  $return     一键支付还款完成订单
     */
    public  function userFinishOrder($status, $order_index, $order_play){
        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($order_index['uid']);
        $this->order = $order = XbModule_Repayment_Order::getInstance($order_index['order_table_num'])->getOrderInfo($order_index['order_id']);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($order['channel_id']);

        //获取信用卡信息
        $user->getUserCard($this->order['repaycard_id']);
        //获取用户等级
        $user->getUserChannel($channel->channel_id);
        if ($status == 1){
            //代付成功
            $order_data['status'] = 1;
            $play_data['status'] = 2;
        } elseif ($status == 2){
            //代付失败
            $order_data['status'] = 3;
            $play_data['status'] = 3;
        }

        $this->param['order_data']      = $order_data;
        $this->param['play_data']       = $play_data;

        return $this;
    }


    /**
     * @desc    智能还款支付计算
     * @return  array  $return     智能还款支付计算
     */
    public function userCreatePlanOrder($channel_id, $order, $order_plan){
        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($order_plan['uid']);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        //判断信用卡信息
        $user->getUserCard($order['paycard_id']);
        //获取用户等级
        $user->getUserChannel($channel->channel_id);

        //选择商户
        if($channel_id == 5){
            $district_id = $order['district_id'];
            if(empty($district_id)){
                return new XbLib_WebError(400,'请选择商户');
            }
            $res_merchant = XbModule_Account_Merchant::getInstance()->selectMerchant(30, $district_id, '');

            if(empty($res_merchant['merchant_no'])){
                return new XbLib_WebError(400,'选择的商户不存在');
            }
            $this->param['merchant_no'] = $res_merchant['merchant_no'];
        }

        $this->param['pay_amount'] = $order_plan['amount'];
        $this->param['rate']       = $order['rate'];
        $this->param['order_id']   = $order_plan['order_id'];
        $this->param['notify_type'] = 3;

        return $this;
    }

    /**
     * @desc    智能还款代付计算
     * @return  array  $return     智能还款代付计算
     */
    public function userCreatePlanPayOrder($channel_id, $order, $order_plan){
        $this->user = $user = XbLib_RepaymentObjs_User::getInstance()->getUserObj($order_plan['uid']);
        $this->channel = $channel = XbLib_RepaymentObjs_Channel::getInstance()->getChannelObj($channel_id);

        //判断信用卡信息
        $user->getUserCard($order['paycard_id']);
        //获取用户等级
        $user->getUserChannel($channel->channel_id);

        $fee = XbLib_Repayment_ChannelFunc::getWithdrawAmount($order_plan['amount'], $order['rate'], $order['single_fee']);
        $custom_amount = bcsub($order_plan['amount'], $fee, 2);

        $this->param['custom_amount'] = $custom_amount;
        $this->param['single_fee']    = $order['single_fee'];
        $this->param['notify_type'] = 4;

        return $this;
    }
}