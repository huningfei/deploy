<?php

/**
 *
 * Author: abel
 * Date: 2017/12/6
 * Time: 17:32
 */
abstract class XbLib_Verification_Abstract {
    static $obj = null;
    protected $code = '';
    protected $expire = 1800;

    /**
     * @param $key
     * @param $code
     * @return bool
     */
    protected function setCode($key, $code) {
        //切换redis数据库
        XbLib_Redis_String::select(10);
        $res = XbLib_Redis_String::sSet($key, $code);
        XbLib_Redis_String::setTimeout($key, $this->expire);
        //切回Redis数据库
        XbLib_Redis_String::select(0);
        return $res;
    }

    /**
     * @param $key
     * @return bool|string
     */
    protected function getCode($key) {
        XbLib_Redis_String::select(10);
        $code = XbLib_Redis_String::sGet($key);
        XbLib_Redis_String::select(0);
        return $code;
    }

    /**
     * @param $len
     * @param bool $letters
     * @return string
     */
    protected function _randomString($len, $letters = false) {
        $random = null;
        $chars = null;
        $factory = new RandomLib\Factory();
        $generator = $factory->getGenerator(new SecurityLib\Strength());
        if ($letters) {
            $chars = "123456789abcdefghijklmnopqrstuvwxyz";
        } else {
            $chars = "123456789";
        }
        return $generator->generateString($len, $chars);
    }

    /**
     * 发送验证码
     * @return mixed
     */
    abstract function sendCode();

    /**
     * 检查验证码是否正确
     * @param code
     * @return boolean
     */
    abstract function checkCode($code);
}