<?php
/**
 * @desc    还款支付通道接口
 * @author  qien
 * @date    18.04.08
 */
interface XbLib_Repaymentchannel_Interface{
	
	/**
	 * @desc    签名加密
     * @param   string  $dataStr    签名字符串
	 */
	function sign($dataStr);
	
    /**
     * @desc    验证加密
     * @param   array   $data
     * @param   string  $sign
     */
    function checkSign($data, $sign);

    /**
     * @desc    组装加密参数
     * @param   int     $data           需要加密的数据
     * @param   boolen  $isCheckSign    是否是检验加密
     */
    function buildSignData($data, $isCheckSign = false);

    /**
     * @desc    注册用户接口
     */
    function signUp();

    /**
     * @desc    更改用户信息接口
     */
    function updateUserInfo();

    /**
     * @desc    发送交易-下单支付
     */
    function transaction();

    /**
     * @desc    渠道提现
     */
    function withdraw();

    /**
     * @desc    订单查询，核对
     */
    function checkOrder();
}