<?php
/**
 * @desc    米联信用卡还款基类
 * @author  qien
 * @date    18.04.08
 */
class XbLib_Repaymentchannel_Adapter_Milian extends XbLib_Repaymentchannel_Abstract implements XbLib_Repaymentchannel_Interface{
    protected   $sign;              //签名数据
    protected   $url;               //访问url
    private     $interface;         //接口
    private     $key;               //加密key
    private     $appId;             //通道id
    protected   $data;              //发送的数据
    private     $intelrderCallback = "https://api.xiaobaijinfu.com/synorder/yingtaoRepaymentCallbackIntel";     //樱桃智能订单异步通知接口
    private     $oneKeyOrderCallback = "https://api.xiaobaijinfu.com/synorder/yingtaoRepaymentCallbackOnekey";     //樱桃一键订单异步通知接口
    public static $obj;             //单例

    function __construct($config){
        $this->url['userInterface'] = $config['userInterface'];
        $this->url['userKey']       = $config['userKey'];
        $this->url['pay']           = $config['pay'];
        $this->url['order']         = $config['order'];
        $this->url['balance']       = $config['balance'];
        $this->url['withdraw']      = $config['withdraw'];
        $this->key                  = $config['key'];
        $this->appId                = $config['appId'];
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Repaymentchannel_Adapter_MilianYangtao($config);
        }
        return self::$obj;
    }

    /**
     * @desc    签名加密
     * @param   string  $data    签名字符串
     */
    function sign($data){
        $signArr = array();
        foreach($data as $k=>$v){
            $signArr[] = $k.'='.$v;
        }
        $signArr[] = 'key='.$this->key;
        $signStr = implode('&', $signArr);
        return strtoupper(md5($signStr));
    }

    /**
     * @desc    签名加密
     * @param   string  $data    签名字符串
     */
    function signA($data, $key){
        $signStr = implode('', $data);
        $sign1 = strtoupper(md5($signStr));
        $sign2 = strtoupper(md5($sign1.$key));
        return substr($sign2, 8, 16);
    }

    /**
     * @desc    绑定发送数据
     * @param   array   $data       需要发送的数据
     * @return  string  $return     返回需要发送的数据字符串
     */
    public function buildSendData($data){
        $sendData = array();
        foreach($data as $k=>$v){
            $sendData[] = $k.'='.$v;
        }
        return implode('&', $sendData);
    }

    /**
     * @desc    验证加密
     * @param   array   $data
     * @param   string  $sign
     */
    function checkSign($data, $sign){

    }

    /**
     * @desc    组装加密参数
     * @param   int     $data           需要加密的数据
     * @param   boolen  $isCheckSign    是否是检验加密
     */
    function buildSignData($data, $isCheckSign = false){
        $this->data = $data;
        return $this;
    }

    /**
     * @desc    注册用户接口
     */
    function signUp(){
        $bankInfo  = $this->getBankInfo($this->data['bankCardCode']);
        $order_id  = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $levelInfo = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($this->data['uid']);
        if(!$levelInfo) $levelInfo['level'] = 1;
        $channelLevel = XbModule_Repayment_Channel::getInstance()->getChannelByChannelidLevel(1, $levelInfo['level']);
        $rate = $channelLevel ? $channelLevel['rate'] : '0.0070';
        $fee  = $channelLevel ? $channelLevel['fee'] : '2';
        if(!$bankInfo){
            $bankInfo = array('code'=> $this->data['bankCardCode'], 'name'=> $this->data['bankName'], 'abbr' => '000', 'no' => '00000000');
        }
        $data = array(
            'bankAccountNo' => $this->data['bankcardNumber'],
            'debitRate'     => $rate,
            'handleType'    => 'A',
            'merchName'     => $this->data['realname'],
            'orderId'       => $order_id,
            'parent'        => $this->appId,
            'phoneNo'       => $this->data['phone'],
        );
        $data['sign']              = $this->sign($data);
        $data['merchAbb']          = $this->data['realname'];
        $data['merchAddress']      = '北京市';
        $data['telNo']             = $this->data['phone'];
        $data['bankAccountName']   = $this->data['realname'];
        $data['legalPersonIdcard'] = $this->data['idcardNumber'];
        $data['settBankName']      = $bankInfo['name'];
        $data['bankChannelNo']     = $bankInfo['no'];            //========
        $data['bankSubName']       = $bankInfo['name'];
        $data['bankProvince']      = '北京市';
        $data['bankCity']          = '北京市';
        $data['bankCode']          = $bankInfo['code'];
        $data['bankAbbr']          = $bankInfo['abbr'];                         //=============
        $data['countFeeT0']        = bcmul($fee, 100, 0);
        $data['futureMinAmount']   = '0';                           //暂时固定为0
        $data['debitCapAmount']    = '9999';                        //暂时固定为9999
        $url = $this->url['userInterface'];
        $sendData = $this->buildSendData($data);
        $res = XbLib_CurlHttp::postNew($url, $sendData);
        $checkRes = $this->checkError($res, $sendData, 'signUp');
        return $checkRes ? array('channel_code' => $res['data']['merchantNo'], 'channel_key' => $res['data']['merchantKey']) : false;
    }

    /**
     * @desc    更改用户信息接口
     */
    function updateUserInfo(){
        $changeType = '';
        if($this->data['updateType'] == 3){
            $data['debitRate'] = $this->data['rate'];
            $changeType        = 'M03';
        }
        $data['handleType']      = 'M';
        $data['orderId']         = $this->data['order_id'];
        $data['parent']          = $this->appId;
        $data['sign']            = $this->sign($data);
        $data['changeType']      = $changeType;
        $data['countFeeT0']      = (int)bcmul($this->data['fee'], 100, 0);
        $data['merchId']         = $this->data['channel_code'];
        $url      = $this->url['userInterface'];
        $sendData = $this->buildSendData($data);
        $res      = XbLib_CurlHttp::postNew($url, $sendData);
        //var_dump($res);exit;
        $checkRes = $this->checkError($res, $sendData, 'updateUserInfo_'.$this->data['updateType']);
        return $checkRes ? true : false;
    }

    /**
     * @desc    发送交易-下单支付
     */
    function transaction(){
        $this->data['updateType'] = 3;
        $upadteRate = $this->updateUserInfo();
        if(!$upadteRate) return false;
        $this->buildCreditCard();
        $orderTime = date('YmdHis');
        $data = array(
            'ORDER_ID'   => $this->data['order_id'],
            'ORDER_AMT'  => number_format($this->data['amount'], 2, '.', ''),
            'ORDER_TIME' => $orderTime,
            'USER_TYPE'  => '02',
            'USER_ID'    => $this->data['channel_code'],
            'SIGN_TYPE'  => '03',
            'BUS_CODE'   => '5029',
        );
        $key = $this->data['channel_key'];
        $data['SIGN'] = $this->signA($data, $key);
        $data['PAY_TYPE'] = '13';
        $data['ADD1']     = $this->data['bankCardNumber'];
        $data['ADD2']     = $this->data['realname'];
        $data['ADD3']     = '02';
        $data['ADD4']     = $this->data['idCardNumber'];
        $data['PHONE_NO'] = $this->data['phone'];
        $data['VALID']    = $this->data['validDate'];
        $data['CVN2']     = $this->data['cvv'];
        $data['BG_URL']   = $this->data['type'] == 1 ? $this->intelrderCallback : $this->oneKeyOrderCallback;
        $url = $this->url['pay'];
        $res = XbLib_CurlHttp::postNew($url, $data, array(), true);
        XbFunc_Log::write('milianTrans', '返回数据错误：'.json_encode($res), '请求参数：'.json_encode($this->data).',加密传输数据'.json_encode($data));
        //var_dump($res);
        $checkRes = $this->checkError($res, $data, 'transaction');
        $code = $this->getCode($res);
        return $checkRes ? array('code' => $code, 'order_id' => $this->data['order_id']) : false;
    }

    /**
     * @desc    渠道提现
     */
    function withdraw(){
        $orderTime = date('YmdHis');
        $data = array(
            'ORDER_ID'   => $this->data['order_id'],
            'ORDER_AMT'  => number_format($this->data['amount'], 2, '.', ''),
            'ORDER_TIME' => $orderTime,
            'PAY_TYPE'   => '13',
            'USER_TYPE'  => '02',
            'USER_ID'    => $this->data['channel_code'],
            'BUS_CODE'   => '1006',
        );
        //order_id, amount, channel_code, channel_key, bankCode, bankCardNumber, bank, realname, fee
        $add3 = $this->data['day'] == date('d') ? '400' : '402';
        //$add3 = '400';
        $data['SIGN'] = $this->signA($data, $this->data['channel_key']);
        $data['SIGN_TYPE']    = '03';
        $data['BANK_CODE']    = $this->data['bankCode'];
        $data['ACCOUNT_NO']   = $this->data['bankCardNumber'];
        $data['BANK_NAME']    = $this->data['bank'];
        $data['ACCOUNT_NAME'] = $this->data['realname'];
        $data['CCT']          = 'CNY';
        $data['ADD2']         = bcmul($this->data['fee'], 100, 0);
        $data['ADD3']         = $add3;
        $url = $this->url['pay'];
        $res = XbLib_CurlHttp::postNew($url, $data, array(), true);
        $checkRes = $this->checkError($res, $data, 'withdraw');
        return $checkRes ? array('code' => $res['RESP_CODE']) : false;
    }

    /**
     * @desc    查询用户余额
     */
    public function getBalance(){
        $data = array(
            'ORDER_ID' => $this->data['order_id'],
            'USER_TYPE' => '02',
            'USER_ID' => $this->data['channel_code'],
        );
        $data['SIGN'] = $this->signA($data, $this->data['channel_key']);
        $data['SIGN_TYPE'] = '03';
        $url = $this->url['balance'];
        $res = XbLib_CurlHttp::postNew($url, $data, array(), true);
        $checkRes = $this->checkError($res, $data, 'getBalance');
        return $checkRes ? array('balance' => $res['BALANCE']) : false;
    }

    /**
     * @desc    订单查询，核对
     */
    function checkOrder(){
        $data = array(
            'ORDER_ID'     => $this->data['new_order_id'],
            'ORG_ORDER_ID' => $this->data['order_id'],
            'USER_ID'      => $this->data['channel_code'],
        );
        $data['SIGN'] = $this->signA($data, $this->data['channel_key']);
        $data['USER_TYPE'] = '02';
        $data['SIGN_TYPE'] = '03';
        $url = $this->url['order'];
        $res = XbLib_CurlHttp::postNew($url, $data, array(), true);
        $checkRes = $this->checkError($res, $data, 'checkOrder');
        $code = $this->getCode($res);
        return array('code' => $code,'res'=>$res);
    }

    /**
     * @desc    检查error
     * @param   array   $res        请求接口返回的数据
     * @param   array   $data       请求接口返回的数据
     * @param   array   $interface  请求方法
     * @return  boolen  $return     检验结果
     */
    public function checkError($res, $data, $interface){
        $retrun = true;
        if(isset($res['RESP_CODE'])){
            $codeField = 'RESP_CODE';
            $descField = 'RESP_DESC';
        }else{
            $codeField = 'respCode';
            $descField = 'respMsg';
        }
        if(!($res[$codeField] == '0000' || $res[$codeField] == '0100' || $res[$codeField] == '00')){
            $log  = json_encode($res);
            $log1 = json_encode($this->data);
            $log2 = is_array($data) ? json_encode($data) : $data;
            XbFunc_Log::write('milianRepaymentError', '返回数据错误：'.$log, '请求参数：'.$log1.',加密传输数据'.$log2.'，请求方法'.$interface);
            $this->error = $res[$descField];
            $retrun = false;
        }
        return $retrun;
    }

    public function getBankInfo($bankCode){
        $bankInfo = XbLib_Var::$bankCode2MilianBank;
        return isset($bankInfo[$bankCode]) ? $bankInfo[$bankCode] : false;
    }

    public function checkChannelBank(){
        return true;
    }

    public function getCode($res){
        if($res['RESP_CODE'] == '0000' || $res['RESP_CODE'] == '00') return 200;
        if($res['RESP_CODE'] == '0100') return 201;
        return 400;
    }

    public function buildCreditCard(){
        return true;
    }
}