<?php

/**
 * 福建米联樱桃还款通道
 *
 *
 */
class XbLib_Repaymentchannel_Adapter_MilianYingtao extends XbLib_Repaymentchannel_Adapter_Milian implements XbLib_Repaymentchannel_Interface
{
    public static $obj;

    public function __construct($config){
        parent::__construct($config);
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }

    public function buildCreditCard(){
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $data = array(
            'ORDER_ID'   => $order_id,
            'USER_TYPE'  => '02',
            'USER_ID'    => $this->data['channel_code'],
            'BUS_CODE'   => '1011',
            'CHECK_TYPE' => '01',
            'ACCT_NO'    => $this->data['bankCardNumber'],
            'PHONE_NO'   => $this->data['phone'],
        );
        $key = $this->data['channel_key'];
        $data['SIGN'] = $this->signA($data, $key);
        $orderTime = date('YmdHis');
        $data['ORDER_TIME'] = $orderTime;
        $data['SIGN_TYPE']  = '03';
        $data['ID_NO']      = $this->data['idCardNumber'];
        $data['NAME']       = $this->data['realname'];
        $data['CVN2']       = $this->data['cvv'];
        $data['VALID']      = $this->data['validDate'];
        $url = $this->url['pay'];
        $res = XbLib_CurlHttp::postNew($url, $data, array(), true);
        $checkRes = $this->checkError($res, $data, 'buildCreditCard');
        return $checkRes ? $res : false;
    }
}