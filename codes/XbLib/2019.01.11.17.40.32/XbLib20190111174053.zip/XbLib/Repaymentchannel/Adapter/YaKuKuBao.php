<?php
/**
 * 雅酷酷宝通道
 */
class XbLib_Repaymentchannel_Adapter_YaKuKuBao extends XbLib_Repaymentchannel_Adapter_YaKu
{
    public static $obj;

    public function __construct($config){
        parent::__construct($config);
    }

    public static function getInstance($config){
        if (empty(self::$obj)) {
            self::$obj = new self($config);
        }
        return self::$obj;
    }
}