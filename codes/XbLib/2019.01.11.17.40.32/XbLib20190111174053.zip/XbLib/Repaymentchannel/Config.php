<?php
/**
 * @desc    支付通道配置文件
 * @author  qien
 * @date    18.04.08
 */
class XbLib_Repaymentchannel_Config{

    public static function getConfig($channel, $env){
        switch($channel){
            case 'milianYingtao':
                $config = self::milianYingtaoConfig();
                break;
            case 'milianYangtao':
                $config = self::milianYangtaoConfig();
                break;
            case 'YaKuKuBao':
                $config = self::YaKuKuBaoConfig();
                break;
            default :
                break;
        }
        return $config[$env];
    }

    /**
     * @desc    米联樱桃
     * @return  array       $return     返回配置信息
     */
    public static function milianYingtaoConfig(){
        return array(
            'rls' => array(
                'userInterface' => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/merchInterface',
                'userKey'       => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/queryMerchKey',
                'pay'           => 'http://npsapi.mylandpay.com/MyLandQuickPay/controller/pay',
                'order'         => 'http://222.76.210.177:9002/WeChatPay/servlet/OrderQuery',
                'balance'       => 'http://222.76.210.177:9002/WeChatPay/servlet/MerchBalanceQuery',
                'key'           => 'EAFB6266A50CA0F7FFC7DD893292771F',
                'appId'         => '70001255'
            ),
            'local' => array(
                'userInterface' => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/merchInterface',
                'userKey'       => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/queryMerchKey',
                'pay'           => 'http://npsapi.mylandpay.com/MyLandQuickPay/controller/pay',
                'order'         => 'http://222.76.210.177:9002/WeChatPay/servlet/OrderQuery',
                'balance'       => 'http://222.76.210.177:9002/WeChatPay/servlet/MerchBalanceQuery',
                'key'           => 'EAFB6266A50CA0F7FFC7DD893292771F',
                'appId'         => '70001255'
            )
        );
    }

    /**
     * @desc    米联杨桃
     */
    public static function milianYangtaoConfig(){
        return array(
            'rls' => array(
                'userInterface' => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/merchInterface',
                'userKey'       => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/queryMerchKey',
                'pay'           => 'http://npsapi.mylandpay.com/MyLandQuickPay/controller/pay',
                'order'         => 'http://222.76.210.177:9002/WeChatPay/servlet/OrderQuery',
                'balance'       => 'http://222.76.210.177:9002/WeChatPay/servlet/MerchBalanceQuery',
                'key'           => 'EF59CA5426B44A9B1A5963675F4FCE3B',
                'appId'         => '70001256'
            ),
            'local' => array(
                /*'userInterface' => 'http://220.160.118.218:8382/ChannelPay/merchBaseInfo/merchInterface',
                'userKey'       => 'http://220.160.118.218:8382/ChannelPay/merchBaseInfo/queryMerchKey',
                'pay'           => 'http://220.160.118.218:8281/MyLandQuickPay/controller/pay',
                'order'         => 'http://220.160.118.218:8280/WeChatPay/servlet/OrderQuery',
                'balance'       => 'http://220.160.118.218:8280/WeChatPay/servlet/MerchBalanceQuery',
                'key'           => '5A3E094AFB415D41E050007F01000EE3',
                'appId'         => 'CSRZ0004'*/
                'userInterface' => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/merchInterface',
                'userKey'       => 'http://222.76.210.177:9006/ChannelPay/merchBaseInfo/queryMerchKey',
                'pay'           => 'http://npsapi.mylandpay.com/MyLandQuickPay/controller/pay',
                'order'         => 'http://222.76.210.177:9002/WeChatPay/servlet/OrderQuery',
                'balance'       => 'http://222.76.210.177:9002/WeChatPay/servlet/MerchBalanceQuery',
                'key'           => 'EF59CA5426B44A9B1A5963675F4FCE3B',
                'appId'         => '70001256'
            )
        );
    }

    /**
     * @desc    雅酷酷宝
     */
    public static function YaKuKuBaoConfig(){
        return array(
            'rls' => array(
                'version'				=> '1.0',
                'partner_id'    		=> '200018580779',
                '_input_charset'    	=> 'utf-8',
                'sign_type'         	=> 'RSA',
                'rsa_sign_private_key'  => '-----BEGIN RSA PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQD3M/zhwXLIZsF1
vAEtrW8XKh5X8pCM1MnBa5u3q+2XoboSZN+oELdEqn23xnEiGVehPgFYcXKIawHd
TDtKS70rZ+f5wXzu7GTVRf4M1BW5pQFgQjAT6mOwYIJUPdeAbhYeWOVgId2EbOZr
P+D3KeORDaiN1relDFRoiGzeMQo3lAGgf0IdQRKjhctwgqhCd/mdwNwmjjVL9UOB
Wo/JBwB6GPPsPqWMpcPe+Xer3J8Bl/rN4Y5DIx+3oCdAiuCY7QDBInSNw83JeE21
PJAXz25iXH+hBhKb3/0aTTMUQHEyPEXMhlFkaQsRYTKQcD1uOZWhXVpg21SLw3sS
UuJITSOdAgMBAAECggEAFjeD6L48FKq3hF9LM9G8hDZy17CjMSUGpO2I5y76gYA1
euW5/B7UecVg2x1omYnxiDpMYKiBhKUpW7w4L+syqy4BeT7cfZSdU1WhCYIeGbss
rnwEWiXco8Nosy2DqrU6I6wVoVgp0nb/FnB9RXlsTGMP3P+JLbo389UfA7Egm/Hy
I50V49In+ypt+CkY7qSLNrgcw++v7ix2wmAWRLfQvf3u8EHdkjxQdgLYgyTnLudi
j3zap7HRBBflMiQk+Q4aq1y8seIC18kO82qj/uvsAPbAoSsU7VqEk3RIUcEjzM6/
GeZRLq+7AJvJ2fXAkb7cfg1S7a0GVpp9lkU+CqFgOQKBgQD8OfE0BhMqRtH3/cmk
B4A4pSICFhoiS3LjCcSa51F8SAIaBqHHFTqiHq4O22/dA0oEFX31bX9kuXxF83GH
wzlKka1lSCeHJUtLw9iNKj/hGf9XWHG7BBF8jA+xMohXwdvXt0CRemPqBkwjJFU6
Nwhunh6zgTT3A5RtIsV5JLuiqwKBgQD65s5Qz6LrhV3OSzYk1tnFLPrXzVN7folK
WegpWcBn3adezM26vC7GM/AGws1+SR+960RMDdxgPq/zSyDceh791h9CnmtN87fi
iqkk2TkxcwMeYJV30vDtpnSg//5E0V0LOBGL41+4dJPHoat2VCnXFkorp5WAO2Qo
ltnOU9aS1wKBgH0531Fu+rDwvGqdrDEuMDDve7UBeDQytXWXce9ejYxgy/pT9Jo9
JgE7rjteI2ndqi/g48qodKlzlgm81k8LVDR7o1U3v7hPgdS6BZgAs/p0x9t74+tw
F6Z4e4oEhsDbVOUC7KHN3DFiswZ3kYD3tc4F30RMEBnbwyN0Mgr1e9tFAoGAYpul
iHMih8gBpxs+K1pZejoEWB41ajrAAH23VdEVYnzl08dQL8zX4UP2WOHk23YnyH+X
dwCXlSfuBQOI5b4FQiQOYyNZ7ugTZDC062uII9wc5Kp29AHueKhL/B7AMxHJrKgb
lUwGibsffX0Xo0jOrN7wxZl2k1BEPAOVlJa0pT8CgYEA+8QVQtSQS4hf8lf8QrGB
xmQiG2gSysBrfqsDuSQPU4tBYC8BAISvipVielZockiLEEedz/h8YPk+yLQkITTI
qCotcOITwupfRygSqnVVH7L9pWdnyP0436PmJQWrNZS5PJGfjaD1L81IUcpynM2b
Afr4lShBLkVF9d5B8IudAqU=
-----END RSA PRIVATE KEY-----',
                'rsa_sign_public_key'   => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuKZgr4ZRET1bz9zdzI9plt6Km3qnYo3/
29E1ND8ynwaRlFKIE1pZYXtl1m2Z5Mdd/+nAMq83SZqyypdjeh1yian2Qx8D9kDkRc3XNYxMjor5
S6OpT0l7hxHEHzGqqmSai5p9E20t5Bmnu/GIFc7C/o3bJ/Z8UTv/Jiqmt9G928Nn+MmCRtJDI4T6
JAlIpVR4QCp4NK551aqqC6piv+ovqTENWreTMmKF6Vn9NpzGFdxAtNAxL5rgO5PFspiJDzF3JWpQ
kD8UHYqMatuMlC5wuGwIp4OWYrrete5Xym8wt4WmvRdAroy8PBs+DhczjrB7+/mUYTMZmfqTCfUb
4TrV9QIDAQAB
-----END PUBLIC KEY-----',
                'rsa_public_key'        => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp9+KkwUwpt78fOUpCwnst2Kx+bnciH/s
GuCngbllx5ZBCTNTKCj/9eTa/oGSAiaTOat8CmqlqeMWQ5SQF8YIJIHo4erVAg+vVu2mfV2JJiXM
ibckju5wGnVSwKTKpvtMAqprI/lrkq7/I8HY77CLm+g/CWultTuNAMglzR+isFvPu0AnmMexe1s9
0ZXH+FTYuNmWQLmJvINHLVQ/m/pqWrOQ1JuiStNNFaTRrIym6bUGKQHXHRykI4ng3R0+ORMuIUIu
pXs7556T+sTSrWNOifOCX/0sQgEZsnnJbNkUZy6za1mKXyzGQGs1UskF/jtP1fAilk1x3+mQNlhK
Mru17QIDAQAB
-----END PUBLIC KEY-----',
                'notify_url_1'     		=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentOnekey',//一键支付回调
                'notify_url_2'     		=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentPayOnekey',//一键代付回调
                'notify_url_3'       	=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentIntel',//智能支付回调
                'notify_url_4'       	=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentPayIntel',//智能代付回调
                'masRequestUrl'         => 'http://gate.yacolpay.com/mas/gateway.do',//卡要素支付、支付发送短信验证、短信重发、单笔支付查询、代付到银行卡、代付订单查询接口
                'mgsRequestUrl'         => 'http://filegate.yacolpay.com/filegs/gateway.do',//小微商户入网，小微商户绑定结算卡
                'queryRequestUrl'       => 'http://gate.yacolpay.com/mgs/gateway.do',//小微商户信息查询，小微商户账户余额查询
                'debug_status'         	=> false,
            ),
            'local' => array(
                'version'				=> '1.0',
                'partner_id'    		=> '200006503094',
                '_input_charset'    	=> 'utf-8',
                'sign_type'         	=> 'RSA',
                'rsa_sign_private_key'  => '-----BEGIN RSA PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCiBgy+gpS7C1t8
La2470sxb3E9XiE+Z9MVRbgOwCjxFu3lY/AQfNA7WXhsdijA5+v3rGChQt311jkj
REaXUsqNAk+PxtF8F5HcpSqx96H9bI2MEu4SttPDoxBQVgMYnDaRTfkvpxj7mZlv
rDnMYIBjn5qsJP5E6dgN+HnV/UVq7FxWwJ6rQA50fyezGez0ZRvKcSxe8ANFzbcL
+BzPbua/hEVyrjG9nXdtvMHQpIh60xUCLwj0ZaInIhOeDe78O/c0q17VHjBWclab
c556Y8sF44ldvnD/STdRrUwKEDyRAoWb9N/M7XPIpHNl0kBuA0jXLJKVAQE6S0Jf
gcTiKkeLAgMBAAECggEAURHl3o1IDi8on4HbouVZIms4phQrXiZlIAe6iObtlXR7
pIPU4usQ5iFmeB7HVX62Oz8tOoNSvGdsP5EyIRVz9Apr9OzudMD2YwjhzBq0GzHt
wWDXbtW8L++vggMHmZDQXPQ+8vERNxMsCwyJ/xFqLG733ZrE/4ZibNsfW0tXKKA/
vsXt2LWArIKiD0msFEJCPgL100pQkvYIpoJZ6sHnaOJofqACTbdCj2iokSsprlGB
0FvdtUzMSoIpKpYo3284ZtIzkwMVjRbRxJfpEFfyXXrJrOAE3tcA/d/wOZVIwb4m
Z/l3kvcgzWah7Qdsc/OjTryfbNIpKSRr+V4PtyC3AQKBgQDThqPWGuelFYs5cIwW
TH/cT/CdMpfNYTfdPr12/SP9URhf1/yS00G0r2uugsdEsjA9BJcqZbmgmKx1LUIh
Dn/7j7um7dPq4KFctMejBJgCeBD6AYMyVGoWoieKBSVPO1dBWnHUecFIv3mtFrRH
kDhzEmS1wDd8f+RWQhETGJ3O2wKBgQDEFvQm8V+FRbINeNwxOwz7BsvZYe3iGb6q
7O6zNZCoBRwB01X+PQkhry16BvMZ/YKNx8aZqUICP7d6vf6teKHA4962TSnaaYqJ
ZPDzNtWRTVRYtybPAhcGiqrO33buZ2ogLAdTbMn16hG8WalLx37VgBTiEOsSeTf6
ryFOgckREQKBgB1Myyj/NRMi9tQQCPeVxShJUnUT6v8h9lEJPclbqz6Nmyi7jFry
NGnI2sujheK4JAJvvli7GolqXIkmqcBWd9fqwv2OeApS70ceK4EjQ8MjyoY262tv
Ufqsn3l42QAuohmFY7sg2msvSrV1Lae0DH20EIs0gvsV5BUmtaLFiCZ9AoGAYF7r
lWwRRv2O2WIpzaQ45/JaIzcm43VFqNmTIs5TjtAcCKWl4LJ8l2pxzkQ2G/Lkw+uI
JqLxxwsrkI5p6TWdQaB8J1pbFHXEWWwbo1yyr5uytXsl/p0HVfa2pb9bwyVeGfup
ig2wYESufMQQGSctpZ4yJTytW0HqCjEiDGRqvhECgYEAjYT2NQ64GlMeh1k6ahnB
gW0TUux1o3uFSk5mTLLmveVOfimwlJyc8WGvB4EEa8PX74/RqqNrTbXhMYHU5UIU
h3c+UGOCVfWSe59f+FUvG3bXZPI4Fc13VtzbmipO5taYu+Lb5TCZIyv6v2fDxKrk
LO5GwCi+33F6sdHDnU0mErU=
-----END RSA PRIVATE KEY-----',
                'rsa_sign_public_key'   => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoRYRUfQsGc7drqfg2K1C
3gWQLLiFjYyB1clTmdandjpjh4wiJo9dfIDgGsNAR+Mx4EqL4plqJD1mLnWkTu9K
mI1ud1FQ2xvepL1XnuxRa01WiPA7YM5WsNiUqXIZItdFFzpnE6r2hpct9bmwvOa/
4Pjlg26REfSZEtA21cjPFxxI06pBr4Y8isP2aoHVBLBWy7yJ79OQPchMBfXPOF5r
bAMzkqViNZp9tw2RJ9erwZwOuUC+nGDGaH2D9Sr9S3H3HLLV0ibJ7gq8ht5D/BXA
/z1uRdCScruEtLwbmzevoP5FgUKUyXgj9dR8xjjG9ljrKdZxwW4/De29Zp+02roi
IwIDAQAB
-----END PUBLIC KEY-----',
                'rsa_public_key'        => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1lStik4jwa6ZHSguzNaw
AoCY6st4CR2XwNExXbSje/p9aMQ4cbj/zHV1z3HeNqagdewtNWNHXR8wDf3OnskI
eIZwLzAKZy+H5B6qL9mJ7mkGM8hC3OsY3LhJAcmpsOOebRtTKq8/9O2NiwrSjXFb
KRBdpOqMi/FIvouIJSERE0eUHo0HpT9ncMnzVHxxzo4Fw/c2YNwQpvhqhaz23dUJ
3ZTRz6a4B9ROM9zvXDp1kb+G5QU6ITuRlXEho+wVfiHc/qO2+CAJ4CTdS0O2u/P8
BQX/rQlXiEICtQmeZt7lVguMGmkSQrswnyQB9Bkqu6e/L9YQP3y+tzIaYtjGE+AE
9wIDAQAB
-----END PUBLIC KEY-----',
                'notify_url_1'     		=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentOnekey',//一键支付回调
                'notify_url_2'     		=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentPayOnekey',//一键代付回调
                'notify_url_3'       	=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentIntel',//智能支付回调
                'notify_url_4'       	=> 'https://api.xiaobaijinfu.com/synorder/yakukubaoRepaymentPayIntel',//智能代付回调
                'masRequestUrl'         => 'http://test.gate.yacolpay.com/mas/gateway.do',//卡要素支付、支付发送短信验证、短信重发、单笔支付查询、代付到银行卡、代付订单查询接口
                'mgsRequestUrl'         => 'http://test.gate.yacolpay.com/mgs/gateway.do',//小微商户入网，小微商户绑定结算卡
                'queryRequestUrl'       => 'http://test.gate.yacolpay.com/mgs/gateway.do',//小微商户信息查询，小微商户账户余额查询
                'debug_status'         	=> false,
            )
        );
    }
}