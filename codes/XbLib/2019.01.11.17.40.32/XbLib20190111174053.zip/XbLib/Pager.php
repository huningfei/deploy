<?php   
/**
 * PHP分页类
 * @author nengzhi
 * 2015-07-16
 * UTF-8
 */ 
class XbLib_Pager{
	
	private static $obj = null;
    private $pagesize = 10;			//每页个数  
    private $pageindex = 1;   			//当前页
    private $totalnum;   			//数据总条数
    private $totalpagescount;   	//总页数
    private $pageurl;   			//分页url	
    private static $_instance;
     
   /**
    * 获取单例对象
    * @param string $hl
    * @param number $timeout
    * @return TyLib_SolrSearch
    */
   public static function getInstance(){
   		if(is_null(self::$obj)){
    		self::$obj = new XbLib_Pager();
    	}
    	return self::$obj;
    }
    
    /**
     * 初始化分页参数
     * @param unknown $p_totalnum
     * @param unknown $p_pageindex
     * @param number  $p_pagesize
     * @param number  $p_initnum
     * @param number  $p_initmaxnum
     * @return string $this
     */
    public function init($p_totalnum, $p_pageindex, $p_pageurl, $p_pagesize = 10,$p_initnum=3){
    	if(!isset ($p_totalnum) || !isset($p_pageindex) || !isset($p_pageurl)){
    		$p_totalnum = 1000;
    		$p_pageindex = 1;
    		$p_pageurl = '{page}';
    	}
    	$this->totalnum			= $p_totalnum;
    	$this->pageindex		= $p_pageindex;
    	$this->pagesize 		= $p_pagesize;
    	$this->initnum 			= $p_initnum;
    	$this->pageurl 			= $p_pageurl;
    	$this->totalpagescount	= ceil($p_totalnum / $p_pagesize);
    	$this->_initPagerLegal(); //验证参数
    	return $this;
    }
    
  /**
   * 效验页面参数是否合法  
   */  
  private function _initPagerLegal(){   
      if((!is_numeric($this->pageindex)) ||  $this->pageindex<1){   
          $this->pageindex=1;
      }elseif($this->pageindex > $this->totalpagescount){   
          $this->pageindex=$this->totalpagescount;
      }
      return $this;
  }   
  
  /**
   * 组合分页 Document代码
   * @return string
   */
  public function GetPagerDocument(){
        
  	$str = "<div class=\"c-page\">";  
  	if($this->totalpagescount <= 1){
  		return '';
  	}
    //首页 上一页   
    if($this->pageindex == 1){
		$str .='<span>首页</span>'."\n";
    }else{
    	$str .='<a href=' . $this->pageIndexReplace(1) . ' title="首页">首页</a> '."\n";
    	$str .='<a href=' . $this->pageIndexReplace($this->pageindex-1) . ' title="上一页">上一页</a> '."\n"."\n";
    }
    //10页（含）以下 
    if($this->totalpagescount <= 10){
    	for($i=1; $i<=$this->totalpagescount; $i++){   
        	if($i == $this->pageindex){
        		$str .= '<span>'.$i.'</span>'."\n";
        	}else{
        		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        	}
        }   
     }else{
     	//10页以上
     	if($this->pageindex < $this->initnum){
        	for($i=1; $i<=$this->initnum; $i++){   
            	if($i==$this->pageindex){
            		$str .= '<span>'.$i.'</span>'."\n";
            	}else{
            		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
            	}
            }
            $str.='<span>……</span>'."\n";
            for($i = ($this->totalpagescount-$this->initnum)+1; $i <= $this->totalpagescount; $i++){
            	$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
            }
        }elseif($this->pageindex > $this->totalpagescount-($this->initnum*2-1)){
        	for($i=1;$i<=$this->initnum;$i++){
        		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        	}
        	$str.='<span>……</span>'."\n";
        	for($i = $this->pageindex-1; $i <= $this->totalpagescount; $i++){
        		if($i==$this->pageindex){
        			$str .= '<span>'.$i.'</span>'."\n";
        		}else{
        			$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        		}
        	}
        }elseif($this->initnum*2 > $this->pageindex){

        	for($i=1;$i<=$this->pageindex+1;$i++){
        		if($i==$this->pageindex){
            		$str .= '<span>'.$i.'</span>'."\n";
            	}else{
            		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
            	}
        	}
        	$str.='<span>……</span>'."\n";
        	for($i = ($this->totalpagescount-$this->initnum)+1; $i <= $this->totalpagescount; $i++){
        		if($i==$this->pageindex){
        			$str .= '<span>'.$i.'</span>'."\n";
        		}else{
        			$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        		}
        	}
        }elseif($this->initnum*2 <= $this->pageindex){
        	for($i=1;$i<=$this->initnum;$i++){
        		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n" ;
        	}
        	$str.='<span>……</span>'."\n";
        	$num = intval($this->initnum/2);
        	for($i = $this->pageindex-$num; $i <= $this->pageindex+$num; $i++){
        		if($i==$this->pageindex){
        			$str .= '<span>'.$i.'</span>'."\n";
        		}else{
        			$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        		}
        	}
        	$str.='<span>……</span>'."\n";
        	for($i=$this->totalpagescount-$this->initnum+1; $i<=$this->totalpagescount; $i++){
        		$str .='<a href='.$this->pageIndexReplace($i).' >'.$i.'</a>'."\n";
        	}
        }else{
        	for($i=1;$i<=$this->initnum;$i++){
        		$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        	}
        	$str.='<span>……</span>'."\n";
        	for($i = ($this->totalpagescount-$this->initnum); $i <= $this->totalpagescount; $i++){
        		if($i==$this->pageindex){
        			$str .= '<span>'.$i.'</span>'."\n";
        		}else{
        				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
        		}
        	}
        }
     }
//除首末后 页面分页逻辑结束   
     //下一页 尾页   
     if($this->pageindex == $this->totalpagescount){
            $str .='<span>尾页</span>'."\n";
        }else{
        	$str .="\n".'<a href='.$this->pageIndexReplace($this->pageindex+1)." title='下一页'>下一页</a>"."\n";
        	$str .='<a href='.$this->pageIndexReplace($this->totalpagescount)." title='尾页'>尾页</a>"."\n";
        }
        $str .= '</div>';
        return $str;   
    }
    
    /**
     * 组合分页 Document代码(理财搜索分页)
     * @return string
     */
    public function GetPagerDocumentSearch(){
    
    	$str = "<div class=\"c-page\">";
    	if($this->totalpagescount <= 1){
    		return '';
    	}
    	//首页 上一页
    	if($this->pageindex == 1){
    		$str .='<span class="c">首页</span>'."\n";
    	}else{
    		$str .='<a href=' . $this->pageIndexReplace(1) . ' title="首页">首页</a> '."\n";
    		$str .='<a href=' . $this->pageIndexReplace($this->pageindex-1) . ' title="上一页">上一页</a> '."\n"."\n";
    	}
    	//10页（含）以下
    	if($this->totalpagescount <= 10){
    		for($i=1; $i<=$this->totalpagescount; $i++){
    			if($i == $this->pageindex){
    				$str .= '<span class="c">'.$i.'</span>'."\n";
    			}else{
    				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    			}
    		}
    	}else{
    		//10页以上
    		if($this->pageindex < $this->initnum){
    			for($i=1; $i<=$this->initnum; $i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    			$str.='<span>……</span>'."\n";
    			for($i = ($this->totalpagescount-$this->initnum)+1; $i <= $this->totalpagescount; $i++){
    				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    			}
    		}elseif($this->pageindex > $this->totalpagescount-($this->initnum*2-1)){
    			for($i=1;$i<=$this->initnum;$i++){
    				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    			}
    			$str.='<span>……</span>'."\n";
    			for($i = $this->pageindex-1; $i <= $this->totalpagescount; $i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    		}elseif($this->initnum*2 > $this->pageindex){
    
    			for($i=1;$i<=$this->pageindex+1;$i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    			$str.='<span>……</span>'."\n";
    			for($i = ($this->totalpagescount-$this->initnum)+1; $i <= $this->totalpagescount; $i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    		}elseif($this->initnum*2 <= $this->pageindex){
    			for($i=1;$i<=$this->initnum;$i++){
    				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n" ;
    			}
    			$str.='<span>……</span>'."\n";
    			$num = intval($this->initnum/2);
    			for($i = $this->pageindex-$num; $i <= $this->pageindex+$num; $i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    			$str.='<span>……</span>'."\n";
    			for($i=$this->totalpagescount-$this->initnum+1; $i<=$this->totalpagescount; $i++){
    				$str .='<a href='.$this->pageIndexReplace($i).' >'.$i.'</a>'."\n";
    			}
    		}else{
    			for($i=1;$i<=$this->initnum;$i++){
    				$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    			}
    			$str.='<span>……</span>'."\n";
    			for($i = ($this->totalpagescount-$this->initnum); $i <= $this->totalpagescount; $i++){
    				if($i==$this->pageindex){
    					$str .= '<span class="c">'.$i.'</span>'."\n";
    				}else{
    					$str .='<a href='.$this->pageIndexReplace($i).'>'.$i.'</a>'."\n";
    				}
    			}
    		}
    	}
    	//除首末后 页面分页逻辑结束
    	//下一页 尾页
    	if($this->pageindex == $this->totalpagescount){
    		$str .='<span class="c">尾页</span>'."\n";
    	}else{
    		$str .="\n".'<a href='.$this->pageIndexReplace($this->pageindex+1)." title='下一页'>下一页</a>"."\n";
    		$str .='<a href='.$this->pageIndexReplace($this->totalpagescount)." title='尾页'>尾页</a>"."\n";
    	}
    	$str .= '</div>';
    	return $str;
    }
    /**
     * 替换分页 页数
     * @param unknown $index
     */
    private function pageIndexReplace($index){
    	return str_replace('{page}', $index, $this->pageurl);
    }
}