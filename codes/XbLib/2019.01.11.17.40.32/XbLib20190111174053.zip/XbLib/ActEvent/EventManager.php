<?php

require_once __DIR__ . '/CommonEvent.php';
require_once __DIR__ . '/AbstractEvent.php';
require_once __DIR__ . '/AbstractListener.php';


class XbLib_ActEvent_EventManager
{
    private static $_listener = array();
    
    private static $_event = array();
    
    private static function _uswToPascal($sStr)
    {
        $aStr = explode('_', trim($sStr));
        $sRtn = '';
        foreach ($aStr as $s) 
            $sRtn .= ucfirst(strtolower($s));
        
        return $sRtn;
    }
    
    /**
     * 设置事件监听对象
     * 
     * @param string $sEventName 事件名
     * @param string $sListener 监听对象class名（区分大小写）
     *                          （同一事件无法绑定多个相同的监听对象，但可以绑定多个不同的监听对象）
     * @return AbstractListener
     */
    public static function attach($sEventName, $sListener = 'DefaultListener')
    {
        if (!$sListener || !$sEventName)
            return;
        
        if (!isset(self::$_listener[$sEventName][$sListener]))
        {
            require_once __DIR__ . "/Listener/{$sListener}.php";
            self::$_listener[$sEventName][$sListener] = new $sListener();
        }
        
        return self::$_listener[$sEventName][$sListener];
    }
    
    /**
     * 触发事件
     * 
     * @param string $sEventName 事件名称
     * @param object $oCaller 触发事件的对象，通常使用$this，如果静态方法调用，可以使用__CLASS__
     * @param array $aData 触发事件的数据，见各个事件的定义
     * @return AbstractEvent
     */
    public static function trigger($sEventName, $oCaller, array $aData = array())
    {
        if (empty(self::$_listener[$sEventName]))
            return;
        
        $sEventClass = self::_uswToPascal($sEventName);
        
        if (!isset(self::$_event[$sEventName]))
        {
            $sClassName = $sEventClass . 'Event';
            $sClassFile = __DIR__ . "/Events/{$sClassName}.php";
            if (!file_exists($sClassFile))
            {
                $sClassName = 'DefaultEvent';
                $sClassFile = __DIR__ . "/Events/DefaultEvent.php";
            }
            
            require_once $sClassFile;
            $oEvent = new $sClassName($sEventName, $oCaller, $aData);
            $bOk = $oEvent->init();
            
            if ($bOk)
                self::$_event[$sEventName] = $oEvent;
        }
        else 
        {
            $oEvent = self::$_event[$sEventName];
            foreach ($aData as $k => $v)
                $oEvent->set($k, $v);
        }
        
        if (!isset(self::$_event[$sEventName]))
            return;

        $sMethodName = lcfirst($sEventClass);
        
        foreach (self::$_listener[$sEventName] as $oListener)
        {
            if (method_exists($oListener, $sMethodName))
                $oListener->$sMethodName(self::$_event[$sEventName]);
        }
        
        return self::$_event[$sEventName];
    }
    
    /**
     * 获取事件（只会返回被监听或有回调的事件）
     * 
     * @param string $sEventName
     * @return AbstractEvent
     */
    public static function getEvent($sEventName)
    {
        return self::$_event[$sEventName];
    }
}