<?php


/**
 * 事件检查类
 * 
 * 
 * 当验证的数据对象不存在，视为验证失败
 * 当验证的数据对象属性不存在，其值作为null处理
 */
class XbLib_ActEvent_Check {
    
    private static $_instance;
    
    private $_config; 
    
    private $_target = [];
    
    private $_option = [];
    
    private $_success = [];
    
    private $_fail = [];
    
    
    private function __construct() {
        $this->_config = require __DIR__ . '/config.php';
    }
    
    /**
     * 
     * @return XbLib_ActEvent_Check
     */
    public static function getInstance() {
        if (!self::$_instance) {
            self::$_instance = new self();
        }
        
        return self::$_instance;
    }
    
    private function _onFail($val, $option) {
        $this->_fail[] = [
            'option' => $option,
            'value' => $val
        ];
    }
    
    private function _onSuccess($val, $option) {
        $this->_success[] = [
            'option' => $option,
            'value' => $val
        ];
    }
    
    private function _onError($msg) {
        throw new Exception($msg);
    }
    
    public function getSuccessOption() {
        return $this->_success;
    }
    
    public function getFailOption() {
        return $this->_fail;
    }
    
    public function getTargetData() {
        return $this->_target;
    }
    
    /**
     * 获取事件检查规则
     * 
     * @return array
     */
    public function getCheckRule() {
        $data = $this->_config['event_check_rule'];
        foreach ($data as &$item) {
            foreach ($item['option_list'] as &$gt) {
                $tmp = explode('|', $gt['op']);
                $opdata = [];
                foreach ($tmp as $op) {
                    if (isset($this->_config['op'][$op])) {
                        $opdata[$op] = $this->_config['op'][$op];
                    }
                }
                
                $gt['op'] = $opdata;
            }
        }
        
        return $data;
    }
    
    
    /**
     * 设置验证选项
     * 
     * @param unknown $option
     * @return XbLib_ActEvent_Check
     */
    public function setOption($option) {
        $this->_option = $option;
        
        return $this;
    }
    
    /**
     * 设置验证对象
     * 
     * @param unknown $name
     * @param unknown $data
     * @return XbLib_ActEvent_Check
     */
    public function setTarget($name, $data) {
        $this->_target[$name] = $data;
        
        return $this;
    }
    
    /**
     * 初始化
     * 
     * @return XbLib_ActEvent_Check
     */
    public function reset() {
        $this->_target = [];
        $this->_option = [];
        $this->_success = [];
        $this->_fail = [];
        
        return $this;
    }
    
    /**
     * 检查全部规则
     * 
     * @return boolean
     */
    public function check($reset = true) {
        foreach ($this->_option as $option) {
            $succ = $this->checkRule($option);
            
            if (!$succ) {
                if ($reset) $this->reset();
                
                return false;
            }
        }

        if ($reset) $this->reset();
        
        return true;
    }
    
    /**
     * 更新检查记录（记录参与记录）
     * 
     * @param unknown $activity_id
     * @param unknown $event_token
     * @param unknown $data
     */
    public function updateCheckRecord($activity_id, $event_token, $data) {
        switch ($event_token) {
            //设置取现数据
            case 'after_withdraw':
                $uid = $data['user_id'];
                $key = "XbAct:{$activity_id}:{$event_token}:{$uid}";
                $data = XbModule_Act_ActivityData::getInstance()->getAll($key);
                //记录活动参与次数                
                XbModule_Act_ActivityData::getInstance()->incr($key, 'activity_join_times', 1);

                break;
                //设置信用卡注册数据
            case 'after_upload_creditcard_apply':
                $uid = $data['uid'];
                $key = "XbAct:{$activity_id}:{$event_token}:{$uid}";
                
                $str = XbModule_Act_ActivityData::getInstance()->get($key, 'applied_order_id');
                $str = $str ? $str : '';
                $bank = explode(',', $str);
                $bank[] = $data['order_id'];
                $str = trim(implode(',', array_unique($bank)), ',');
                
                XbModule_Act_ActivityData::getInstance()->set($key, 'applied_order_id', $str);

                break;
        }
        
        return $this;
    }
    
    /**
     * 获取活动数据
     * 
     * 
     */
    public function setActData($activity_id, $event_token, $data) {
        switch ($event_token) {
            //设置取现数据
            case 'after_withdraw':
                $uid = $data['user_id'];
                $order_id = empty($data['order_id']) ? 0 : $data['order_id'];
                $mch_id = empty($data['mch_id']) ? 0 : $data['mch_id'];
                $user_data = XbModule_Account_Users::getInstance()->getUserById($uid);
                
                if (empty($mch_id)) $mch_id = $user_data['mch_id'];
                
                $key = "XbAct:{$activity_id}:{$event_token}:{$uid}";
                $data = XbModule_Act_ActivityData::getInstance()->getAll($key);
                
                //没有最后取款时间记录，查询并创建
                if (!isset($data['first_withdraw_date']) || $data['first_withdraw_date'] === false) {
                    $data['first_withdraw_date'] = XbModule_Account_Order::getInstance($mch_id)->getFirstPlayTime($uid);
                    $data['first_withdraw_date'] = $data['first_withdraw_date'] ? $data['first_withdraw_date'] : 0;
                    
                    //如果用户的首次取款记录存在，记录首次取款时间，否则取当前时间作为首次收款时间，但是不做记录
                    //由于with_draw 事件只在取款成功后触发，不存在找不到首次收款时间的可能性
                    //唯一发生的可能是在检查用户是否具备参与资格，此时默认将在当前时间取款，所以首次收款时间是当前时间
                    if ($data['first_withdraw_date']) {
                        XbModule_Act_ActivityData::getInstance()->set($key, 'first_withdraw_date', $data['first_withdraw_date']);
                    }
                    else {
                        $data['first_withdraw_date'] = time();
                    }
                }

                //补充必要用户数据
                $user_data['first_withdraw_date'] = empty($data['first_withdraw_date']) ? 0 : $data['first_withdraw_date'];
                $user_data['activity_join_times'] = empty($data['activity_join_times']) ? 0 : $data['activity_join_times'];

                //参与次数在已经参与次数基础上加1，作为判断时的参与次数
                $user_data['activity_join_times']++;

                if ($order_id && $mch_id) {
                    $order_data = XbModule_Account_Order::getInstance($mch_id)->getOrderByOrderid($order_id);
                }
                else {
                    $order_data = [];
                }
                
                //补充订单数据
                $order_data['max_free_for_withdraw'] = 0;
                
                $this->setTarget('user', $user_data);
                $this->setTarget('order', $order_data);
                
                break;
            //设置信用卡注册数据
            case 'after_upload_creditcard_apply':
                $uid = $data['uid'];
                $key = "XbAct:{$activity_id}:{$event_token}:{$uid}";
                $data_cache = XbModule_Act_ActivityData::getInstance()->getAll($key);
                
                $data = array_merge($data, $data_cache);
                
                //已经注册过的银行
                $data['applied_order_id'] = empty($data['applied_order_id']) ? [] : explode(',', $data['applied_order_id']);
                $data['bank_is_applied'] = in_array($data['order_id'], $data['applied_order_id']) ? 1 : 0;
                
                $this->setTarget('users_apply_bank', $data);
                break;
        }   
        
        return $this;
    }
    
    /**
     * 检查数据是否符合指定规则
     * 
     * @param unknown $option
     * @return boolean
     */
    public function checkRule($option) {

        if (!isset($option['target'])) {
            $this->_onError('target is undefined: ' . var_export($option, true));
            return false;
        }
        
        if (!isset($option['target_attr'])) {
            $this->_onError('target_attr is undefined: ' . var_export($option, true));
            return false;
        }
        
        if (!isset($option['op'])) {
            $this->_onError('op is undefined: ' . var_export($option, true));
            return false;
        }
        
        if (!isset($option['value'])) {
            $this->_onError('value is undefined: ' . var_export($option, true));
            return false;
        }
        
        if (!isset($option['target_type'])) {
            $this->_onError('target_type is undefined: ' . var_export($option, true));
            return false;
        }

        //验证对象不存在
        if (!isset($this->_target[$option['target']])) {
            $this->_onFail(null, $option);
            return false;
        }
        
        //尝试获取属性值，没有则取null
        $val = isset($this->_target[$option['target']][$option['target_attr']]) ? 
            $this->_target[$option['target']][$option['target_attr']] :
            null;
        
        
        $succ = $this->_check($val, $option['op'], $option['value'], $option['target_type']);
        
        if ($succ) {
            $this->_onSuccess($val, $option);
        }
        else {
            $this->_onFail($val, $option);
        }
        
        return $succ;
    }
    
    /**
     * 按数据类型获取数据值
     * 
     * @param unknown $val
     * @param unknown $type
     * @return unknown|number|string|number|NULL
     */
    private function _getValue($val, $type) {
        //'datetime', 'string', 'int'
        switch ($type) {
            case 'datetime':
                return is_numeric($val) ? $val : strtotime($val);
                break;
            case 'string':
                return (string)$val;
                break;
            case 'int':
                return (int)$val;
                break;
            case 'float':
                return (float)$val;
                break;
            default:
                $this->_onError('unsupported data type: ' . $type);
                break;
        }
        
        return null;
    }
    
    /**
     * 比较数据
     * 
     * @param unknown $val
     * @param unknown $op
     * @param unknown $limit
     * @param unknown $type
     * @return boolean
     */
    private function _check($val, $op, $limit, $type) {
        $val = $this->_getValue($val, $type);
        $limit = json_decode($limit);
        switch ($op) {
            case 'gt':
                return $val > $this->_getValue($limit, $type);
                break;
            case 'egt':
                return $val >= $this->_getValue($limit, $type);
                break;
            case 'eq':
                return $val == $this->_getValue($limit, $type);
                break;
            case 'lt':
                return $val < $this->_getValue($limit, $type);
                break;
            case 'elt':
                return $val <= $this->_getValue($limit, $type);
                break;
            case 'range':
                $left = isset($limit[0]) ? $val >= $this->_getValue($limit[0], $type) : true;
                $right = isset($limit[1]) ? $val <= $this->_getValue($limit[1], $type) : true;
                return $left && $right;
                break;
            case 'in':
                $limit = (array)$limit;
                return in_array($val, $limit);
                break;
            default:
                $this->_onError('unsupported data op: ' . $op);
                break;
        }
        
        return false;
    }
    
    /**
     * 按id获取规则类型
     * 
     * @param unknown $id
     * @return NULL
     */
    public function getRuleTypeById($id) {
        return isset($this->_config['event_check_rule'][$id]) ? $this->_config['event_check_rule'][$id] : null;
    }
    

}