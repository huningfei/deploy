<?php

class DefaultListener extends AbstractListener
{
    /**
     * 取现成功
     * 
     */
    public function afterWithdraw(AbstractEvent $oEvent) {
 
        $uid = $oEvent->get('user_id');
        $mch_id = $oEvent->get('mch_id');
        $order_id = $oEvent->get('order_id');

        $activityList = XbModule_Act_Activity::getInstance()->tryJoin($oEvent->getName(), [
            'user_id' => $uid,
            'mch_id' => $mch_id,
            'order_id' => $order_id
        ]);

        if ($activityList) {
            foreach ($activityList as $act) {
                $data = [];
                //设置接口参数
                $data['activity_id'] = $act[0]['id'];
                $data['award_rule_id'] = $act[0]['rule_id'];
                $data['amount'] = $act[2]['order']['amount'];
                $data['rule_id'] = $act[0]['rule_id'];
                $data['free_for_amount'] = $data['amount'];

                //获取免单金额
                foreach ($act[1] as $option) {
                    if ($option['option']['target'] == 'order' && $option['option']['target_attr'] == 'max_free_for_withdraw') {
                        $max = json_decode($option['option']['value'], true);
                        $data['free_for_amount'] = $data['free_for_amount'] > $max ? $max : $data['free_for_amount'];
                    }
                    
                }
                
                $data['order_id'] = $act[2]['order']['order_id'];
                $data['user_id'] = $uid;
                $data['item_type'] = 2;
                
                $logId = XbModule_Act_ActivityLog::getInstance()->add($data['activity_id'], $data['user_id'], $data['order_id'], $data);

                $data['log_id'] = $logId;
                
                $this->callApi('send_award', $data);
            }
        }

        $oEvent->set('response', $activityList);
        
    }
    
    /**
     * 上传信用卡申请
     * 
     */
    public function afterUploadCreditcardApply(AbstractEvent $oEvent) {
        
        $id = $oEvent->get('file_id');
        
        $file = XbModule_Account_CommonBankFile::getInstance()->getBankFileById($id);
        
        $data = XbModule_Account_Users::getInstance()->getApplyBankList(0, 99999, '', '', '', '', $file['batch_number']);

        foreach ($data as $row) {
            $activityList = XbModule_Act_Activity::getInstance()->tryJoin($oEvent->getName(), $row);
 
            if ($activityList) {
                foreach ($activityList as $act) {

                    $data = [];
                    //设置接口参数
                    $data['activity_id'] = $act[0]['id'];
                    $data['award_rule_id'] = $act[0]['rule_id'];
                    $data['rule_id'] = $act[0]['rule_id'];

                    $data['order_id'] = $act[2]['users_apply_bank']['order_id'];
                    $data['user_id'] = $act[2]['users_apply_bank']['uid'];
                    $data['users_apply_bank_id'] = $act[2]['users_apply_bank']['id'];
                    $data['bank'] = $act[2]['users_apply_bank']['bank'];
                    $data['item_type'] = 1;
                    
                    $logId = XbModule_Act_ActivityLog::getInstance()->add($data['activity_id'], $data['user_id'], $data['order_id'], $data);
                    
                    $data['log_id'] = $logId;
                    
                    $this->callApi('send_award', $data);
                }
            }
        }
        
        $oEvent->set('response', []);
    }
    
    /**
     * 上传信用卡申请资料excel文件
     * 
     */
    public function afterUploadCreditcardApplyExcel(AbstractEvent $oEvent) {
        $id = $oEvent->get('file_id');
        
        $data = ['id' => $id];
        $this->callApi('excel_notice', $data);
        
        $oEvent->set('response', []);
    }
}