<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015-11-2
 * UTF-8
 */
class XbLib_WebSpam{
	
	
	
	
	
}