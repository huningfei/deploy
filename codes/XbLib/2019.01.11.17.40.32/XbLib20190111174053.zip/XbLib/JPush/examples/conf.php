<?php
require __DIR__ . '/../autoload.php';

use JPush\Client as JPush;

$app_key = getenv('app_key');
$master_secret = getenv('master_secret');
$registration_id = getenv('registration_id');

$client = new JPush($app_key, $master_secret);
