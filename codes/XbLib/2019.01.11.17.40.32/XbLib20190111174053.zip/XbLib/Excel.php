<?php


Class XbLib_Excel{

    private static $obj;


    private function __construct(){

    }
    private function __clone(){

    }

    /*
     * */
    public static function getInstance()
    {
        if (empty(self::$obj)) {
            self::$obj = new XbLib_Excel();
        }
        return self::$obj;
    }
    function excelToArray($filename,$indexKey){
        require_once dirname(__FILE__) . '/Classes/PHPExcel/IOFactory.php';

        $objPHPExcelReader = PHPExcel_IOFactory::load($filename);

        $reader = $objPHPExcelReader->getWorksheetIterator();
        //循环读取sheet
        $i = 0;
        foreach($reader as $sheet) {
            //读取表内容
            $content = $sheet->getRowIterator();

            //逐行处理
            $res_arr = array();
            foreach($content as $key => $items) {

                $rows = $items->getRowIndex();              //行
                $columns = $items->getCellIterator();       //列
                $row_arr = array();
                $i = 0;
                //确定从哪一行开始读取
                if($rows < 2){
                    continue;
                }
                //逐列读取
                foreach($columns as $head => $cell) {
                    //获取cell中数据
                    $data = $cell->getValue();
                    $row_arr[$indexKey[$i]] = $data;
                    $i++;
                }
                $res_arr[] = $row_arr;
            }

        }

        return $res_arr;
    }
    //文件导出
    public function exportExcel($list,$filename,$indexKey=array(),$head){
        require_once dirname(__FILE__) . '/Classes/PHPExcel/IOFactory.php';
        require_once dirname(__FILE__) . '/Classes/PHPExcel.php';
        require_once dirname(__FILE__) . '/Classes/PHPExcel/Writer/Excel2007.php';

        $header_arr = array('A','B','C','D','E','F','G','H','I','J','K','L','M', 'N','O','P','Q','R','S','T','U','V','W','X','Y','Z');

        $objPHPExcel = new PHPExcel();                        //初始化PHPExcel(),不使用模板
//        $template = dirname(__FILE__).'/template.xls';          //使用模板
//        $objPHPExcel = PHPExcel_IOFactory::load($template);     //加载excel文件,设置模板

        $objWriter = new PHPExcel_Writer_Excel5($objPHPExcel);  //设置保存版本格式
        //接下来就是写数据到表格里面去
        $objActSheet = $objPHPExcel->getActiveSheet();
        //设置单元格格式

        foreach($head as $k => $v){
            foreach($header_arr as $kk => $vv){
//            $objActSheet->getColumnDimension($header_arr[$k])->setWidth(20);
            $objPHPExcel->getActiveSheet()->getStyle($header_arr[$k])->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_TEXT);

            $objActSheet->setCellValue($header_arr[$k].'1',$v);
            }
        }

        $i =2;
        if($list){
            foreach ($list as $row) {
                foreach ($indexKey as $key => $value){
                    //这里是设置单元格的内容
                    $objActSheet->setCellValue($header_arr[$key].$i,$row[$value]);
                }
                $i++;
            }

        }

        // 1.保存至本地Excel表格
        //$objWriter->save($filename.'.xls');

        // 2.接下来当然是下载这个表格了，在浏览器输出就好了

        ob_end_clean();
        ob_start();
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
        header("Content-Type:application/force-download");
        header("Content-Type:application/vnd.ms-execl");
        header("Content-Type:application/octet-stream");
        header("Content-Type:application/download");;
        header('Content-Disposition:attachment;filename="'.$filename.'.xls"');
        header("Content-Transfer-Encoding:binary");
        $objWriter->save('php://output');
    }

}


?>