<?php

/**
 * PHP SCWS 扩展类
 * @author nengzhi
 * 2014-10-28
 * UTF-8
 */
class XbLib_DyNamic{
    
    private static $obj = null;
    private $scws_model = null;
    //词库路径  缺省值SCWS默认词库
    public $nam_path = null;
    


    
   /**
    * 单例获取
    * 保证一条进程只产生一个Module对象
    */
    public static function getInstance() {
	   
	if (empty ( self::$obj )) {
            self::$obj = new XbLib_DyNamic();
	}
            return self::$obj;
    }
    
    /**
     * 分词方法
     * @param string $str 预分词字符串
     * @return array $result 分词结果
     */
    public function Participles($str){
        
        //获取SCWS配置
        $this->initConfig();
        $this->scws_model->send_text($str);
        $data = null;
        while($tmp = $this->scws_model->get_result()){
            $data[] = $tmp;
        }
        return $data;
    }
    
    /**
     * 初始化SCWS
     * 
     */
    public function initConfig() {
        //实例化SCWS
        $this->scws_model = scws_new();
        //设置编码
        $this->scws_model->set_charset('utf8');
        //词库路径
        $this->scws_model->set_dict($this->nam_path ? $this->nam_path : ini_get('scws.default.fpath') . '/dict.utf8.xdb');
        //分词规则
        $this->scws_model->set_rule(ini_get('scws.default.fpath') . '/rules.utf8.ini');
        //禁用标点符号
        $this->scws_model->set_ignore(true);
        //使用复式分割
        //$this->scws_model->set_multi(true);
    }
    
}