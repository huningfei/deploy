<?php

/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-25
 * UTF-8
 */
class XbLib_Dic
{

    /**
     * ********ACCOUNT************
     */
    public static $account_dic = array(
        "user_is_black" => array(
            0 => "否",
            1 => "是"
        ),
        "user_type" => array(
            1 => "普通用户",
            2 => "机构用户"
        ),
        "user_reg_channel" => array(
            1 => "WEB"
        ),
        "is_new_licence" => array(
            1 => "三证",
            2 => "三证合一",
            3 => "一证一码"
        ),
        "account_type" => array(
            1 => "充值",
            2 => "提现"
        ),
        "account_cz_status" => array(
            0 => "待支付",
            1 => "支付成功",
            2 => "支付失败",
            3 => "进行中"
        ),
        "account_tx_status" => array(
            0 => "处理中",
            1 => "提现成功",
            2 => "提现失败",
            3 => "进行中"
        ),
        "account_channel" => array(
            1 => "新浪"
          )
    );

    /**
     * ********Asset***************
     */
    public static $asset_dic = array(
        "asset_status" => array(
            0 => "草稿",
            1 => "审核中",
            2 => "审核通过项目进行中",
            3 => "审核失败",
            4 => "已流标",
            5 => "项目结束"
        )
    );
    
    public static $asset_search_data_dic = array(
            1 => "今天",
            2 => "最近一周",
            3 => "一个月",
            4 => "三个月",
            5 => "六个月"
    );
    
    public static $asset_search_status_dic = array(
            1 => "审核中",
            2 => "预约中",
            3 => "提前购买中",
            4 => "正式购买中",
            5 => "资产购入中",
            6 => "资产处置中",
            7 => "资产回购中",
            8 => "项目结束",
            9 => "已流标",
            10=>"草稿"
    );
    

    /**
     * ********BASE库 BEGIN********
     */
    /**
  * 订单编号分类
     *
     * @var unknown
     */
    public static $base_order_code_type = array(
        1 => "充值订单",
        2 => "提现订单",
        3 => "购买产品订单"
    );

    /**
     * ********BASE库 END********
     */
    
    /**
     * ********Bill BEGIN***********
     */
    public static $bill_type = array(
        1 => "充值",
        2 => "提现冻结",
        3 => "提现成功",
        4 => "提现失败",
        5 => "分红",
        6 => "购买资产",
        7 => '红包或活动'
    );

    /**
     * ********Bill END*************
     */
    
    /**
     * ********gender BEGIN***********
     */
    public static $gender_dic = array(
        1 => "男",
        2 => "女",
        3 => "保密"
    );

    /**
     * ********gender END*************
     */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $org_status_dic = array(
        1 => "审核中",
        2 => "审核失败",
        3 => "审核成功"
    );
/**
 * ********org_status END*************
 */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $asset_status_dic = array(
        2 => "审核成功",
        3 => "审核失败"
    );
    /**
     * ********org_status END*************
     */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $liability_dic = array(
       "liability_guarantee_type" => array(
           1 => "无担保",
           2 => "抵押",
           3 => "质押",
           4 => "第三方保障"
        ),
        "liability_is_justice" => array(
            1 => "否",
            2 => "是"
        ),
        "liability_legal_state" => array(
            1 => "未诉",
            2 => "已诉",
            3=> "执行"
        ),
        "liability_is_preserving" => array(
            1 => "否",
            2 => "是"
        ),
        "business_status"=>array(
            1=>"正常营业",
            2=>"停业",
            3=>"吊销",
            4=>"吊销(重组整顿)",
            5=>"吊销(清算破产)"
        ),
        "track_status"=>array(
            1=>"申请中",
            2=>"财务已确认",
            3=>"财务已驳回"
        ),
        "risk_guarantee_type"=>array(
            1=>"新手模式",
            2=>"进阶模式",
            3=>"高手模式"
        )
    );
    /**
     * ********org_status END*************
     */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $order_asset_dic = array(
        "product_type"=>array(
        1 => "新手模式",
        2 => "进阶模式",
        3 => "高级模式"
       ),
        "order_type"=>array(
        1 => "购买",
        2 => "流标"
       ),
        "order_status"=>array(
        0 => "待支付",
        1 => "购买成功",
        2 => "失败"
       ),
    );
    /**
     * ********org_status END*************
     */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $user_bill_dic = array(
        "type"=>array(
            1=>"充值成功",
            2=>"提现冻结",
            3=>"提现成功",
            4=>"提现失败",
            5=>"分红",
            6=>"购买资产",
            7=>"充值失败",
            8=>"流标退款",
            9=>"企业借款",
            10=>"企业还款成功",
            11=>"企业还款失败"
        )
    );
    /**
     * ********org_status END*************
     */
    
    /**
     * ********org_status BEGIN***********
     */
    public static $pay_back_dic = array(
        "status"=>array(
            1=>"还款中",
            2=>"已还款",
            3=>"还款失败"
        )
    );
    /**
     * ********org_status END*************
     */
}