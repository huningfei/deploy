<?php
/**
 * PHP生成二维码
 * @author yurong
 * 2018-02-28
 * UTF-8
 */
class XbLib_Phpqrcode{
    protected $url = 'https://upload.xiaobaijinfu.com';
    public function __construct(){
        include LIBRARY_DIR."/XbLib/src/phpqrcode.php";
    }




}
