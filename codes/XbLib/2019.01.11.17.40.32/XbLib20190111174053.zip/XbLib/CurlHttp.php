<?php

Class XbLib_CurlHttp{

    public static $timeout = 30;
    public static $is_proxy =  false;
    public static $user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0';
    public static $cookie_file = './tmp/curlhttp_cookie.txt';

    public  static function get($url) 
    { // 模拟获取内容函数
        $curl = curl_init (); // 启动一个CURL会话
        if (self::$is_proxy) {
            //以下代码设置代理服务器
            //代理服务器地址
            curl_setopt ( $curl, CURLOPT_PROXY, self::$proxy );
        }
        curl_setopt ( $curl, CURLOPT_URL, $url ); // 要访问的地址
        curl_setopt ( $curl, CURLOPT_SSL_VERIFYPEER, 0 ); // 对认证证书来源的检查
        curl_setopt ( $curl, CURLOPT_SSL_VERIFYHOST, 1 ); // 从证书中检查SSL加密算法是否存在

        if (!empty(self::$user_agent)){
            curl_setopt ( $curl, CURLOPT_USERAGENT, self::$user_agent ); // 模拟用户使用的浏览器
        }
        @curl_setopt ( $curl, CURLOPT_FOLLOWLOCATION, 1 ); // 使用自动跳转
        curl_setopt ( $curl, CURLOPT_AUTOREFERER, 1 ); // 自动设置Referer
        curl_setopt ( $curl, CURLOPT_HTTPGET, 1 ); // 发送一个常规的GET请求

        if (!empty(self::$cookie_file)){
            curl_setopt ( $curl, CURLOPT_COOKIEJAR, self::$cookie_file ); // 存放Cookie信息的文件名称
            curl_setopt ( $curl, CURLOPT_COOKIEFILE, self::$cookie_file ); // 读取上面所储存的Cookie信息
        }
        curl_setopt ( $curl, CURLOPT_TIMEOUT, self::$timeout ); // 设置超时限制防止死循环
        curl_setopt ( $curl, CURLOPT_HEADER, 0 ); // 显示返回的Header区域内容
        curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, 1 ); // 获取的信息以文件流的形式返回
        $ch_ret = curl_exec ( $curl ); // 执行操作

        if (curl_errno ( $curl )) {
            $ch_ret = null;
        }

        curl_close ( $curl ); // 关闭CURL会话
        return $ch_ret; // 返回数据
    }

    static public function post($url, $post_data, $ext_config = array())
    {
        /** 仅使用超时设置,负载由 $url 自行负责 */
        static $config;

        $config = count($ext_config) ? $ext_config : Config::$httpConfig;
        $ret = array(
            'error' => 500,     /** 参数不正确 */
            'data'  => array(),
        );

        $json_str = json_encode($post_data);
        if (! (strlen($url) && is_array($post_data) 
            && count($post_data) && strlen($json_str) > 8))
        {
            return $ret;
        }

        $seed = mt_rand(2, 8);
        $token = md5('hy0kle#' . substr($json_str, 0, $seed) . '@google.com|*_^');
        $fields = array(
            'input' => $json_str,
            'token' => $token,
            'seed'  => $seed,
        );

        $time = $config['talk'];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$fields);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, $time['connect_timeout_ms']);
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, $time['read_timeout_ms']);

        curl_setopt($ch, CURLOPT_URL, $url);
        
        $ch_ret = curl_exec($ch);
        if (0 != ($errno = curl_errno($ch)))
        {
            $ret['error'] = 501;
            curl_close($ch);
            return $ret;
        }
        
        curl_close($ch);

        $result = json_decode($ch_ret, true);
        if (! is_array($result) || count($result) <= 0)
        {
            $ret['error'] = 400;
            return $ret;
        }

        $ret = $result;
        return $ret;
    }

    /**
     * curl全局封装方法
     * @param unknown $url
     * @param number $limit
     * @param string $post
     * @param string $cookie
     * @param string $bysocket
     * @param string $ip
     * @param number $timeout
     * @param string $block
     * @param string $encodetype
     * @param string $allowcurl
     */
     public static function dfopen($url, $limit = 0, $post = '', $cookie = '', $bysocket = FALSE, $ip = '', $timeout = 15, $block = TRUE, $encodetype  = 'URLENCODE', $allowcurl = TRUE) {
        $return = '';
        $matches = parse_url($url);
        $scheme = $matches['scheme'];
        $host = $matches['host'];
        $path = $matches['path'] ? $matches['path'].(isset($matches['query']) && $matches['query'] ? '?'.$matches['query'] : '') : '/';
        $port = !empty($matches['port']) ? $matches['port'] : 80;
        if(function_exists('curl_init') && $allowcurl) {
            
            $ch = curl_init();
            $ip && curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: ".$host));
            curl_setopt($ch, CURLOPT_URL, $scheme.'://'.($ip ? $ip : $host).':'.$port.$path);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            if($post) {
                curl_setopt($ch, CURLOPT_POST, 1);
                if($encodetype == 'URLENCODE') {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                } else {
                    parse_str($post, $postarray);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $postarray);
                }
            }
            
            if($cookie) {
                curl_setopt($ch, CURLOPT_COOKIE, $cookie);
            }
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $data = curl_exec($ch);
            $status = curl_getinfo($ch);
            $errno = curl_errno($ch);
            curl_close($ch);
            if($errno || $status['http_code'] != 200) {
                $status['code'] = 503;
                return json_encode($status);
            }
            return !$limit ? $data : substr($data, 0, $limit);
        }
    
        if($post) {
            $out = "POST $path HTTP/1.0\r\n";
            $header = "Accept: */*\r\n";
            $header .= "Accept-Language: zh-cn\r\n";
            $boundary = $encodetype == 'URLENCODE' ? '' : '; boundary='.trim(substr(trim($post), 2, strpos(trim($post), "\n") - 2));
            $header .= $encodetype == 'URLENCODE' ? "Content-Type: application/x-www-form-urlencoded\r\n" : "Content-Type: multipart/form-data$boundary\r\n";
            $header .= "User-Agent: $_SERVER[HTTP_USER_AGENT]\r\n";
            $header .= "Host: $host:$port\r\n";
            $header .= 'Content-Length: '.strlen($post)."\r\n";
            $header .= "Connection: Close\r\n";
            $header .= "Cache-Control: no-cache\r\n";
            $header .= "Cookie: $cookie\r\n\r\n";
            $out .= $header.$post;
        } else {
            $out = "GET $path HTTP/1.0\r\n";
            $header = "Accept: */*\r\n";
            $header .= "Accept-Language: zh-cn\r\n";
            $header .= "User-Agent: $_SERVER[HTTP_USER_AGENT]\r\n";
            $header .= "Host: $host:$port\r\n";
            $header .= "Connection: Close\r\n";
            $header .= "Cookie: $cookie\r\n\r\n";
            $out .= $header;
        }
    
        $fpflag = 0;
        if(!$fp = @fsocketopen(($ip ? $ip : $host), $port, $errno, $errstr, $timeout)) {
            $context = array(
                    'http' => array(
                            'method' => $post ? 'POST' : 'GET',
                            'header' => $header,
                            'content' => $post,
                            'timeout' => $timeout,
                    ),
            );
            $context = stream_context_create($context);
            $fp = @fopen($scheme.'://'.($ip ? $ip : $host).':'.$port.$path, 'b', false, $context);
            $fpflag = 1;
        }
    
        if(!$fp) {
            return '';
        }
        stream_set_blocking($fp, $block);
        stream_set_timeout($fp, $timeout);
        @fwrite($fp, $out);
        $status = stream_get_meta_data($fp);
        if(!$status['timed_out']) {
            while (!feof($fp) && !$fpflag) {
                if(($header = @fgets($fp)) && ($header == "\r\n" ||  $header == "\n")) {
                    break;
                }
            }
    
            $stop = false;
            while(!feof($fp) && !$stop) {
                $data = fread($fp, ($limit == 0 || $limit > 8192 ? 8192 : $limit));
                $return .= $data;
                if($limit) {
                    $limit -= strlen($data);
                    $stop = $limit <= 0;
                }
            }
        }
        @fclose($fp);
        return $return;
    }

    static public function postNew($url, $post_data, $header = array(),$is_xml=false)
    {
        $ret = array(
            'error' => 500,     /** 参数不正确 */
            'data'  => array(),
        );
        if($is_xml){
            $post_data = http_build_query($post_data);
        }

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $post_data,
            CURLOPT_HTTPHEADER => $header,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_SSL_VERIFYHOST => 0,
        ));
        $ch_ret = curl_exec($ch);
        if (0 != ($errno = curl_errno($ch)))
        {
            XbFunc_Log::write('curlError', '错误编号：'.curl_errno($ch), '具体错误：'.curl_error($ch));
            $ret['error'] = 501;
            curl_close($ch);
            return $ret;
        }
        XbFunc_Log::write('curlResult', '返回数据：'.json_encode($ch_ret));
        curl_close($ch);
        if($is_xml){
            $result = self::xmlToArray($ch_ret);
        }else{
            $result = json_decode($ch_ret, true);
        }
        if (! is_array($result) || count($result) <= 0)
        {
            $ret['error'] = 400;
            return $ret;
        }

        $ret = $result;
        return $ret;
    }

    static public function getNew($url,$header)
    {
        $ret = array(
            'error' => 500,     /** 参数不正确 */
            'data'  => array(),
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::$timeout);

        curl_setopt($ch, CURLOPT_URL, $url);

        $ch_ret = curl_exec($ch);
        if (0 != ($errno = curl_errno($ch)))
        {
            $ret['error'] = 501;
            curl_close($ch);
            return $ret;
        }

        curl_close($ch);
        $result = json_decode($ch_ret, true);
        if (! is_array($result) || count($result) <= 0)
        {
            $ret['error'] = 400;
            return $ret;
        }

        $ret = $result;
        return $ret;
    }
    //将XML转为array
    static public function xmlToArray($xml)
    {
        $xml = str_replace(array('\r', '\n', '\t', '\/'), array('', '', '', '/'), $xml);
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $values = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $values;
    }
}

