<?php

/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2015年12月25日
 * UTF-8
 */
class XbLib_SinaPay_Order
{

	private static $obj = null;

	/**
	 *
	 * @var XbLib_SinaPay_Config
	 */
	private $configObj = null;

	private $weiboTools = null;

	/**
	 * 封闭构造
	 *
	 * @param unknown $configObj        	
	 */
	private function __construct($configObj)
	{
		$this->configObj = $configObj;
		$this->weiboTools = new XbLib_SinaPay_Lib_Weibo($configObj);
	}

	/**
	 * 单例
	 *
	 * @param unknown $configObj        	
	 */
	public static function getInstance($configObj)
	{
		if (empty($configObj) || ! ($configObj instanceof XbLib_SinaPay_Config)) {
			return false;
		}
		if (is_null(self::$obj)) {
			self::$obj = new XbLib_SinaPay_Order($configObj);
		}
		return self::$obj;
	}

	/**
	 * 账户充值
	 * 
	 * @param unknown $uid        	
	 * @param unknown $out_trade_no        	
	 * @param unknown $summary        	
	 * @param unknown $amount    
	 * @param string $online_bank_card_attribute   C、对私 B、对公 	
	 * @param float $user_fee 
	 * @param string $account_type   
	 * @param string $pay_method        	
	 *       	
	 */
	public function deposit($uid, $out_trade_no, $summary, $amount, $online_bank_card_attribute="C", $user_fee = 0.00, $account_type = "SAVING_POT", $pay_method = "online_bank")
	{
		$uid = intval($uid);
		$out_trade_no = trim($out_trade_no);
		$summary = trim($summary);
		$amount = floatval($amount);
		$user_fee = floatval($user_fee);
		if ($uid < 1) {
			return false;
		}
		if (empty($out_trade_no) || empty($summary) || empty($amount)) {
			return false;
		}
		
		if (! in_array($pay_method, array(
			"online_bank"
		), true)) {
			return false;
		}
		
		if (! in_array($account_type, array(
			'BASIC',
			"ENSURE",
			'SAVING_POT'
		))) {
			return false;
		}
		
		$data = array();
		$data['identity_id'] = $uid;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['out_trade_no'] = $out_trade_no;
		$data['amount'] = $amount;
		$data['pay_method'] = $pay_method . '^' . $amount . '^SINAPAY,DEBIT,'.$online_bank_card_attribute;
		$data['account_type'] = $account_type;
		$data['user_fee'] = $user_fee;
		$data['return_url'] = $this->configObj->getDepositReturnUrl();
		$data['notify_url'] = $this->configObj->getDepositNotifyUrl();
		
		$res = $this->processData("create_hosting_deposit", $data, false,$uid);
		return $res;
	}

	/**
	 * 提现
	 * @param unknown $uid
	 * @param unknown $out_trade_no
	 * @param unknown $amount
	 * @param string $account_type
	 * @param real $user_fee
	 */
	public function withdraw($uid, $out_trade_no, $amount, $user_fee = 0.00, $account_type = "SAVING_POT")
	{
		$service = "create_hosting_withdraw";
		$data = array();
		$data['identity_id'] = $uid;
		// 用户类别UID
		$data['identity_type'] = "UID";
		$data['out_trade_no'] = $out_trade_no;
		$data['amount'] = $amount;
		$data['account_type'] = $account_type;
		$data['user_fee'] = $user_fee;
		$data['withdraw_mode'] = "CASHDESK";
		$data['return_url'] = $this->configObj->getWithdrawReturnUrl();
		$data['notify_url'] = $this->configObj->getWithdrawNotifyUrl();
		$res = $this->processData($service, $data, false,$uid);
		return $res;
	}
	
	/**
	 * 创建标的信息
	 * @param unknown $goods_id 标ID
	 * @param unknown $goods_name 标名称
	 * @param unknown $total_amount 总金额
	 * @param unknown $begin_date 开始时间 yyyyMMddHHmmss
	 * @param unknown $term 还款期限 yyyyMMddHHmmss
	 * @param unknown $url url链接
	 * @param unknown $guarantee_method 担保方式
	 * @param unknown $debtor_uid 借款人id
	 * @param real $annual_yield 年化利率
	 * @param string $repay_method 还款方式
	 */
	public function createP2pHostingBorrowingTarget($goods_id,$goods_name,$total_amount,$begin_date,$term,$url,$guarantee_method,$debtor_uid,$annual_yield=0.01,$repay_method="MONTHLY_PAYMENT"){
		$goods_id = intval($goods_id);
		$goods_name = trim($goods_name);
		$total_amount = floatval($total_amount);
		$url = trim($url);
		$debtor_uid = intval($debtor_uid);
		$annual_yield = floatval($annual_yield);
		if(!in_array($repay_method, array("DEBT_MATURITY","MONTHLY_PAYMENT"))){
			return false;
		}
		$service = "create_p2p_hosting_borrowing_target";
		$data = array();
		$data['goods_id'] = $goods_id;
		$data['goods_name'] = $goods_name;
		$data['total_amount'] = $total_amount;
		$data['begin_date'] = $begin_date;
		$data['term'] = $term;
		$data['url'] = $url;
		$data['guarantee_method'] = $guarantee_method;
		$data['debtor_list'] = $debtor_uid . "^UID^{$total_amount}";
		$data['annual_yield'] = $annual_yield;
		$data['repay_method'] =  $repay_method;
		
		$res = $this->processData($service, $data, true, $debtor_uid);
		if($res['response_code'] == "APPLY_SUCCESS"){
			return true;
		}
		return false;
		
	}
	
	/**
	 * 创建托管待收交易
	 * 超时交易时间30m 可以重复支付
	 * @param unknown $out_trade_no 交易订单号
	 * @param unknown $out_trade_code 交易码 1001待收投资基金 1002待收还款金
	 * @param unknown $summary 简介
	 * @param unknown $goods_id 标id
	 * @param unknown $uid uid
	 * @param unknown $amount 金额
	 * @param string $online_bank_card_attribute C对私 B对公
	 * @param string $online_bank_bankid
	 * @param string $online_bank_card_type
	 * @param number $type  0 资产购买 1 企业还款
	 */
	public function createHostingCollectTrade($out_trade_no,$out_trade_code,$summary,$goods_id,$uid,$amount,$online_bank_card_attribute="C",$type=0,$online_bank_bankid="SINAPAY",$online_bank_card_type="DEBIT"){
		$goods_id = intval($goods_id);
		$uid = intval($uid);
		$amount = floatval($amount);
		$out_trade_no = trim($out_trade_no);
		if( !in_array($out_trade_code, array("1001","1002"))){
			return false;
		}
		if(empty($out_trade_no) || empty($summary) || empty($goods_id) || empty($uid) || empty($amount)){
			return false;
		}
		$service = "create_hosting_collect_trade";
		$data = array();
		$data['notify_url'] = $this->configObj->getHostingCollectTradeNotifyUrl();
		$data['return_url'] = $this->configObj->getHostingCollectTradeReturnUrl();
		if($type==1){
		    $data['notify_url'] = $this->configObj->getHostingCollectTradeNotifyPayBackUrl();
		}
		$data['can_repay_on_failed'] = "Y";
		$data['pay_method'] = "online_bank^{$amount}^{$online_bank_bankid},{$online_bank_card_type},{$online_bank_card_attribute}";
		$data['payer_identity_type'] = "UID";
		$data['out_trade_no'] = $out_trade_no;
		$data['out_trade_code'] = $out_trade_code;
		$data['summary'] = $summary;
		$data['trade_close_time'] = "30m";
		$data['goods_id'] = $goods_id;
		$data['payer_id'] = $uid;
		$res = $this->processData($service, $data, false, $uid);
		return $res;
	}
	
	/**
	 * 代付本金收益金
	 * @param unknown $out_trade_no
	 * @param unknown $uid
	 * @param unknown $amount
	 * @param unknown $summary
	 * @param number $goods_id
	 * @param number $type  0 付款给企业 1 分红
	 */
	public function createSingleHostingPayTrade($out_trade_no,$uid,$amount,$summary,$type=0,$goods_id=0,$account_type="SAVING_POT"){
		$out_trade_no = trim($out_trade_no);
		$uid = intval($uid);
		$amount = floatval($amount);
		$summary = trim($summary);
		if(empty($out_trade_no) || empty($uid) || empty($amount) || empty($summary)){
			return false;
		}
		if (! in_array($account_type, array(
			'BASIC',
			"ENSURE",
			'SAVING_POT'
		))) {
			return false;
		}
		
		$service = "create_single_hosting_pay_trade";
		$data = array();
		$data['payee_identity_type'] = "UID";
		$data['account_type'] = $account_type;
		$data['out_trade_no'] = $out_trade_no;
		$data['out_trade_code'] = "2001"; //2001 代付借款 2002 代付（本金/收益）金
		if($type==1){
		    $data['out_trade_code'] = "2002";
		}
		$data['payee_identity_id'] = $uid;
		$data['amount'] = $amount;
		$data['summary'] = $summary;
		if(!empty($goods_id)){
			$data['goods_id'] = $goods_id;
		}
		$data['notify_url'] = $this->configObj->getSingleHostingPayTrade_notify_url();
		if($type==1){
		    $data['notify_url'] = $this->configObj->getSingleHostingPayTrade_notify_bonusurl();
		}
		$res = $this->processData($service, $data);
		if($res['response_code'] == "APPLY_SUCCESS" && $res['trade_status'] == "PAY_FINISHED"){
			return true;
		}
		return false;
	}
	
	/**
	 * 托管退款
	 * @param unknown $out_trade_no
	 * @param unknown $orig_outer_trade_no
	 * @param unknown $refund_amount
	 * @param unknown $summary
	 */
	public function createHostingRefund($out_trade_no,$orig_outer_trade_no,$refund_amount,$summary){
	    $out_trade_no = trim($out_trade_no);
	    $orig_outer_trade_no = trim($orig_outer_trade_no);
	    $refund_amount = floatval($refund_amount);
	    $summary = trim($summary);
	    if(empty($out_trade_no) || empty($orig_outer_trade_no) || empty($refund_amount) || empty($summary)){
	        return false;
	    }

	    $service = "create_hosting_refund";
	    $data = array();
	    $data['out_trade_no'] = $out_trade_no;
	    $data['orig_outer_trade_no'] = $orig_outer_trade_no;
	    $data['refund_amount'] = $refund_amount;
	    $data['summary'] = $summary;
	    $data['notify_url'] = $this->configObj->getHostingRefund_notify_url();
	    $res = $this->processData($service, $data);
	    if($res['refund_status'] == "SUCCESS"){
	        return true;
	    }
	    return false;
	}
	
	
	/**
	 * 校验签名正确性
	 * @param unknown $data
	 */
	public function checkSignMsg($data,$sign_type="MD5"){
		return $this->weiboTools->checkSignMsg($data,$sign_type);
	}

	/**
	 * 提交服务接口
	 *
	 * @param unknown $service        	
	 * @param unknown $mergeData        	
	 * @return boolean | array
	 */
	private function processData($service, $mergeData, $jsond=true, $uid=0)
	{
		$now = time();
		$data = array();
		// 接口名称
		$data['service'] = $service;
		// 接口版本
		$data['version'] = $this->configObj->getVersion();
		// 请求时间
		$data['request_time'] = date("YmdHis", $now);
		// 商户id
		$data['partner_id'] = $this->configObj->getPartnerId();
		// 字符集
		$data['_input_charset'] = $this->configObj->getCharset();
		$data = array_merge($data, $mergeData);
		
		// 签名类型
		$data['sign_type'] = $this->configObj->getSignType();
		// 签名
		$data['sign'] = $this->weiboTools->getSignMsg($data, $this->configObj->getSignType());

		// 调用createcurl_data创建模拟表单需要的数据
		$curl_data = $this->weiboTools->createcurl_data($data);
		$response = $this->weiboTools->curlPost($this->configObj->getOpayurl(), $curl_data);
		$response = urldecode($response);
		if(!$jsond){
			return $response;
		}
		$result = json_decode($response, true);
		if(!is_array($result)){
			return false;
		}
		$res = $this->weiboTools->checkSignMsg($result, $this->configObj->getSignType());
		if (! $res) {
			XbFunc_Log::write("SinaPay", "CheckResponseSignError", json_encode($response));
			return false;
		}
		if ($result['response_code'] != "APPLY_SUCCESS") {
			if (isset($data['identity_id'])) {
				$uid = $data['identity_id'];
			}
			XbFunc_Log::write("SinaPayOrder_{$service}", "{$result['response_code']}[{$this->configObj->getResponseMsg($result['response_code'])}]UID[$uid]", "request->" . json_encode($data) . "||response->" . json_encode($result));
		}
		
		return $result;
	}
}