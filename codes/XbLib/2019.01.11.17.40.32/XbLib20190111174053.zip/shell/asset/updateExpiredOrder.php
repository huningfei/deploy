<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2016年1月17日
 * UTF-8
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');

$result = XbModule_Asset_OrderAsset::getInstance()->updateExpiredOrder(1800);
XbFunc_Log::write("update_expired_order", "更新了{$result}个过期订单");