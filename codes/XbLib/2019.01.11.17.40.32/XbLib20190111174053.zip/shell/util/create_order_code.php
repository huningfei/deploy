<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2016年1月6日
 * UTF-8
 */
$path = realpath(dirname(__FILE__));
define("SHELL_VARIABLE", 'rls');

include $path.'/../../bootstrap.php';

$model = new XbModel_Base_Order();
$res = $model->createOrderId(1000000);
var_dump($res);