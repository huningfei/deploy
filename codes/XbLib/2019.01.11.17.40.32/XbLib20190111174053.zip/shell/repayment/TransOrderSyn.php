<?php
//定时计划脚本
//查本期支付状态,修改数据状态
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
$page         = 1;
$num          = 10;
$mch_id       = 2;
$statusArr = array('0000', '0100');

$startTime = time() - 7500;
$endTime   = time() - 300;

//do{
//    $limit = ($page - 1)*$num;
//    $commonTransOrder = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByStatusAndType(0, 1, $limit, $num, $startTime, $endTime);
//    if($commonTransOrder){
//        foreach($commonTransOrder as $k=>$v){
//            $userChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserChannelInfo($v['uid'], $v['channel_id']);
//            if(!$userChannel){
//                continue;
//            }
//            $newOrderId  = XbModule_Account_OrderCode::getInstance()->getOrderCode();
//            $queryData = array(
//                'new_order_id' => $newOrderId,
//                'order_id'     => $v['order_id'],
//                'channel_code' => $userChannel['channel_code'],
//                'channel_key'  => $userChannel['channel_key'],
//            );
//            $checkOrder = XbLib_Repayment_Channel::getInstance()->checkOrder($v['channel_id'], $queryData);
//            if($checkOrder && isset($checkOrder['res']['RESP_CODE']) && !in_array($checkOrder['res']['RESP_CODE'], $statusArr)){
//                //todo 订单失败处理
//                $res = XbModule_Repayment_Order::getInstance($mch_id)->updateStatus($v['id'], 2, $checkOrder['res']['RESP_DESC']);
//                if(!$res){
//                    XbFunc_Log::write('repaymentOrderStatus','修改处理失败订单状态失败：'.json_encode($checkOrder));
//                }else{
//                    //微信推送
////                    $date   = $v['create_time'] ? $v['create_time'] : time();
////                    $wxdata = array(
////                        'uid'         => $v['uid'],
////                        'orderamount' => number_format($v['amount'], 2, '.', '').'元（实际到账'.$v['custom_amount'].'元）',
////                        'date'        => date('Y-m-d H:i:s',$date),
////                        'ordernumber' => $v['order_id']
////                    );
////                    XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(6, $wxdata);
//
//                    //优化推送消息
//                    $res = XbLib_PushMsg::getInstance()->commonRepaymentFail($v['uid'],$v['order_id']);
//                }
//            }
//        }
//    }else{
//        break;
//    }
//    $page ++;
//}while(true);

$page = 1;
do{
    $limit = ($page - 1)*$num;
    $wiseTransOrder = XbModule_Repayment_Order::getInstance($mch_id)->getPlanOrderByStatusAndType(1, 1, $limit, $num);

    if($wiseTransOrder){
        foreach($wiseTransOrder as $k=>$v){
            $userChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserChannelInfo($v['uid'], $v['channel_id']);
            if(!$userChannel){
                continue;
            }
            $newOrderId = XbModule_Account_OrderCode::getInstance()->getOrderCode();
            $queryData = array(
                'order_id'     => $v['order_id'],
                'type'         => 1,
//                'new_order_id' => $newOrderId,
//                'channel_code' => $userChannel['channel_code'],
//                'channel_key'  => $userChannel['channel_key']
            );
            $checkOrder = XbLib_Repayment_Channel::getInstance()->checkOrder($v['channel_id'], $queryData);
            if($checkOrder && isset($checkOrder['res']['RESP_CODE']) && !in_array($checkOrder['res']['RESP_CODE'], $statusArr)){
                //todo 订单失败处理
                $res = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($v['id'], 2, $v['oid'], false, '订单刷卡失败，期数：'.$v['issue']);
                if(!$res){
                    XbFunc_Log::write('execRepaymentPlanError1','修改处理失败订单状态失败：'.json_encode($checkOrder));
                }else{
                    $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($v['oid']);
                    if($orderInfo){
//                        //极光+站内推送
//                        XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'wiseRepaymentStop');
//                        //微信推送
//                        $date   = $v['plan_time'] ? $v['plan_time'] : time();
//                        $fee    = XbLib_Repayment_ChannelFunc::getWithdrawAmount($v['amount'], $orderInfo['rate'], $orderInfo['single_fee']);
//                        $amount = bcsub($v['amount'], $fee, 2);
//                        $wxdata = array(
//                            'uid'         => $orderInfo['uid'],
//                            'orderamount' => number_format($v['amount'], 2, '.', '').'元（实际到账'.number_format($amount, 2, '.', '').'元）',
//                            'date'        => date('Y-m-d H:i:s',$date),
//                            'ordernumber' => $orderInfo['order_id']
//                        );
//                        XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(9, $wxdata);

                        //优化推送消息
                        $res = XbLib_PushMsg::getInstance()->wiseRepaymentStop($v['uid'],array('order_plan_id'=>$v['id']));
                    }
                }
            }
        }
    }else{
        break;
    }
    $page ++;
}while(true);

echo 'TransOrderSyn';