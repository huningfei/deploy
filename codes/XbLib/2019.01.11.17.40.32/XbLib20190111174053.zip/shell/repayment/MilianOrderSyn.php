<?php
//定时拉取打款状态脚本脚本
//查上一期代付状态,发起支付
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
$page         = 1;
$num          = 10;
$mch_id       = 2;
$count        = 0;
$channel_id   = 5;
$channel_name = '雅酷酷宝';
$statusArr    = array(0, 4);
$planStatus   = array(1, 2);
$milianStatus = array('0000', '0100');
do{
    $limit = ($page - 1)*$num;
    $orderPlan = XbModule_Repayment_Order::getInstance($mch_id)->scriptOrderPlan($limit, $num);
    if(!$orderPlan){
        break;
    }
    foreach($orderPlan as $k=>$v){
        if($v['real_status'] != 0){
            continue;
        }
        //获取此计划订单是否正在执行
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($v['oid']);
        $issue = $v['issue'] - 1;
        if($issue < 1){
            continue;
        }
        $withdrawOrder = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 2);
        if(!$withdrawOrder){
            /*if($orderInfo && $orderInfo['status'] == 4){
                //todo 执行失败
                $resSuccess = XbModule_Repayment_Order::getInstance($mch_id)->updateStatus($v['oid'], 6);
                XbFunc_Log::write('execRepaymentPlanError1', '没有查询到订单打款信息，订单id:'.$v['oid'].'，打款期数：'.$issue);
            }*/
            continue;
        }

        //获取用户channel_id
        $userChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserChannelInfo($v['uid'], $channel_id);
        if(!$userChannel){
            XbFunc_Log::write('execRepaymentPlanError1', '没有查询到用户通道信息，用户id:'.$v['uid'].'，订单：'.$v['oid'], '拉取期数：'.$issue);
            continue;
        }

        if(!in_array($withdrawOrder['status'], $planStatus)){
            //查询订单状态
            $newOrderId = XbModule_Account_OrderCode::getInstance()->getOrderCode();
            $queryData = array(
                'order_id'     => $withdrawOrder['order_id'],
                'type'         => 2,
//                'new_order_id' => $newOrderId,
//                'channel_code' => $userChannel['channel_code'],
//                'channel_key'  => $userChannel['channel_key'],
            );
            $res = XbLib_Repayment_Channel::getInstance()->checkOrder($channel_id, $queryData);
            if(!$res){
                //查询订单错误时处理
                XbFunc_Log::write('execRepaymentPlanError1', '在通道中查询订单错误：'.json_encode($queryData));
                continue;
            }
            if($res['res']['RESP_CODE'] == '0000' ){
                //订单处理成功
                $resSuccess = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($withdrawOrder['id'], 1);
                if(!$resSuccess){
                    XbFunc_Log::write('execRepaymentPlanError1', '提现订单返回成功状态，修改订单状态失败，订单：'.$v['oid'], '订单号：'.$v['order_id'],'返回：'.json_encode($res));
                    continue;
                }
                //还款成功以后推送消息
//                try{
//                    $replaceAmount = number_format($withdrawOrder['amount'], 2, '.', '');
//                    $cardNumber    = substr($orderInfo['repaycard'], -4, 4);
//                    $replace = array(
//                        'amount'     => $replaceAmount,
//                        'cardNumber' => $cardNumber
//                    );
//                    XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'wiseSingleRepayment', $replace);
//                    //微信推送
//                    $date = $v['plan_time'] ? $v['plan_time'] : time();
//                    $payOrder = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 1);
//                    $wxdata = array(
//                        'uid'         => $orderInfo['uid'],
//                        'orderamount' => number_format($payOrder['amount'], 2, '.', '').'元（实际到账'.$replaceAmount.'元）',
//                        'date'        => date('Y-m-d H:i:s',$date),
//                        'ordernumber' => $orderInfo['order_id']
//                    );
//                    XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(8, $wxdata);
//                }catch (Exception $e){
//                    XbFunc_Log::write('JPushappxiaoxi','推送消息失败：单笔提现。type:wiseSingleRepayment', $v['uid']);
//                }
                //优化推送消息
                $res = XbLib_PushMsg::getInstance()->wiseSingleRepayment($uid,array('order_plan_id'=>$v['id']));

            }elseif($res['res']['RESP_CODE'] == '0100'){
                //订单处理中，下次再拉取订单状态
                continue;
            }else{
                //打款订单处理失败
                $resFail = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($withdrawOrder['id'], 2, $v['oid']);
                if($resFail){
//                    //极光+站内推送
//                    XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'wiseRepaymentStop');
//                    //微信推送
//                    $payOrder = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $issue, 1);
//                    $date = $v['plan_time'] ? $v['plan_time'] : time();
//                    $amount = number_format($withdrawOrder['amount'], 2, '.', '');
//                    $wxdata = array(
//                        'uid'         => $orderInfo['uid'],
//                        'orderamount' => number_format($payOrder['amount'], 2, '.', '').'元（实际到账'.$amount.'元）',
//                        'date'        => date('Y-m-d H:i:s',$date),
//                        'ordernumber' => $orderInfo['order_id']
//                    );
//                    XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(9, $wxdata);

                    //优化推送消息
                    $res = XbLib_PushMsg::getInstance()->wiseRepaymentStop($v['uid'],array('order_plan_id'=>$v['id']));
                }

                continue;
            }
        }elseif($withdrawOrder['status'] == 2){
            //如果订单打款失败，且订单时执行状态中，将订单改为失败
            if($orderInfo && $orderInfo['status'] == 4){
                $resSuccess = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($withdrawOrder['id'], 2, $v['oid']);
                XbFunc_Log::write('execRepaymentPlanError1', '查询打款订单时失败状态，订单id:'.$v['oid'].'，打款期数：'.$issue);
            }
            continue;
        }

        if($orderInfo['status'] != 4){
            continue;
        }

        $res = XbModule_Repayment_Order::getInstance($mch_id)->orderPlanTrans($v, $orderInfo, $channel_id, $channel_name);
        if(!$res){
            XbFunc_Log::write('execRepaymentPlanError1', '刷卡失败，订单：'.$v['oid'], '订单号：'.$v['order_id']);
        }
    }
    $page ++;
}while(true);

echo 'MilianOrderSyn';