<?php
//定时拉取打款状态脚本脚本
//查最后一期代付状态,修改数据状态
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
$page         = 1;
$num          = 10;
$mch_id       = 2;
$count        = 0;
$channel_id   = 5;
$channel_name = '雅酷酷宝';
$planStatus   = array(1, 2);
$milianStatus = array('0000', '0100');
do{
    $limit = ($page - 1)*$num;
    $orderPlan = XbModule_Repayment_Order::getInstance($mch_id)->scriptOrderPlan($limit, $num);
    if(!$orderPlan){
        break;
    }
    foreach($orderPlan as $k=>$v){
        //获取此计划订单是否正在执行
        $orderInfo = XbModule_Repayment_Order::getInstance($mch_id)->getOrderById($v['oid']);
        if($v['issue'] != $orderInfo['plan_time']){
            continue;
        }
        $withdrawOrder = XbModule_Repayment_Order::getInstance($mch_id)->getOrderByIssue($v['oid'], $v['issue'], 2);
        if(!$withdrawOrder){
            continue;
        }
        if(in_array($withdrawOrder['status'], $planStatus)){
            continue;
        }

        //获取用户channel_id
        $userChannel = XbModule_Repayment_UsersChannel::getInstance()->getUserChannelInfo($v['uid'], $channel_id);
        if(!$userChannel){
            XbFunc_Log::write('execRepaymentPlanError1', '没有查询到用户通道信息，用户id:'.$v['uid'].'，订单：'.$v['oid'], '拉取期数：'.$issue);
            continue;
        }

        //查询订单状态
        $newOrderId = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $queryData = array(
            'order_id'     => $withdrawOrder['order_id'],
            'type'         => 2,
//            'new_order_id' => $newOrderId,
//            'channel_code' => $userChannel['channel_code'],
//            'channel_key'  => $userChannel['channel_key'],
        );
        $res = XbLib_Repayment_Channel::getInstance()->checkOrder($channel_id, $queryData);
        if(!$res){
            //查询订单错误时处理
            XbFunc_Log::write('execRepaymentPlanError1', '在通道中查询订单错误：'.json_encode($queryData));
            continue;
        }
        if($res['res']['RESP_CODE'] == '0000' ){
            //todo 订单成功
            $resSuccess = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($withdrawOrder['id'], 1, $v['oid'], true);
            if(!$resSuccess){
                XbFunc_Log::write('execRepaymentPlanError1', '提现订单返回成功状态，修改订单状态失败，订单：'.$v['oid'], '订单号：'.$v['order_id'],'返回：'.json_encode($res));
                continue;
            }
            //支付成功修改分润信息(最后一期)
            $res_profit = XbModule_Repayment_Order::getInstance($mch_id)->synOrderProfit($v['id'],$v['uid'],$v['amount'],$v['order_id'],$orderInfo['order_id'],1);

            //还款成功以后推送消息
//            try{
//                $replaceAmount = number_format($withdrawOrder['amount'], 2, '.', '');
//                $cardNumber    = substr($orderInfo['repaycard'], -4, 4);
//                $replace = array(
//                    'amount'     => $replaceAmount,
//                    'cardNumber' => $cardNumber
//                );
//                //极光推送--完成一期还款，以及智能计划完成
//                XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'wiseSingleRepayment', $replace);
//                XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'wiseRepaymentSuccess', $replace);
//                //微信消息推送--完成一期还款，以及智能计划完成
//                $date = $v['plan_time'] ? $v['plan_time'] : time();
//                $wxdata = array(
//                    'uid'         => $orderInfo['uid'],
//                    'orderamount' => number_format($v['amount'], 2, '.', '').'元（实际到账'.number_format($withdrawOrder['amount'], 2, '.', '').'元）',
//                    'date'        => date('Y-m-d H:i:s', $date),
//                    'ordernumber' => $orderInfo['order_id']
//                );
//                XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(8, $wxdata);
//                $date   = $orderInfo['create_time'] ? $v['create_time'] : time();
//                $amount = bcadd($orderInfo['amount'], $orderInfo['fee'], 2);
//                $wxdata = array(
//                    'uid'         => $orderInfo['uid'],
//                    'orderamount' => number_format($amount, 2, '.', '').'元（实际到账'.number_format($orderInfo['amount'], 2, '.', '').'元）',
//                    'date'        => date('Y-m-d H:i:s', $date),
//                    'ordernumber' => $orderInfo['order_id']
//                );
//                XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(10, $wxdata);
//            }catch (Exception $e){
//                XbFunc_Log::write('JPushappxiaoxi','推送消息失败：单笔提现+完成计划。type:wiseSingleRepayment,wiseRepaymentSuccess', $v['uid']);
//            }
            //优化推送消息
            $res = XbLib_PushMsg::getInstance()->wiseSingleRepayment($orderInfo['uid'],array('order_plan_id'=>$v['id']));
            $res = XbLib_PushMsg::getInstance()->wiseRepaymentSuccess($orderInfo['uid'],array('order_plan_id'=>$v['id']));
        }elseif($res['res']['RESP_CODE'] == '0100'){
            //todo 订单处理中
            continue;
        }else{
            //todo 订单失败
            $resSuccess = XbModule_Repayment_Order::getInstance($mch_id)->updateWithdrawOrderStatus($withdrawOrder['id'], 2, $v['oid']);
            continue;
        }
    }
    $page ++;
}while(true);

echo 'MilianWithdrawSyn';