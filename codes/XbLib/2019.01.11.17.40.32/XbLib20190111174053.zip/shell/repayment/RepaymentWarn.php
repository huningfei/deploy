<?php
//还款提醒脚本
date_default_timezone_set('Asia/Shanghai');
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$page = 1;
$num  = 10;
$date = date('d');
do{
    $limit = ($page - 1)*$num;
    $billCreditCard = XbModule_Account_CreditCard::getInstance()->getAllRepaymentWarn($date, 1, $limit, $num);
    if($billCreditCard){
        foreach($billCreditCard as $k=>$v){
//            try{
//                //极光站内推送
//                $replace = array(
//                    'cardNumber' => substr($v['cardNumber'], -4, 4),
//                    'cardBank'   => $v['bank']
//                );
//                XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'repaymentBillDate', $replace);
//                //微信推送
//                $replace['billDate'] = XbLib_Repayment_ChannelFunc::getCreditCardDate($v['billDate'], 1);
//                $replace['payDate']  = XbLib_Repayment_ChannelFunc::getCreditCardDate($v['payDate'], 2);
//                $replace['uid']      = $v['uid'];
//                XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(11, $replace);
//            }catch (Exception $e){
//                XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：账单日提醒。type:repaymentBillDate', $v['uid']);
//            }
            //优化推送消息
            $res = XbLib_PushMsg::getInstance()->repaymentBillDate($v['uid'],array('card_id'=>$v['id']));
        }
    }

    $payCreditCard = XbModule_Account_CreditCard::getInstance()->getAllRepaymentWarn($date, 2, $limit, $num);
    if($payCreditCard){
        foreach($payCreditCard as $k=>$v){
//            try{
//                //极光站内推送
//                $replace = array(
//                    'cardNumber' => substr($v['cardNumber'], -4, 4),
//                    'cardBank'   => $v['bank']
//                );
//                XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], 0, 'repaymentPayDate', $replace);
//                //微信推送
//                $replace['billDate'] = XbLib_Repayment_ChannelFunc::getCreditCardDate($v['billDate'], 1);
//                $replace['payDate']  = XbLib_Repayment_ChannelFunc::getCreditCardDate($v['payDate'], 2);
//                $replace['uid']      = $v['uid'];
//                XbLib_WechatTools_SendMsg::getInstance()->publicWxTemplateMsgSendFunc(12, $replace);
//            }catch (Exception $e){
//                XbFunc_Log::write('JPushappxiaoxi', '推送消息失败：还款日提醒。type:repaymentPayDate', $v['uid']);
//            }
            //优化推送消息
            $res = XbLib_PushMsg::getInstance()->repaymentPayDate($v['uid'],array('card_id'=>$v['id']));
        }
    }
    if(!$billCreditCard && !$payCreditCard){
        break;
    }
    $page ++;
}while(true);

echo 'RepaymentWarn';