<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/3
 * Time: 10:35
 */
$path = realpath(dirname(__FILE__));
define("SHELL_VARIABLE", 'rls');

include $path.'/../../bootstrap.php';
//获取所有的商户

$start = strtotime(date('Y-m-d',time()-3600*24));
$end = strtotime(date('Y-m-d',time()));
$arr = XbModule_Merchant_Merchant::getInstance()->index();
//获取商户收益
foreach ($arr as $k=>$v){
    $money = 0;
    //获取商户订单
    $order = XbModule_Account_Order::getInstance($v['id'])->merchantGetOrder($start,$end);
    foreach ($order as $key=>$val){
                //判断分润是否更新
                if($val['is_profit'] == 0){
                    XbFunc_Log::write("is_profit","分润订单没更新","商户".$v['id']."订单".$val['id']);continue;
                }elseif ($val['is_profit'] == 1){
                    if (bccomp($val['profit_rate'],$v['rate'],5) !=1){
                        XbFunc_Log::write("profit_rate","最终利率小于商户利率","商户".$v['id']."订单".$val['id']);continue;
                    }else{
                        $profit_money = round(bcmul(bcsub($val['profit_rate'],$v['rate'],5),$val['amount'],4),2);
                        XbModule_Account_Order::getInstance($v['id'])->insertMoney($val['id'],$profit_money);
                        $money += $profit_money;
                    }
                }elseif ($val['is_profit'] == 2){
                    if (bccomp($val['rate'],$v['rate'],5) !=1){
                        XbFunc_Log::write("rate","刷卡利率小于商户利率","商户".$v['id']."订单".$val['id']);continue;
                    }else{
                        $profit_money =round(bcmul(bcsub($val['rate'],$v['rate'],5),$val['amount'],4),2);
                        XbModule_Account_Order::getInstance($v['id'])->insertMoney($val['id'],$profit_money);
                        $money += $profit_money;
                    }
                }
            }
        //把每日收益插入数据库
        $profit = XbModule_Merchant_Merchant::getInstance()->insertProfit($v['id'],$money);
        if($profit !=1 ){
            XbFunc_Log::write("profit", $v['id'],$money);
        }
        //计算交易分润总收益
       $transactio = XbModule_Merchant_Merchant::getInstance()->updateTransactio($v['id'],$money);
        if($transactio !=1 ){
            XbFunc_Log::write("transactio", $v['id'],$money);
        }
}
