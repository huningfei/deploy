<?php
/**
 * Created by PhpStorm.
 * User: zq
 * Date: 2018/6/29
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';

$array = array(
    array('db'=>'xb_account','table'=>'users_invite_code','field'=>'qrcode_url'),
    array('db'=>'xb_account','table'=>'users_profile','field'=>'idcardImage1'),
//    array('db'=>'xb_account','table'=>'users_profile','field'=>'idcardImage2'),
//    array('db'=>'xb_account','table'=>'users_profile','field'=>'bankcardImage1'),
//    array('db'=>'xb_account','table'=>'users_profile','field'=>'bankcardImage2'),
    array('db'=>'xb_act','table'=>'activity','field'=>'url'),
    array('db'=>'xb_mis','table'=>'merchant','field'=>'log'),
    array('db'=>'xb_mis','table'=>'merchant_app','field'=>'start_page'),
//    array('db'=>'xb_mis','table'=>'merchant_app','field'=>'ios_download'),
//    array('db'=>'xb_mis','table'=>'merchant_app','field'=>'and_download'),
    array('db'=>'xb_mis','table'=>'sharetheme','field'=>'shareurl'),
);

foreach ($array as $key => $value) {
    $old_table = $value['db'].'.'.$value['table'];
    $new_table = $value['db'].'.'.$value['table'].'_temp';

    //复制表结构与数据
    $res_copy = XbModule_Account_Http2Https::getInstance()->copyTable($old_table, $new_table);

    //统计复制前后数据量
    $res_count_old = XbModule_Account_Http2Https::getInstance()->tableCount($old_table);
    $res_count_new = XbModule_Account_Http2Https::getInstance()->tableCount($new_table);

    if ($res_copy && ($res_count_old == $res_count_new)) {
        echo "复制表成功 ".$value['db'].".".$value['table']."\n";
    } else {
        echo "复制表失败 ".$value['db'].".".$value['table']."\n";
    }
}
echo "复制完毕 \n";
die();