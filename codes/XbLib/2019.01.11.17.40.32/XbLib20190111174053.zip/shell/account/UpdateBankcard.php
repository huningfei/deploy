<?php

/*
 * 处理用户编辑银行卡的请求，1分钟执行1次
 */

$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
error_reporting(E_ALL);


$prefix = 'XB_CRON_UPBANK_';

$cache_factory = new XbCache_Factory();
$cache_adapter = $cache_factory->getCacheAdapter();

$lock_key = $prefix . 'LOCK';
$is_lock = $cache_adapter->get($lock_key);

//上次脚本没有执行完毕
if (!$is_lock) {
    
    $time = time();
    //锁定10分钟
    $succ = $cache_adapter->set($lock_key, $time, $time + 10 * 60);
    
    $n = 0;
    do {
        try {

            //取最新的1个编辑请求
            $request = XbModule_Account_UsersBankcardUpdate::getInstance()->listHistory(0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1);
            
            //没有数据停止
            if (empty($request) || empty($request[0])) {
                echo "数据处理完毕，共处理{$n}条记录";
                break;
            }

            $request = $request[0];
            
            $uid = $request['uid'];
 
            $res = XbModule_Account_UsersBankcardUpdate::getInstance()->doUpdate($request['id']);
            
            //将其它没有处理的重复请求标记为放弃
            XbModule_Account_UsersBankcardUpdate::getInstance()->rejectReduplicatedUpdate($uid, $request['id']);

            $n++;
        }
        catch (Exception $e) {
            echo $e . '';
        }
        
        sleep(2);
    } while (1);

    
    $cache_adapter->delete($lock_key);
}
else 
{
    echo 'Process is running, exit';
}