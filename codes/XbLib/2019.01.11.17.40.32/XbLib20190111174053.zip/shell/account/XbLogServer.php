<?php

//预警系统server端，使用swoole_table，依赖共享内存确保进程间计数一致，需要swoole1.9.0版本以上
//目前使用udp通信，待优化
//每次通知最小间隔时间30分钟（取决于配置文件设置）

//TODO udp不检查端口占用，需要确保server唯一，僵尸进程没有预警功能，需要确定。收到特定包时回复。

if (!class_exists('swoole_table')) {
    die('当前swoole版本过低，请升级swoole到1.9.0版本以上');
}

$data_file_dir = '/home/yx/sites/XbLogs';

if (!is_dir($data_file_dir)) {
    @mkdir($data_file_dir);
}

$log_data = [];


//TODO 从日志文件加载初始数据
if (file_exists($data_file_dir . '/current.log')) {
    $content = file_get_contents($data_file_dir . '/current.log');
    $log_data = json_decode($content, true);
}

$log_data = $log_data ? $log_data : [];

$key = "XBLOG";



function get_xblog_notice_user($type, $config) {
    $user = [];
    
    if (!empty($config['default']['user'])) {
        $user = array_merge($user, (array)($config['default']['user']));
    }
    
    if (!empty($config['default']['group'])) {
        $config['default']['group'] = (array)($config['default']['group']);
        
        foreach ($config['default']['group'] as $group) {
            if (!empty($config['user_group'][$group])) {
                $user = array_merge($user, (array)($config['user_group'][$group]));
            }
        }
    }
    
    foreach ($config['rule'] as $key => $item) {
        if (strtolower($key) == strtolower($type)) {
            if (!empty($item['user'])) {
                $user = array_merge($user, (array)($item['user']));
            }
        }
        
        if (!empty($item['group'])) {
            $item['group'] = (array)($item['group']);
            
            foreach ($item['group'] as $group) {
                if (!empty($config['user_group'][$group])) {
                    $user = array_merge($user, (array)($config['user_group'][$group]));
                }
            }
        }
    }
    
    $user = array_unique($user);
    
    $data = [];
    foreach ($user as $name) {
        if (!empty($config['users'][$name])) {
            $data[$name] = $config['users'][$name];
        }
    }
    
    return $data;
}

function decodeUnicode($str) {
    return preg_replace_callback('/\\\\u([0-9a-f]{4})/i',
        create_function(
            '$matches',
            'return mb_convert_encoding(pack("H*", $matches[1]), "UTF-8", "UCS-2BE");'
            ),
        $str);
}

//最大行数小于1024
$table = new swoole_table(1024);

//错误次数
$table->column('times', swoole_table::TYPE_INT, 8);
//上次通知时间
$table->column('alert_at', swoole_table::TYPE_INT, 4);
//上次通知时发生次数
$table->column('alert_times', swoole_table::TYPE_INT, 8);
//是否需要通知
$table->column('alert', swoole_table::TYPE_INT, 4);
//是否需要短信通知
$table->column('alert_sms', swoole_table::TYPE_INT, 4);

if (!$table->create()) {
    die('内存申请失败！');
}

//创建udp服务
$server = new swoole_server("0.0.0.0", 9002, SWOOLE_PROCESS, SWOOLE_SOCK_UDP);

$server->set(array(    
    'daemonize' => 1,//开启守护进程运行
    'task_worker_num' => 4
   
));


$server->on('WorkerStart', function($server, $worker_id) use ($key) {
    //只在一个进程中启动定时器
    if ($worker_id == 0) {
        
        //每隔3秒检查一次告警触发
        $server->tick(3000, function ($id) use ($server) {
            $server->task("Notice");
        });
    }
});

/*
$server->on('receive', function ($server, $fd, $from_id, $data) use ($key, $table) {
    echo $data;
    $data = json_decode($data, true);
    
    if (!isset($data['type'])) {
        return;
    }
    
    //0-4级日志不处理
    if (empty($data['level']) || $data['level'] < 5) {
        return;
    }
    
    //5 级及以上日志统计数量
    $name = $key. ':' . $data['type'];
    
    $num = $table->incr($name, 'times', 1);
    
    // 10 级及以上记录日志内容，并做邮件短信处理
    //遇到触发警告类错误时，将日志数据写到零时文件
    if (!empty($data['level']) && $data['level'] >= 10) {
        $table->incr($name, 'alert', 1);
        
        //15级（不含15）错误短信通知
        if ($data['level'] > 15) {
            $table->incr($name, 'alert_sms', 1);
        }
        
        $file_name = $name . '.xblog.tmp';
        file_put_contents('/tmp/' . $file_name, "[id:{$num}]\n" . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "<hr>\n-------------------------\n\n", FILE_APPEND);
    }
    
    //echo "[{$num}]";
});
*/

$server->on('packet', function($server, $data, $client) use ($key, $table) {
    echo $data;
    $data = json_decode($data, true);
var_dump($data);
    if (!isset($data['type'])) {
        return;
    }
    
    //0-4级日志不处理
    if (empty($data['level']) || $data['level'] < 5) {
        return;
    }
    
    //5 级及以上日志统计数量
    $name = $key. ':' . $data['type'];
    
    $num = $table->incr($name, 'times', 1);
    
    // 10 级及以上记录日志内容，并做邮件短信处理
    //遇到触发警告类错误时，将日志数据写到零时文件
    if (!empty($data['level']) && $data['level'] >= 10) {
        $table->incr($name, 'alert', 1);
        
        //15级（不含15）错误短信通知
        if ($data['level'] > 15) {
            $table->incr($name, 'alert_sms', 1);
        }
        
        $file_name = $name . '.xblog.tmp';
        file_put_contents('/tmp/' . $file_name, "[id:{$num}]\n<pre>" . json_encode($data, JSON_PRETTY_PRINT) . "</pre>\n", FILE_APPEND);
    }
    
    //echo "[{$num}]";
});


$server->on('task', function ($server, $task_id, $reactor_id, $data) use ($table) {
    $time = time();
    
    if ($data == 'Notice') {
        
        require_once __DIR__ . '/../../bootstrap.php';

        //引用预警配置
        $config = require __DIR__ . '/XbLogConfig.php';
        
        foreach ($table as $key => $column) {
            //开始检查触发规则
            
            $tmp = explode(':', $key);
            
            $type = $tmp[1];
            
            $config['alert_interval'] = empty($config['alert_interval']) ? 30*60 : $config['alert_interval'];
            $config['alert_interval'] = $config['alert_interval'] < 10*60 ? 10*60 : $config['alert_interval'];

            //需要通知
            if ($column['alert']) {
            
                if ($column['times'] > $column['alert_times'] && ($time - $column['alert_at']) > $config['alert_interval'] ) {

                    $notice_num = $column['times'] - $column['alert_times'];
                    $notice_num_10 =  $column['alert'];
                    $notice_num_15 = $column['alert_sms'];
                    $notice_at = $column['alert_at'];
                    
                    $column['alert_at'] = $time;
                    $column['alert_times'] = $column['times'];
                    $column['alert'] = 0;
                    
                    $alert_sms = $column['alert_sms'];
                    $column['alert_sms'] = 0;
                    
                    //更新数据
                    $table->set($key, $column);
                    
                    $file_name = '/tmp/' . $key . '.xblog.tmp';
                    
                    $user_info = get_xblog_notice_user($type, $config);
                    
                    if ($user_info) {
                         //将零时文件作为附件，发送邮件，短信通知
                        
                        echo (json_encode($user_info));
                        
                        $email = [];
                        $phone = [];
                        foreach ($user_info as $item) {
                            if (!empty($item['email'])) {
                                $email[] = $item['email'];
                            }
                            
                            if (!empty($item['phone'])) {
                                $phone[] = $item['phone'];
                            }
                        }
                        
                        $email = array_unique($email);
                        $phone = array_unique($phone);
                        
                        echo '发送提醒邮件';
                        
                        //组合邮件内容
                        
                        $title = '【告警通知】【' . (empty($config['rule'][$type]['name']) ? '-' : $config['rule'][$type]['name']) . '】' . $type . ' ' . date('Y-m-d H:i:s', $time);
                        
                        //$msg = "距离上次通知【" . date('Y-m-d H:i:s', $notice_at) . "】共触发预警：5级以上【{$notice_num}】次；10级以上【{$notice_num_10}】次；15级以上【{$notice_num_15}】次；";
                        
                        $sms = '【小白卡管家】告警通知 '. (empty($config['rule'][$type]['name']) ? '-' : $config['rule'][$type]['name']).' ' .$type.' ' .date('Y-m-d H:i:s', $time). '发生' . ($notice_num_15) . '次紧急错误，请及时查看邮件！';
                        
                        
                        $msg = '5-9&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;级告警数量：' . ($notice_num - $notice_num_10) . "\n";
                        $msg .= '10-14&nbsp;级告警数量：' . ($notice_num_10 - $notice_num_15) . "\n";
                        $msg .= '15+&nbsp;&nbsp;&nbsp;&nbsp;级告警数量：' . ($notice_num_15) . "\n";
                        $msg .= "告警id编号：" . ($column['times'] - $notice_num) . " - {$column['times']}\n";
                        $notice_at = $notice_at ? date('Y-m-d H:i:s', $notice_at).' - ' : '';
                        $msg .= '时间：' .$notice_at  . date('Y-m-d H:i:s', $time) . "\n";
                        $msg .= "\n\n";
                        
                        //读取日志，最多读取1m
                        $content = file_get_contents($file_name, null, null, null, 1024 * 1024 * 1);
                        //转化unicode
                        $content = decodeUnicode($content);
                        //去掉多余 \
                        $content = str_replace('\\', '', $content);

                        $msg .= $content;

                        
                        XbLib_Postman::sendMail($email, $title, $msg ? str_replace("\n", "<br>", $msg) : '');
                    
                        //如果需要短信通知，发送短信
                        if ($alert_sms && $phone) {
                            echo '短信通知';
                            //TODO 
                            $adapter = new XbLib_Msg_Adapter_Zhizhen();
                            foreach ($phone as $n) {
                                $adapter->sendMsg('127.0.0.1', $n, $sms);
                            }
                        }                    
                    }
                    
                    //删除日志零时文件
                    @unlink($file_name);
                }
                else {
                    echo '时间限制';
                }
            }
        }
        
        //TODO 将错误统计写入硬盘，用于重启后重新加载数据
    }

});

$server->on('finish', function ($server, $task_id, $data) {
});

$server->start();

