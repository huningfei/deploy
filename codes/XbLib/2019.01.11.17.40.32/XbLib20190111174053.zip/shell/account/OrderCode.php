<?php

$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$num = 1000;
XbModule_Account_Order::getInstance(0)->createOrderCode($num);

