<?php
define('ROOT_PATH', '/home/yx/sites/xb_api');
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);

//获取所有已经审核通过的用户
$num = 10;
$page = 1;
do{
    $limit = ($page - 1)*$num;
    $userProfile = XbModule_Account_UsersProfile::getInstance()->getUsersByStatus(3, $limit, $num);
    if(!$userProfile) break;
    foreach($userProfile as $key => $val){
        //获取目前通道
        $channels = array(
            //2 => 'fujianyangtao',
            //3 => 'fujianliulian',
            //4 => 'fujianyingtao',
            //5 => 'fujianhuolongguo',
            //6 => 'fujianboluo',
//            7 => 'fujianyingtaojx'
            8 => 'fujianyingtaojxb'
        );

        $userInfo = XbModule_Account_Users::getInstance()->getUserById($val['uid']);
        if($userInfo){
            sleep(1);
            //获取用户已注册通道信息、
            $userChannel = [];
            $userChannel =XbModule_Account_UsersChannel::getInstance()->getAllUserChannelByUid($val['uid']);

            foreach($channels as $k => $v){
                foreach($userChannel as $kkk => $vvv){
                    if($k  == $vvv['channel_id']){
                        unset($channels[$k]);
                        unset($userChannel[$kkk]);
                    }
                }
            }
            if(!$channels) {echo "用户".$val['uid']."已注册完成当前所有可用通道\n";continue;}
            $data = array(
                'order_id'       => XbModule_Account_OrderCode::getInstance()->getOrderCode(),
                'phone'          => $val['bankcard_phone'],
                'realname'       => $val['realname'],
                'idcardNumber'   => $val['idcardNumber'],
                'bankcardNumber' => $val['bankcardNumber'],
                'bankCardCode'   => $val['bankCode'],
                'bankcardImage1' => $val['bankcardImage1'],
                'bankcardImage2' => $val['bankcardImage2'],
                'idcardImage1'   => $val['idcardImage1'],
                'idcardImage2'   => $val['idcardImage2'],
                'bank'           => $val['bank'],
                'fee'            => '2',
                'rate'           => '0.0054',
                'mininum_charge' => '0',
                'maxnum_charge'  => '9999',
                'uid'  => $val['uid'],
            );
            foreach($channels as $kk=>$vv){
                $res = XbLib_ChannelFunc_Channel::getInstance()->signUpChannel($kk,$data);
                XbFunc_Log::write('sinupUserChannel', '注册通道失败：'.$kk.json_encode($data));

                if($res['code'] == 200 && count($res['channelInfo'])>0){
                    $res = XbModule_Account_UsersChannel::getInstance()->createChannelCode($val['uid'], $res['channelInfo']);
                    $res= $res ? 'OK' : 'Fail';
                    echo "用户ID【".$val['uid']."】通道【".$vv."】入库结果：".$res."数据\n";
                }else{
                    echo "用户ID【".$val['uid']."】通道【".$vv."】注册结果失败\n";
                    continue;
                }
            }
        }else{
            echo "用户信息不全";
            continue;
        }
    }
    $page ++;
}while(true);

echo '执行完毕';

