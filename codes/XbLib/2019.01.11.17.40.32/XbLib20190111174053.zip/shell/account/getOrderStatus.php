<?php
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", 'rls');
$yibao_sett_status = array(
    'RECEIVED'   =>1,//已接收
    'PROCESSING' =>2,//处理中
    'SUCCESSED'  =>3,//打款成功
    'FAILED'     =>4,//打款失败
    'REFUNED'    =>5,//已退款
    'CANCELLED'  =>6//已撤销
);
do {
    //获取没支付/结算中订单订单
    $orders  = XbModule_Account_Order::getInstance(1)->getOrderByStatus('0');
    if(!$orders)  exit;
    foreach($orders as $key => $val){
        var_dump($val);
        $channel_level = XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($val['channel_id']);
        $channel_id     =$channel_level['channel_id'];
        $usersChannel = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($val['uid'],$channel_id);
        $is_settlement = XbModule_Account_Channel::getInstance()->getChannelDetail( $channel_id);
        $mch_id = XbModule_Account_Users::getInstance()->getUserById($val['uid'])['mch_id'];
        //查询订单状态
        $data['order_id'] = $channel_id==1? $val['axf_order_no']:XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $data['channel_code'] = $usersChannel['channel_code'];
        $data['channel_key'] = $usersChannel['channel_key'];
        $data['axf_order_no'] = $val['axf_order_no'];
        $data['startTime'] =date('Y-m-d H:i:s',$val['create_time']-3600);
        $data['endTime'] = date('Y-m-d H:i:s',$val['create_time']+86400);

        $res = XbLib_ChannelFunc_Channel::getInstance()->tradeRevice($channel_id,$data);
        var_dump($res);
        if($res['code'] == '0000'){
            if($res['tradeReceives']&&count($res['tradeReceives'])>0){
                //处理数据
                $yibao_res = $res['tradeReceives'][0];
                $params= array(
                    'order_id'=>$yibao_res['requestId'],
                    'axf_order_no'=>$yibao_res['requestId'],
                    'externalld'=>$yibao_res['externalId'],
                    'paytime'=>$yibao_res['payTime'],
                    'pay_amount'=>$yibao_res['amount'],
                    'amount'=>$yibao_res['amount'],
                    'msg'=>$res['message'],
                    'channel_code'=>$yibao_res['customerNumber'],
                    'fee'=>$yibao_res['fee'],
                    'status'=> $yibao_res['status']=='SUCCESS'?1:2,
                    'code'=>'200',
                );
                $params['uid']  = $val['uid'];
                $params['channel_tag']  = 3;
                $params['rate'] = (int)$channel_level['fee'];
                $params['channel_id'] = $channel_level['channel_id'];
//                var_dump($params);die;

            }else if($res['USER_ID']){
                //处理数据
                $params = array(
                    'channel_id' => $channel_id,
                    'uid' => $val['uid'],
                    'order_id' => $res['ORDER_ID'],
                    'axf_order_no' => $res['ORG_ORDER_ID'],
                    'externalld' => $res['ORDER_ID'],
                    'paytime'   => '',
                    'pay_amount' => $res['ORDER_AMT'],
                    'amount' => $res['ORDER_AMT'],
                    'msg' => $res['RESP_DESC'],
                    'channel_code' => $res['USER_ID'],
                    'code' =>  $res['RESP_CODE']=='0000'?200:$res['RESP_CODE'],
                    'status' => $res['RESP_CODE']=='0000'?1:2
                );
                //计算实际到账金额以及手机费
                $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($params['axf_order_no']);
                var_dump($order);
                $params['rate'] = $order['rate'];
                $fee = sprintf("%.2f", bcmul( $params['pay_amount'],$params['rate'],4));
                $params['fee'] = $fee + $order['single_fee'];
                $params['after_amount'] = $params['pay_amount'] - $params['fee'] ;
            }
            //如果通道支持结算走结算，反之直接修改订单状态
            if($is_settlement && $is_settlement['is_settlement'] ==1){
                $params['after_amount'] = bcsub($params['amount'],$params['fee'],2);
                //如果订单状态为未支付，则走结算接口 为其打款成功后修改订单状态  如果状态为结算中则拉取结算状态 更改订单状态
                $res = XbLib_ChannelFunc_CallBackField::getInstance()->settlement($params);
                if($res){
                    $params['fee'] = bcadd($params['fee'],$channel_level['fee']);
                    $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($params,1);
                }else{
                    XbFunc_Log::write('CallBackField','请求结算接口失败：'.json_encode($res));
                }
            }else{
                $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($params,2);
            }
            if(!$res){
                XbFunc_Log::write('orderCallback','修改订单状态失败：'.json_encode($params));
            }else{
                echo "订单【".$val['order_id'].'】通道【'.$channel_id."】拉取状态并更改状态成功\n";
            }
        }else{
            echo "FAIL\n";
        }
    }
//    $orders['create_time'] = '1522388567';
//    $orders['uid']=22;
//    $orders['status']=0;
//    $orders['channel_id'] = 1;
//    $orders['order_id'] = '7281816993223641881';
//    $orders['externalld'] = '7281816993223641881';
    //获取用户通道唯一识别
    //校验该通道是否支持结算接口
//    $channel_level = XbModule_Account_Channel::getInstance()->getChannelInfoByChannelLevel($orders['channel_id']);
//    $channel_id     =$channel_level['channel_id'];
//    $usersChannel = XbModule_Account_UsersChannel::getInstance()->getUsersChannelCode($orders['uid'],$channel_id);
//    $is_settlement = XbModule_Account_Channel::getInstance()->getChannelDetail( $channel_id);
//    $uid = XbModule_Account_UsersChannel::getInstance()->getUserId($params['channel_code'])['uid'];
//    $mch_id = XbModule_Account_Users::getInstance()->getUserById($uid)['mch_id'];
//    $data['order_id'] = $channel_id==1? $orders['externalld']:XbModule_Account_Order::getInstance(1)->getOrderCode();
//    $data['channel_code'] = $usersChannel['channel_code'];
//    $data['channel_key'] = $usersChannel['channel_key'];
//    $data['axf_order_no'] = $orders['axf_order_no'];
//    $data['startTime'] =date('Y-m-d H:i:s',$orders['create_time']-3600);
//    $data['endTime'] = date('Y-m-d H:i:s',$orders['create_time']+86400);
//    var_dump($data);
//    $res = XbLib_ChannelFunc_Channel::getInstance()->tradeRevice($channel_id,$data);
//    XbFunc_Log::write('orderCallback','拉取订单状态：'.json_encode($getData));
//    $res = array(
//        'ORDER_ID'=>'2017122500000000911',
//        'ORG_ORDER_ID'=>'2017122500000000120',
//        'ORDER_AMT'=>'110',
//        'RESP_DESC'=>'成功',
//        'USER_ID'=>'C20180413727952',
//        'RESP_CODE'=>'0000',
//        'code'=>'0000',
//    );
//    if($res['code'] == '0000'){
//       if($res['tradeReceives']&&count($res['tradeReceives'])>0){
//           $yibao_res = $res['tradeReceives'][0];
//           $params= array(
//               'order_id'=>$yibao_res['requestId'],
//               'axf_order_no'=>$yibao_res['requestId'],
//               'externalld'=>$yibao_res['externalId'],
//               'paytime'=>$yibao_res['payTime'],
//               'pay_amount'=>$yibao_res['amount'],
//               'amount'=>$yibao_res['amount'],
//               'msg'=>$yibao_sett_status[$yibao_res['status']],
//               'channel_code'=>$yibao_res['customerNumber'],
//               'fee'=>$yibao_res['fee'],
//               'status'=> $yibao_res['status']=='SUCCESS'?1:2,
//               'code'=>$yibao_res['code']=='0000' ? 200 : $data['code'],
//           );
//
//           $params['uid']  = $orders['uid'];
//           $params['channel_tag']  = 3;
//           $params['rate'] = (int)$channel_level['fee'];
//           $params['channel_id'] = $channel_level['channel_id'];
//           var_dump($params);
//
//       }else if($res['USER_ID']){
//            $params = array(
//                'channel_id' => $channel_id,
//                'uid' => $orders['uid'],
//                'order_id' => $res['ORDER_ID'],
//                'axf_order_no' => $res['ORG_ORDER_ID'],
//                'externalld' => $res['ORDER_ID'],
//                'paytime'   => '',
//                'pay_amount' => $res['ORDER_AMT'],
//                'amount' => $res['ORDER_AMT'],
//                'msg' => $res['RESP_DESC'],
//                'channel_code' => $res['USER_ID'],
//                'code' =>  $res['RESP_CODE']=='0000'?200:$res['RESP_CODE'],
//                'status' => $res['RESP_CODE']=='0000'?1:2
//            );
//           //计算实际到账金额以及手机费
//           $order =  XbModule_Account_Order::getInstance($mch_id)->getOrderByAnfOrderNo($params['axf_order_no']);
//           var_dump($order);
//           $params['rate'] = $order['rate'];
//           $fee = sprintf("%.2f", bcmul( $params['pay_amount'],$params['rate'],4));
//           $params['fee'] = $fee + $order['single_fee'];
//           $params['after_amount'] = $params['pay_amount'] - $params['fee'] ;
//       }
//        if($is_settlement && $is_settlement['is_settlement'] ==1){
//            $params['after_amount'] = bcsub($params['amount'],$params['fee'],2);
//            if($orders['status'] == 3){
//                $res = XbLib_ChannelFunc_CallBackField::getInstance()->settlement($params);
//                if($res){
//                    $params['fee'] = bcadd($params['fee'],$channel_level['fee']);
//                    $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($params,1);
//                }else{
//                    XbFunc_Log::write('CallBackField','请求结算接口失败：'.json_encode($res));
//                }
//            }else{
//                $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($params,2);
//            }
//        }else{
//            $res = XbModule_Account_Order::getInstance($mch_id)->callBackField($params,2);
//        }
//        if(!$res){
//           XbFunc_Log::write('orderCallback','修改订单状态失败：'.json_encode($params));
//       }
//    }
}while(true);
