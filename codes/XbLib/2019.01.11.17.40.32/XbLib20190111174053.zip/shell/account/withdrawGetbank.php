<?php
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';

//获取所有profit所有记录
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
$mch_id = empty($argv[2])?1:$argv[2];
$id = 1;
do{
    echo $id;
    $profit = XbModule_Account_Profit::getInstance($mch_id)->getAllProfit($id);

    if($profit){
        foreach($profit as $key => $val){
            if($val['type'] == 1){
                $profit[$key]['surplus_amount'] = ($key-1 == -1 ?0:$profit[$key-1]['surplus_amount']) + $val["amount"];
            }else{
                $profit[$key]['surplus_amount'] =($key-1 == -1 ?0:$profit[$key-1]['surplus_amount']) - $val["amount"] < 0 ?0: ($key-1 == -1 ?0:$profit[$key-1]['surplus_amount']) - $val["amount"] ;
                //获取用户提现银行卡名称
                $cashInfo = XbModule_Account_Profit::getInstance($mch_id)->getWithdrawByOrderId($val['order_id']);
                if($cashInfo){
                    //获取用户
                    $profile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($val['uid']);
                    if($profile){
                        //初始化提现银行卡
                        $changeBank = XbModule_Account_Profit::getInstance($mch_id)->changeBank($cashInfo['id'],$profile['bank']);
                        if($changeBank){
                            echo "用户【".$val['uid']."】初始化银行卡成功\n";
                        }else{
                            echo "用户【".$val['uid']."】初始化银行卡成功\n";
                        }
                    }else{
                        echo "用户【".$val['uid']."】没有此用户基础信息";continue;
                    }
                }else{
                    echo "用户【".$val['uid']."】withdraw_cash 没有提现数据";continue;
                }
            }
            if($profit[$key]['surplus_amount'] >0){
                //金额发生变化，更改当前数据
                $changeSurplusAmout = XbModule_Account_Profit::getInstance($mch_id)->changeSurplusAmount($val['id'],$profit[$key]['surplus_amount']);
                if($changeSurplusAmout){
                    echo "用户【".$val['uid']."】修改变动后金额成功 ".$profit[$key]['surplus_amount']."\n";

                }else{
                    echo "用户【".$val['uid']."】修改变动后金额失败 ".$profit[$key]['surplus_amount']."\n";

                }
            }
        }



    }else{
        echo "没有数据\n";
    }
    $id++;
    if($id>=110){
        exit;
    }
}while(true);

