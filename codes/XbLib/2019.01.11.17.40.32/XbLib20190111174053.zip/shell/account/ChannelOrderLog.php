<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/16
 * Time: 上午10:28
 */
$unit_path = realpath(dirname(__FILE__));
ini_set('memory_limit', '2048M');
ini_set("max_execution_time", "0");
include $unit_path . '/../../bootstrap.php';
define("SHELL_VARIABLE", empty($argv[1]) ? 'rls' : $argv[1]);
//今天的时间
$end_time = strtotime(date("Y-m-d",time()).' 23:59:59');
$start_time = strtotime(date("Y-m-d",time()).' 00:00:00');
//获取所有开启的通道
$res = XbModule_Account_Channel::getInstance()->getChannel(1);

if($res){
    foreach($res as $key => $val){
        //获取通道对应等级的ID
        $ccl_ids = '';
        $ccl_res = XbModule_Account_CommonChannelLevel::getInstance()->getCClByChannelId($val['channel_id']);
        if($ccl_res){
            foreach($ccl_res as $key => $val){
                $ccl_ids .=$val['id'].',';
            }
        }
        $new_ccl_ids = rtrim($ccl_ids,',');
        //获取当天通道下单数量
        $count = XbModule_Account_Order::getInstance(1)->getTodayOrderBychannelId($new_ccl_ids,$start_time,$end_time);
        if($count==0){
            echo $val['channel_name'].'已24小时未产生订单'.$count;
            XbFunc_Log::write('通道没有订单','通道没有订单',$val['channel_name'].'已24小时未产生订单,建议查看通道是否异常',16);
        }else{
            echo $val['channel_name'].'OK';
        }
    }

}else{
    echo "暂无可用通道";
}