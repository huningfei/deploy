<?php
/**
 *
 * Author: abel
 * Date: 2017/12/7
 * Time: 12:14
 */
$unit_path = realpath(dirname(__FILE__));

include $unit_path.'/../../bootstrap.php';

$factory = new RandomLib\Factory();

//随字符
$generator = $factory->getGenerator(new SecurityLib\Strength());
$random = $generator->generateString(4,'1234567890');
print_r("随机字符:{$random}");