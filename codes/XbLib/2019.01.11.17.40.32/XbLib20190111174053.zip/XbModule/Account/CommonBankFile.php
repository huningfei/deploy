<?php
/**
 * @desc 	上传信用卡管理
 * @author  yurong
 * @date    18.06.06
 */
class XbModule_Account_CommonBankFile
{
    private $order_model = null;
    private static $obj = null;
    private static $sufix = null;

    /**
     * 封闭构造
     * XbModule_Account_CommonBankFile constructor.
     */
    private function __construct()
    {
        $this->bankfile_model = new XbModel_Account_CommonBankFile();
    }

    /**
     * 单例获取
     * 保证一条进程只产生一个Module对象
     */
    public static function getInstance()
    {
        if (empty (self::$obj)) {
            self::$obj = new XbModule_Account_CommonBankFile();
        }
        return self::$obj;
    }
    /**
     * @desc 获取上传信用卡列表
     * @param    int          $start      偏移量
     * @param    int          $limit      条数
     * @param    string       $title      表格名称
     * @param    string       $start_time 开始时间
     * @param    string       $end_time   结束时间
     * @param    int          $status     状态
     * @return   array        $return     返回执行结果
     **/
    public function getBankFileList($start,$limit,$title,$start_time,$end_time,$status){
        return $this->bankfile_model->getBankFileList($start,$limit,$title,$start_time,$end_time,$status);
    }
    /**
     * @desc 获取上传信用卡条数
     * @param    string       $title      表格名称
     * @param    string       $start_time 开始时间
     * @param    string       $end_time   结束时间
     * @param    int          $status     状态
     * @return   int          $return     返回执行条数
     **/
    public function getBankFileCount($title,$start_time,$end_time,$status){
        $res =  $this->bankfile_model->getBankFileCount($title,$start_time,$end_time,$status);
        return $res ? $res['num'] : 0;
    }
    /**
     * @desc 上传文件
     * @param   string     $batch_number      批次号
     * @param   string     $title             上传表格名称
     * @param   int        $status            状态
     * @param   string     $url               上传路径
     * @param   string     $operator          操作人
     * @return  int        $return            返回执行结果
     * */
    public function add($batch_number,$title,$status,$url,$operator){
        return $this->bankfile_model->add($batch_number,$title,$status,$url,$operator);
    }
    /**
     * @desc 获取单条上传信息
     * @param    int    $id    上传ID
     * @return   array  $return返回执行结果
     * */
    public function getBankFileById($id){
        return $this->bankfile_model->getBankFileById($id);
    }
    /**
     * 更改上传文件状态
     * @param   int       $id       ID
     * @param   int       $status   状态
     * @param   string    $reason   原因
     * @return  boolean   $return   返回执行结果
     * */
    public function updateStatus($id,$status,$reason,$number=0){
        return $this->bankfile_model->updateStatus($id,$status,$reason,$number);
    }
    /**
     * @desc 获取当天最新批次号
     */
    public function getBatchNumber(){
        $res =  $this->bankfile_model->getBatchNumber();
        $number = date('Ymd',time()).'001';
        return $res ? $res['batch_number']+1 :$number;
    }
}