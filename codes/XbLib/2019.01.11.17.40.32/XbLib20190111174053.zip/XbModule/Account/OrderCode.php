<?php
/**
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/14
 * Time: 下午3:18
 */
class XbModule_Account_OrderCode
{
    private $ordercode_model = null;
    private static $obj = null;

    /**
     * 封闭构造
     * XbModel_Account_OrderCode constructor.
     */
    private function __construct()
    {
        $this->ordercode_model = new XbModel_Account_OrderCode();
    }

    /**
     * 单例
     * @return null|XbModel_Account_OrderCode
     */
    public static function getInstance()
    {

        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_OrderCode();
        }
        return self::$obj;
    }
    //获取orderCode
    public function getOrderCode(){
        return $this->ordercode_model->getOrderCode();
    }
    //创建单个订单号
    public function createOrder(){
        return $this->ordercode_model->createOrder();
    }
}