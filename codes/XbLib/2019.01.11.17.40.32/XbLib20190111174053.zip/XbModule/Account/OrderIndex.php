<?php
/**
 * @desc 	订单相关
 * @author  zq
 * @date    18.5.29
 */
class XbModule_Account_OrderIndex{
    private $order_index_model = null;
    private static $obj  = null;

    /**
     * 封闭构造
     * XbModel_Account_OrderProfit constructor.
     */
    private function __construct() {
        $this->order_index_model = new XbModel_Account_OrderIndex();
    }

    /**
     * 单例获取
     * 保证一条进程只产生一个Module对象
     */
    public static function getInstance() {
        if (empty ( self::$obj )) {
            self::$obj = new XbModule_Account_OrderIndex();
        }
        return self::$obj;
    }

    /**
     * @desc    创建订单索引信息
     * @param   array   $param      订单索引信息
     * @return  array   $return     返回创建结果
     */
    public function createOrderIndex($index_data){
        return $this->order_index_model->createOrderIndex($index_data);
    }

    /**
     * @desc    根据订单号，查询订单索引信息
     * @param   int     $orderid    订单号
     * @return  array   $return     返回搜索结果
     */
    public function getOrderIndexByOrderId($order_id){
        return $this->order_index_model->getOrderIndexByOrderId($order_id);
    }
}