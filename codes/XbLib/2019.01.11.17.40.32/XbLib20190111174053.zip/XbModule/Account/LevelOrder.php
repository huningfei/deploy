<?php
/**
 * @desc    购买等级订单
 * @author  qien
 * @date    18.01.22
 */
class XbModule_Account_LevelOrder {
    private $levelorder_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModel_Account_LevelOrder constructor.
     */
    private function __construct() {
        $this->levelorder_model = new XbModel_Account_LevelOrder();
    }

    /**
     * 单例
     * @return null|XbModule_Account_LevelOrder
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_LevelOrder();
        }
        return self::$obj;
    }

    /**
     * @desc    新建购买等级订单
     * @param   array           $data       需要插入的数据
     * @return  error|boolen    $return     返回执行结果
     */
    public function createLevelOrder($data, $authorName){
        if(!$data['telephone'] || !XbLib_Verify::checkPhone($data['telephone']) ){
            return new XbLib_WebError(4101);
        }
        $userInfo = XbModule_Account_Users::getInstance()->getUserByPhone($data['telephone']);
        if(!$userInfo){
            return new XbLib_WebError(4108);
        }
        $userProfile = XbModule_Account_UsersProfile::getInstance()->getProfileByUid($userInfo['id']);
        if(!$userProfile || $userProfile['status'] != 3){
            return new XbLib_WebError(6001);
        }
        $mchInfo = XbModule_Merchant_Merchant::getInstance()->details($userInfo['mch_id']);
        //获取当前用户等级
        $oldLevel = XbModule_Account_UsersLevel::getInstance()->getUserLevelByUid($userProfile['uid']);
        if(!$oldLevel){
            return new XbLib_WebError(6002);
        }
        $buyLevel = XbModule_Account_Level::getInstance()->getLevelByLevel($data['level']);
        if(!$buyLevel){
            return new XbLib_WebError(6004);
        }
        if(empty($data['payId'])){
            return new XbLib_WebError(6005);
        }
        $payIdInfo = $this->getLevelOrderByPayId($data['payId']);
        if($payIdInfo){
            return new XbLib_WebError(6009);
        }
        if(empty($data['payTime'])){
            return new XbLib_WebError(6006);
        }
        $paytime = strtotime($data['payTime']);
        if(empty($data['status'])){
            return new XbLib_WebError(6007);
        }
        $order_id = XbModule_Account_OrderCode::getInstance()->getOrderCode();
        $profit   = bcmul($buyLevel['cost'], $mchInfo['by_rate'], 2);
        $res = $this->levelorder_model->createLevelOrder($order_id, $data['payId'], $data['payType'], $userInfo['id'], $userInfo['mch_id'], $oldLevel['level'], $oldLevel['levelName'], $buyLevel['level'], $buyLevel['levelName'], $buyLevel['cost'], $profit, $paytime, $data['status'], $data['description'], $authorName);
        if($res){
            $res = XbModule_Account_UsersLevel::getInstance()->updateUserLevel($userInfo['id'], $oldLevel['level'], $oldLevel['levelName'], $buyLevel['level'], $buyLevel['levelName'], 1, '添加等级购买订单');
        }
        return $res;
    }

    public function updateLevelOrder($data, $authorName){
        $levelOrderInfo = $this->getLevelOrderById($data['id']);
        $updateField = array();
        if($levelOrderInfo['buyLevel'] != $data['level']){
            if($levelOrderInfo['oldLevel'] >= $data['level']){
                return new XbLib_WebError(6003);
            }
            $buyLevel = XbModule_Account_Level::getInstance()->getLevelByLevel($data['level']);
            $updateField['level'] = '修改等级由'.$levelOrderInfo['buyLevelName'].'修改为：'.$buyLevel['levelName'];
            //计算分润
            $userInfo = XbModule_Account_Users::getInstance()->getUserById($levelOrderInfo['uid']);
            $mchInfo = XbModule_Merchant_Merchant::getInstance()->details($userInfo['mch_id']);
            $profit   = bcmul($buyLevel['cost'], $mchInfo['by_rate'], 2);
        }
        if($levelOrderInfo['pay_id'] != $data['payId']){
            $updateField['payId'] = '修改支付订单号由'.$levelOrderInfo['pay_id'].'修改为：'.$data['payId'];
        }
        $paytime = strtotime($data['payTime']);
        if($paytime != $levelOrderInfo['pay_time']){
            $oldPayDate = date('Y-m-d H:i:s', $levelOrderInfo['pay_time']);
            $updateField['payTime'] = '修改支付时间由'.$oldPayDate.'修改为：'.$data['payTime'];
        }
        if($data['description'] != $levelOrderInfo['description']){
            $updateField['description'] = '修改备注由'.$levelOrderInfo['description'].'修改为：'.$data['description'];
        }
        if(count($updateField) == 0){
            return new XbLib_WebError(6008);
        }
        $userInfo = XbModule_Account_Users::getInstance()->getUserByid($levelOrderInfo['uid']);
        $res = $this->levelorder_model->updateLevelOrder($data['id'], $data['payId'], $data['payType'], $buyLevel['level'], $buyLevel['levelName'], $buyLevel['cost'], $profit, $paytime, $data['description'], $updateField, $authorName);
        if($res){
            $res = XbModule_Account_UsersLevel::getInstance()->updateUserLevel($userInfo['id'], $levelOrderInfo['oldLevel'], $levelOrderInfo['oldLevelName'], $buyLevel['level'], $buyLevel['levelName'], 1, '添加等级购买订单');
        }
        return $res;
    }

    /**
     * @desc    根据uid获取购买等级记录
     * @param   int     $uid        用户id
     * @return  array   $return     返回记录
     */
    public function getLevelOrderByUid($uid, $status=''){
        return $this->levelorder_model->getLevelOrderByUid($uid, $status);
    }

    /**
     * @desc    获取等级购买页面
     * @param   int     $mchId      商户id
     * @param   string  $telephone  商户手机号
     * @param   int     $buyLevel   购买等级
     * @param   string  $startTime  搜索开始时间
     * @param   string  $endTime    搜索结束时间
     * @param   int     $status     订单状态
     * @return  array   $return     返回搜索信息
     */
    public function getAllLevelOrder($realname ='',$start='', $limit='', $count=false, $status='', $mchId='', $telephone='', $buyLevel='', $startTime='', $endTime=''){
        return $this->levelorder_model->getAllLevelOrder($realname,$start, $limit, $count, $status, $mchId, $telephone, $buyLevel, $startTime, $endTime);
    }

    /**
     * @desc    获取订单|订单分润总金额
     */
    public function getTotalAmount($realname='',$profit=false, $status='', $mchId='', $telephone='', $buyLevel='', $startTime='', $endTime=''){
        return $this->levelorder_model->getTotalAmount($realname,$profit, $status, $mchId, $telephone, $buyLevel, $startTime, $endTime);
    }

    /**
     * @desc    根据id获取订单
     * @param   int     $id     id
     * @return  array   $return
     */
    public function getLevelOrderById($id){
        return $this->levelorder_model->getLevelOrderById($id);
    }

    /**
     * @desc    根据pay_id获取订单
     * @param   int     $payId     支付id
     * @return  array   $return
     */
    public function getLevelOrderByPayId($payId){
        return $this->levelorder_model->getLevelOrderByPayId($payId);
    }

    /**
     * @desc    创建操作日志
     * @param   int     $order_id   订单id
     * @return  boolen  $return     返回执行结果
     */
    public function getLevelOrderLogByOrderId($order_id){
        return $this->levelorder_model->getLevelOrderLogByOrderId($order_id);
    }

    /**
     * @desc    删除订单
     * @param   int     $id         订单id
     * @param   string  $authorName 操作人
     * @return  boolen  $return     返回执行结果
     */
    public function delLevelOrder($id, $authorName, $levelOrderInfo){
        $userLevelOrder = $this->getLevelOrderByUid($levelOrderInfo['uid']);
        $updateLevel = 0;
        foreach($userLevelOrder as $v){
            if($v['id'] == $id) continue;
            if(!$updateLevel || $updateLevel < $v['buyLevel']){
                $updateLevel = $v['buyLevel'];
                $updateLevelName = $v['buyLevelName'];
            }
        }
        $updateLevel = $updateLevel > 0 ? $updateLevel : $levelOrderInfo['oldLevel'];
        $updateLevelName = $updateLevelName ? $updateLevelName : $levelOrderInfo['oldLevelName'];
        $res = $this->levelorder_model->delLevelOrder($id, $authorName, $levelOrderInfo, $updateLevel);
        if($res){
            XbModule_Account_UsersLevel::getInstance()->updateUserLevel($levelOrderInfo['uid'], $levelOrderInfo['buyLevel'], $levelOrderInfo['buyLevelName'], $updateLevel, $updateLevelName, 1, '删除等级购买订单');
        }
        return $res;
    }
}