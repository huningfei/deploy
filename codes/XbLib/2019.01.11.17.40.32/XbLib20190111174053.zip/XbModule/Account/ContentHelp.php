<?php
/**
 * @desc  内容管理-帮助中心
 * User: zq
 * Date: 19/6/18
 * Time: 12:03
 */
class XbModule_Account_ContentHelp{
    private $help_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModule_Account_ContentHelp constructor.
     */
    private function __construct() {
        $this->help_model = new XbModel_Account_ContentHelp();
    }

    /**
     * 单例
     * @return null|XbModule_Account_ContentHelp
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_ContentHelp();
        }
        return self::$obj;
    }

    /**
     * @desc 获取帮助中心问题列表
     * @param    int       $help_type   help_type
     * @param    string    $title       奖励名称
     * @return   array     $return      返回执行结果
     * */
    public function getList($help_type, $title, $page,$mch_id){
        return $this->help_model->getList($help_type, $title, $page,$mch_id);
    }

    /**
     * @desc 获取帮助中心一条问题
     * @param    int       $id          id
     * @return   array     $return      返回执行结果
     * */
    public function getHelpById($id){
        return $this->help_model->getHelpById($id);
    }

    /**
     * @desc 修改问题与内容
     * @param    int       $id          id
     * @param    int       $help_type   问题类型
     * @param    string    $title       问题标题
     * @param    int       $content_type内容类型
     * @param    string    $text        文本
     * @param    string    $image       图片地址
     * @param    int       $sort        排序
     * @param    int       $is_use      是否启用
     * @param    int       $is_hot      是否热门推荐
     * @return   array     $return      返回执行结果
     * */
    public function editHelp($id, $help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot){
        return $this->help_model->editHelp($id, $help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot);
    }

    /**
     * @desc 添加问题与内容
     * @param    int       $help_type   问题类型
     * @param    string    $title       问题标题
     * @param    int       $content_type内容类型
     * @param    string    $text        文本
     * @param    string    $image       图片地址
     * @param    int       $sort        排序
     * @param    int       $is_use      是否启用
     * @param    int       $is_hot      是否热门推荐
     * @return   array     $return      返回执行结果
     * */
    public function addHelp($help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot,$mch_id){
        return $this->help_model->addHelp($help_type, $title, $content_type, $text, $image, $sort, $is_use, $is_hot,$mch_id);
    }

    /**
     * @desc 设置是否推荐问题
     * @param    int       $id          id
     * @param    string    $is_hot      是否推荐
     * @return   array     $return      返回执行结果
     * */
    public function editHelpHot($id, $is_hot){
        return $this->help_model->editHelpHot($id, $is_hot);
    }

    /**
     * @desc 删除问题
     * @param    int       $id          id
     * @return   array     $return      返回执行结果
     * */
    public function deleteHelp($id){
        return $this->help_model->deleteHelp($id);
    }

    /**
     * @desc 获取热门问题
     * @return   array     $return      返回执行结果
     * */
    public function getHotHelp($mch_id=1){
        return $this->help_model->getHotHelp($mch_id);
    }

    /**
     * @desc 获取指定问题类型的问题列表
     * @param    int       $help_type    问题类型
     * @return   array     $return      返回执行结果
     * */
    public function getHelpByHelpType($help_type,$mch_id){
        return $this->help_model->getHelpByHelpType($help_type,$mch_id);
    }

    /**
     * @desc 获取排序值
     * @param    int       $id          问题id
     * @param    int       $sort        输入的sort 值
     * @return   array     $return      返回执行结果
     * */
    public function getSort($id, $sort){
        $res_is_have = $this->help_model->getSortIsHave($id, $sort);
        if ($res_is_have) {
            $res_new_sort = $this->help_model->getNewSort($id, $sort);
            return $res_new_sort;
        } else {
            return $sort;
        }
    }
}
