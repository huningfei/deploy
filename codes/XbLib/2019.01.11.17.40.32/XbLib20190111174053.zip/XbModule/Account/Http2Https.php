<?php
/**
 * @desc  http2https
 * User: zq
 * Date: 29/6/18
 * Time: 16:32
 */
class XbModule_Account_Http2Https{
    private $http_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModule_Account_Http2Https constructor.
     */
    private function __construct() {
        $this->http_model = new XbModel_Account_Http2Https();
    }

    /**
     * 单例
     * @return null|XbModel_Account_Http2Https
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModel_Account_Http2Https();
        }
        return self::$obj;
    }

    /**
     * @desc 统计表行数
     * @return    int    $return     返回执行结果
     * */
    public function tableCount($table_name) {
        return $this->http_model->tableCount($table_name);
    }

    /**
     * @desc 复制表表结构与数据
     * @param     int      $id         红包记录id
     * @return    array    $return     返回执行结果
     * */
    public function copyTable($old_table, $new_table) {
        return $this->http_model->copyTable($old_table, $new_table);
    }

    /**
     * @desc 使用https替换http
     * @param     int      $id         红包记录id
     * @return    array    $return     返回执行结果
     * */
    public function http2https($db, $table, $field,  $fromStr='http', $toStr='https') {
        return $this->http_model->http2https($db, $table, $field,  $fromStr, $toStr);
    }

}