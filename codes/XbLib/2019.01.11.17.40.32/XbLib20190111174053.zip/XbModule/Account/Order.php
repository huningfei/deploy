<?php
/**
 * @desc 	订单相关
 * @author  qien
 * @date    17.12.25
 */
class XbModule_Account_Order{
    private $order_model = null;
    private static $obj  = null;

    /**
     * 封闭构造
     * XbModel_Account_Order constructor.
     */
    private function __construct() {
        $this->order_model = new XbModel_Account_Order();
    }
    
    /**
     * 单例获取
     * 保证一条进程只产生一个Module对象
     */
    public static function getInstance($sufix) {
        if(XbModel_Account_Order::$suffix != $sufix){
            XbModel_Account_Order::$suffix = $sufix;
        }
        if (empty ( self::$obj ) ) {
            self::$obj = new XbModule_Account_Order();
        }
        return self::$obj;
    }


    /**
     * @desc    创建订单
     * @param   $uid            用户id
     * @param   $amount         刷卡金额
     * @param   $level          用户等级
     * @param   $rate           刷卡利率
     * @param   $creditBank     刷卡银行
     * @param   $cc             刷卡卡号
     * @param   $dc             收款卡号
     * @param   $channel        刷卡通道
     * @param   $mch_code       用户标识
     * @return  array           返回安心付订单信息
     */
    public function createOrder($uid, $amount, $level, $rate, $creditBank, $cc, $dc, $channel_id, $channel_name, $channel_type, $channel_data, $client_channel = ''){
        $res = $this->order_model->createOrder($uid, $amount, $level, $rate, $creditBank, $cc, $dc, $channel_id, $channel_name, $channel_type, $channel_data, $client_channel);
        if($res){
            //获取用户信息
            $user = XbModule_Account_Users::getInstance()->getUserById($uid);
            if($user['mch_id'] == 1){
                //分润信息
                $profit_channel_id = $channel_type==1 ? $channel_data['channel_id'] : $channel_id;
                $profitUsers = XbModule_Account_UsersInvite::getInstance()->getProfitInfoByUid($uid, $level, $profit_channel_id, $channel_type);
                if(count($profitUsers) > 0){
                    $profitRes = XbModule_Account_OrderProfit::getInstance()->createProfit($profitUsers, $res['orderId'], XbModel_Account_Order::$suffix);
                    if(!$profitRes){
                        $log = json_encode($profitUsers);
                        XbFunc_Log::write('profitUserError','创建订单分润信息（分润用户）失败，订单表：'.XbModel_Account_Order::$suffix.'，订单id：'.$res['orderId'], '用户信息：'.$log);
                    }
                }
            }
        }
        return $res;
    }

    /**
     * @desc    获取所有订单
     * @param   int     $uid    用户id
     * @param   array   $where  搜索条件
     * @param   int     $start  开始条目
     * @param   int     $limit  搜索条目
     * @param   string  $order  排序方式
     * @return  array   $return 返回搜索数据
     */
    public function getAllOrderByUid($uid, $where, $start, $limit, $order='id DESC'){
        return $this->order_model->getAllOrderByUid($uid, $where, $start, $limit, $order);
    }

    /**
     * @desc    统计用户订单
     * @param   int     $uid    用户id
     * @param   array   $where  搜索条件
     * @return  int     $return 返回搜索数量
     */
    public function countOrderByUid($uid, $where){
        return $this->order_model->countOrderByUid($uid, $where);
    }

    /**
     * @desc    统计一共刷卡多少钱
     * @param   int     $uid        用户id
     * @param   array   $where      搜索条件
     * @return  int     $return     返回搜索结果
     */
    public function countAmountByUid($uid, $where){
        return $this->order_model->countAmountByUid($uid, $where);
    }

    /**
     * @desc    根据订单号获取订单信息
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderByOrderid($order_id){
        return $this->order_model->getOrderByOrderid($order_id);
    }

    /**
     * @desc    根据id获取订单信息
     * @param   int     $param      参数
     * @return  array   $return     返回订单信息
     */
    public function getOrderById($id){
        return $this->order_model->getOrderById($id);
    }


    /**
     * @desc    更新订单分润
     * @param   string  $order_id       订单号
     * @param   int     $uid            用户id
     * @param   float   $rate           订单刷卡费率
     * @param   float   $amount         订单刷卡金额
     * @param   float   $oid            订单id
     * @return  boolen  $return         执行结果
     */
    public function synOrderProfit($order_id, $uid, $rate, $amount, $oid){
        $orderProfitInfo = XbModule_Account_OrderProfit::getInstance()->getOrderProfit(XbModel_Account_Order::$suffix, $oid);
        $is_profit = 1;
        $profit = array();
        $profit_min_rate = $rate;
        if($orderProfitInfo){
            foreach($orderProfitInfo as $k=>$v){
                $profitAmount = bcmul(bcsub($rate, $v['rate'], 4), $amount);
                if(!$profitAmount || $profitAmount <= 0){
                    XbFunc_Log::write('profitError','分润金额错误，参数：'.$profitAmount, '分润用户id:'.$v['uid'].'，分润订单：'.$order_id);
                    continue;
                }
                $rate = $v['rate'];
                $reference_no = XbModule_Account_OrderCode::getInstance()->getOrderCode();
                $profit[] = array(
                    'uid'          => $v['uid'],
                    'order_id'     => $order_id,
                    'reference_no' => $reference_no,
                    'from_uid'     => $uid,
                    'rate'         => $v['rate'],
                    'amount'       => $profitAmount,
                    'type'         => 1
                );
                if(bccomp($profit_min_rate, $rate, 4) == 1) $profit_min_rate = $rate;
            }
        }
        if(count($profit) <= 0){
            $profit_min_rate = 0;
            $is_profit = 2;
        }
        $res = $this->order_model->synOrderProfit($order_id, $profit, $profit_min_rate, $is_profit);
        if(!$res){
            //分润失败，记录日志
            $log = json_encode($profit);
            XbFunc_Log::write('profitError','分润插入失败，参数：',$log);
        }
        foreach($profit as $k=>$v){
            XbModule_Account_Profit::getInstance(XbModel_Account_Order::$suffix)->addUserProfitAmount($v['uid'], $v['amount']);
//            XbLib_Jpushappxiaoxi::getInstance()->send_notification_single($v['uid'], $v['from_uid'], 'profit');
            //优化推送消息
            $res = XbLib_PushMsg::getInstance()->profit($v['uid'], array('bid'=>$v['from_uid']));

        }
        return $res;
    }

    //获取orderCode
    public function getOrderCode(){
        return $this->order_model->getOrderCode();
    }
    
    /**
     * @desc    根据商户获取订单
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderList($order_id,$start_time,$end_time,$start,$limit,$status){
        $start=($start-1)*$limit;
        return $this->order_model->getOrderList($order_id,$start_time,$end_time,$start,$limit,$status);
    }
    
    /**
     * @desc    根据商户获取订单数量
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderListCount($order_id,$start_time,$end_time,$o_status){
        return $this->order_model->getOrderListCount($order_id,$start_time,$end_time,$o_status);
    }

    /**
     * @desc    根据id获取跳转链接
     * @param   int     $order_id   订单号
     * @return  array   $return     返回订单信息
     */
    public function getOrderRecirect($order_id){
        return $this->order_model->getOrderRecirect($order_id);
    }

    //获取商户昨天所有的订单
    public function merchantGetOrder($start,$end){
        return $this->order_model->merchantGetOrder($start,$end);
    }

    /**
     * @desc    根据安心付订单号查询订单
     * @param   int     $axf_order_no   订单号
     * @return  array   $return         返回订单信息
     */
    public function getOrderByAnfOrderNo($axf_order_no){
        return $this->order_model->getOrderByAnfOrderNo($axf_order_no);
    }
    //插入每条订单收益
    public function insertMoney($id,$profit_money){
        return $this->order_model->insertMoney($id,$profit_money);
    }

    /**
     * @desc    根据时间获取订单
     */
    public function getOrderByTime($start, $end){
        return $this->order_model->getOrderByTime($start, $end);
    }

    /**
     * @desc    创建订单号，脚本使用，勿用
     * @param   int     $num    数量
     * @return  boolen  $return 执行结果
     */
    public function createOrderCode($num){
        return $this->order_model->createOrderCode($num);
    }

    /**
     * @desc    创建订单分表，脚本使用，勿用
     * @param   int     $num    数量
     * @return  boolen  $return 执行结果
     */
    public function createOrderTable($num){
        return $this->order_model->createOrderTable($num);
    }

    /**
     *@desc  订单支付回调处理订单状态 除失败以外创建打款订单
     *@param
     *@return
     */
    public  function   callBackField($data,$type){
        return $this->order_model->callBackField($data,$type);
    }
    /**
     *@desc  订单结算回调处理订单状态
     *@param
     *@return
     */
    public  function   callBackSettlement($data){
        return $this->order_model->callBackSettlement($data);
    }

    /**
     * @desc 创建打款订单号
     * */
    public function createPlayMoneyOrderCode(){
        return $this->order_model->createPlayMoneyOrderCode();
    }
    /**
     * @desc 根据打款订单号获取订单ID
     * */
    public function getOrderByPlayOrderNo($play_money_no){
        return $this->order_model->getOrderByPlayOrderNo($play_money_no);
    }
    /**
     * @desc    根据用户id,信用卡号获取用户刷卡金额
     * @param   int     $uid            用户id
     * @param   int     $status         查询订单状态
     * @param   int     $channel_id     通道id
     * @param   int     $type           通道类型
     * @param   string  $creditCard     信用卡卡号
     * @return  array   $return         返回搜索信息
     */
    public function getAllAmountByUid($uid, $status, $channel_id, $type, $creditCard, $startTime, $endTime){
        $res = $this->order_model->countAllAmountByUid($uid, $status, $channel_id, $type, $creditCard, $startTime, $endTime);
        return $res['amount'] ? $res['amount'] : 0;
    }
    /**
     * @desc 脚本 获取未支付订单
     * */
    public function getOrderByStatus($status){
        return $this->order_model->getOrderByStatus($status);
    }
    /**
     * @desc 根据订单号获取结算信息
     * */
    public  function getOrderPlayData($order_id){
        return $this->order_model->getOrderPlayData($order_id);
    }
    /**
     * @desc    根据OrderCode获取跳转链接
     * @param   string     $order_code   订单code码
     * @param   boolean     $is_check    是否校验时间
     * @return  array   $return     返回订单信息
     */
    public function getRecirectByOrderCode($orderCode,$is_check = false){
        return $this->order_model->getRecirectByOrderCode($orderCode,$is_check);
    }
    
    /**
     * 获取最后一次取款时间
     *
     * @param unknown $uid
     * @return string
     */
    public function getLastPlayTime($uid) {
        return $this->order_model->getLastPlayTime($uid);
    }
    
    /**
     * 获取第一次取款时间
     *
     * @param unknown $uid
     * @return string
     */
    public function getFirstPlayTime($uid) {
        return $this->order_model->getFirstPlayTime($uid);
    }

    /**
     * 获取所有订单
     *
     * @param
     * @return array    订单列表
     */
    public function getAllOrder() {
        return $this->order_model->getAllOrder();
    }
    /**
     * @desc 获取用户最后一条取款成功的订单
     */
    public function getUserLastOrder($uid,$status){
        return $this->order_model->getUserLastOrder($uid,$status);
    }
    /**
     * @desc 获取通道一天的订单数量
     * @param    int     $channel_id       通道ID
     * @param    string  $start_time       开始时间
     * @param    string  $end_time         结束时间
     * @return   int
     */
    public function getTodayOrderBychannelId($channel_id,$start_time,$end_time){
        $res = $this->order_model->getTodayOrderBychannelId($channel_id,$start_time,$end_time);
        return $res ? $res['num'] : 0;
    }
    /**
     * @desc 脚本调用 获取支付成功未分润的订单
     *
     */
    public function getIsProfitOrder($start,$is_profit,$status){
        return  $this->order_model->getIsProfitOrder($start,$is_profit,$status);
    }
}