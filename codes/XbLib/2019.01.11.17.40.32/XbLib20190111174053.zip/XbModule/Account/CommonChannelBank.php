<?php


class XbModule_Account_CommonChannelBank {
    
    private $channel_bank_model;
    
    private static $obj;
    
    private $token_expire = 2592000;    //token生存期30天
    
    private function __construct() {
        $this->channel_bank_model = new XbModel_Account_CommonChannelBank();
    }
    
    /**
     * 单例
     * 
     * @return XbModule_Account_CommonChannelBank
     */
    public static function getInstance() {
        if (!self::$obj) {
            self::$obj = new self();
        }
        
        return self::$obj;
    }
    
    /**
     * 查询通道银行设置
     * 
     * @param string $channel_id 通道id
     * @param string $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param string $bank_code 银行编号
     * @param string $status 状态（1：可用;0;不可用）
     * @param number $offset 
     * @param number $limit
     * @return array
     */
    public function listChannelBank($channel_id = '', $type = '', $bank_code = '', $status = '', $offset = 0, $limit = 30) {
        return $this->channel_bank_model->listBank($channel_id, $type, $bank_code, $status, $offset, $limit);
    }
    
    /**
     * 统计通道银行设置
     * 
     * @param string $channel_id 通道id
     * @param string $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param string $bank_code 银行编号
     * @param string $status 状态（1：可用;0;不可用）
     * @return string
     */
    public function countChannelBank($channel_id = '', $type = '', $bank_code = '', $status = '') {
        return $this->channel_bank_model->countBank($channel_id, $type, $bank_code, $status);
    }
    
    /**
     * 获取全部通道
     * 
     * @return multitype:[]
     */
    public function getChannelList()
    {
        return $this->channel_bank_model->getChannelList();
    }
    
    /**
     * 创建通道银行设置
     * 
     * @param unknown $channe_id 通道id
     * @param unknown $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param unknown $bank_code 银行编号
     * @param unknown $min_charge 单笔最小交易额度
     * @param unknown $max_charge 单笔最大交易额度
     * @param unknown $day_max_charge 单日单卡最大交易额度
     * @param unknown $month_max_charge 单月单卡最大交易额度
     * @param unknown $status 状态（1：可用;0;不可用）
     * @return boolean|string
     */
    public function createChannelBank($channe_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status) {
        return $this->channel_bank_model->createChannelBank($channe_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status);
    }
    
    /**
     * 更新银行通道设置
     * 
     * @param unknown $id 记录id
     * @param unknown $channe_id 通道id
     * @param unknown $type 银行卡类型（1：信用卡；2：储蓄卡）
     * @param unknown $bank_code 银行编号
     * @param unknown $min_charge 单笔最小交易额度
     * @param unknown $max_charge 单笔最大交易额度
     * @param unknown $day_max_charge 单日单卡最大交易额度
     * @param unknown $month_max_charge 单月单卡最大交易额度
     * @param unknown $status 状态（1：可用;0;不可用）
     * @return boolean|number
     */
    public function updateChannelBank($id, $channe_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status) {
        return $this->channel_bank_model->updateChannelBank($id, $channe_id, $type, $bank_code, $min_charge, $max_charge, $day_max_charge, $month_max_charge, $status);
    }
    
    /**
     * 获取单个银行设置
     * 
     * @param unknown $id
     * @return mixed|multitype:|unknown
     */
    public function getChannelBank($id) {
        return $this->channel_bank_model->getChannelBank($id);
    }
    
    /**
     * 删除设置记录
     * 
     * @param unknown $id
     * @return number
     */
    public function deleteChannelBank($id) {
        return $this->channel_bank_model->deleteChannelBank($id);
    }
    /**
     * @desc 通道通道ID获取信用卡列表
     */
    public function getBankByChannelId($channel_id){

    }
    
}