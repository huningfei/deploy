<?php
/**
 * @desc  标识管理
 * Created by PhpStorm.
 * User: yurong
 * Date: 2018/5/18
 * Time: 上午10:58
 */
class XbModule_Account_Flag{
    private $flag_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModule_Account_Flag constructor.
     */
    private function __construct() {
        $this->flag_model = new XbModel_Account_Flag();
    }

    /**
     * 单例
     * @return null|XbModule_Account_Flag
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_Flag();
        }
        return self::$obj;
    }

    /**
     * @desc 标识列表
     * @param
     * @return
     * */
    public function getList($start,$limit,$type,$flag_name,$flag_cate){
        return $this->flag_model->getList($start,$limit,$type,$flag_name,$flag_cate);
    }
    /**
     * @desc 获取条数
     * @param      int    $type       类型（true:标识分类；false:标识）
     * @param      string $flag_name  标识名称（true:标识分类；false:标识）
     * @param      int    $flag_cate  标识分类（true:标识分类；false:标识）
     * @return     array  $return     返回执行结果
     * */
    public function getListCount($type,$flag_name,$flag_cate){
        return $this->flag_model->getListCount($type,$flag_name,$flag_cate);
    }
    /**
     * @desc 获取标识分类下总条数
     * @param   int   $pid    标识分类ID
     * @return  array $return 返回执行结果
     * */
    public function getTitleCount($pid){
        return $this->flag_model->getTitleCount($pid);
    }

    /**
     * @desc 获取单条标识
     * @param   int   $pid    标识分类ID
     * @return  array $return 返回执行结果
     * */
    public function getflagById($pid){
        return $this->flag_model->getflagById($pid);
    }
    /**
     * @desc 获取所有标识分类
     * @param   int    $pid   标识分类ID
     * @return  array  $return返回执行结果
     * */
    public function getAllFlagCate($pid){
        return $this->flag_model->getAllFlagCate($pid);
    }
    /**
     * @desc 编辑标识
     * @param   int        $id             标识ID
     * @param   int        $pid            标识分类ID
     * @param   string     $title          标识名称
     * @param   string     $description    备注
     * @return  boolean    $return         返回执行结果
     * */
    public function edit($id,$pid,$title,$description){
        return $this->flag_model->edit($id,$pid,$title,$description);
    }
    /**
     * @desc 新增标识
     * @param   int        $pid            标识分类ID
     * @param   string     $title          标识名称
     * @param   string     $description    备注
     * @return  boolean    $return         返回执行结果
     * */
    public function add($pid,$title,$description){
        return $this->flag_model->add($pid,$title,$description);
    }
    /**
     * @desc 删除标识，标识分类
     * */
    public function delete($id){
        return $this->flag_model->delete($id);
    }

}