<?php
class XbModule_Account_Merchant{
    private $help_model = null;
    private static $obj = null;
    /**
     * 封闭构造
     * XbModule_Account_Merchant constructor.
     */
    private function __construct() {
        $this->model = new XbModel_Account_Merchant();
    }

    /**
     * 单例
     * @return null|XbModule_Account_Merchant
     */
    public static function getInstance() {
        if (empty(self::$obj)) {
            self::$obj = new XbModule_Account_Merchant();
        }
        return self::$obj;
    }

    /**
     * @desc 获取所有地区
     * @return   array     $return      返回执行结果
     * */
    public function getDistrict(){
        return $this->model->getDistrict();
    }

    /**
     * @desc 获取所有商户类型
     * @return   array     $return      返回执行结果
     * */
    public function getMerchantType(){
        return $this->model->getMerchantType();
    }

    /**
     * @desc 获取商户列表
     * @param    int       $aisle       通道
     * @param    int       $district_id 地区id
     * @param    int       $merchant_type_id  商户类型
     * @return   array     $return      返回执行结果
     * */
    public function getMerchant($aisle, $district_id, $merchant_type_id, $page=array()){
        $aisle       = !empty($aisle) ? $aisle : 1;
//        $district_id = !empty($district_id) ? $district_id : 1;
//        $merchant_type_id = !empty($merchant_type_id) ? $merchant_type_id : 1;
        return $this->model->getMerchant($aisle, $district_id, $merchant_type_id, $page);
    }

    /**
     * @desc 选择商户
     * @param    int       $district_id 地区id
     * @param    int       $merchant_id 商户id
     * @return   array     $return      返回执行结果
     * */
    public function selectMerchant($order_type, $district_id, $merchant_id){
        if ($order_type == 20){
            //一键还款
            $res = $this->model->getMerchantById($merchant_id);
        }elseif ($order_type == 30){
            //智能还款
            $res = $this->model->getMerchantByDistrict($district_id);
        }
        return $res;
    }


    /**
     * @desc 脚本插入商户信息
     * @param    string    $sql         sql
     * @return   array     $return      返回执行结果
     * */
    public function addMerchantSql($sql_arr){
        $num = count($sql_arr);
        if($num < 1) {
            return fale;
        }
        $success_num = 0;
        for($i = 0; $i < $num; $i++){
            $res = $this->model->addMerchantSql($sql_arr[$i]);
            if ($res){
                $success_num++;
            }else{
                XbFunc_Log::write('merchant_create','创建商户信息失败 ', $sql_arr[$i]);
            }
            printf("\r (%d/%d)", $i+1, $num);
        }
        return $success_num;
    }
}
