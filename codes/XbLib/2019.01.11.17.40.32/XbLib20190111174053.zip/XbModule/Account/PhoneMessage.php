<?php
/**
 * @desc 	记录发送短信详情
 * @author  qien
 * @date    18.1.3
 */
class XbModule_Account_PhoneMessage{
    private $message_model = null;
    private static $obj  = null;

    /**
     * 封闭构造
     * XbModel_Account_PhoneMessage constructor.
     */
    private function __construct() {
        $this->message_model = new XbModel_Account_PhoneMessage();
    }

    /**
     * 单例获取
     * 保证一条进程只产生一个Module对象
     */
    public static function getInstance() {
        if (empty ( self::$obj )) {
            self::$obj = new XbModule_Account_PhoneMessage();
        }
        return self::$obj;
    }

    /**
     * @desc    创建短信数据
     * @param   int     $phone      发送短信手机号
     * @param   int     $mch_id     商户id
     * @param   string  $type       短信类型：reg,login,updatepwd...
     * @param   int     $uid        用户id
     * @return  boolen  $return     返回执行结果
     */
    public function createMessage($phone, $mch_id, $type, $uid=0){
        return $this->message_model->createMessage($phone, $mch_id, $type, $uid);
    }
}