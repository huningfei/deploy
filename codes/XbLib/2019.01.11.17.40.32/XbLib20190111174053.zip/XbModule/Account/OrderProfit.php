<?php
/**
 * @desc 	下单时，订单反润用户表
 * @author  qien
 * @date    18.3.5
 */
class XbModule_Account_OrderProfit{
    private $order_profit_model = null;
    private static $obj  = null;

    /**
     * 封闭构造
     * XbModel_Account_OrderProfit constructor.
     */
    private function __construct() {
        $this->order_profit_model = new XbModel_Account_OrderProfit();
    }

    /**
     * 单例获取
     * 保证一条进程只产生一个Module对象
     */
    public static function getInstance() {
        if (empty ( self::$obj )) {
            self::$obj = new XbModule_Account_OrderProfit();
        }
        return self::$obj;
    }

    /**
     * @desc    创建反润列表
     * @param   array   $profitInfo     反润信息
     * @param   array   $orderid        订单id
     * @param   array   $table          订单表
     * @return  boolen  $return         返回结果
     */
    public function createProfit($profitInfo, $orderid, $table){
        return $this->order_profit_model->createProfit($profitInfo, $orderid, $table);
    }

    /**
     * @desc    根据订单表，订单id获取下单时分润信息
     * @param   int     $table      订单表
     * @param   int     $orderid    订单id
     * @return  array   $return     返回搜索结果
     */
    public function getOrderProfit($table, $orderid){
        return $this->order_profit_model->getOrderProfit($table, $orderid);
    }
}