<?php
/**
 * 
 * @author Abel
 * email:abel.zhou@hotmail.com
 * 2014-9-23
 * UTF-8
 */
class XbFunc_Log{

    protected static $_ip = '127.0.0.1';
    
    protected static $_port = 9002;
    
    protected static function _synclog($msg) {
        $handle = stream_socket_client('udp://' . static::$_ip . ':' . static::$_port, $errno, $errstr);
        if($handle){
            fwrite($handle, $msg);
            fclose($handle);
        }

//         $client = new swoole_client(SWOOLE_SOCK_UDP, SWOOLE_SOCK_SYNC);
//         $client->connect(static::$_ip, static::$_port, 5);
//         $client->send($msg);
//         $client->close();

    }
	
    /**
     * 写日志
     * 
     * @param unknown $module_name 模块名称
     * @param unknown $notice_header 消息头
     * @param string $notice_body 消息内容
     * @param number $level 消息等级：
     *                      0 - 4 写入硬盘
     *                      5 - 9 发送预警系统做数量统计
     *                      10 - 14 邮件通知相关人员，并发送日志内容 
     *                      15 + 邮件 + 短信通知相关人员
     * @return boolean
     */
	public static function write($module_name,$notice_header,$notice_body='', $level = 0){
		$path = LIBRARY_DIR.'/../XbLogs/';
		if(!file_exists($path)){
			@mkdir($path,0755);
		}
		$date_str = date('Y-m-d');
		$date_fmt = date('Y-m-d H:i:s',time());
		$path = $path.$module_name.'/';
		if(!file_exists($path)){
			@mkdir($path,0755);
		}
		$filepath = $path.$date_str.'.log';
		if ( ! $fp = @fopen($filepath, 'ab'))
		{
			return false;
		}
		$message = $date_fmt.'::'.$notice_header.'::'.$notice_body."\n";
		flock($fp, LOCK_EX);
		fwrite($fp, $message);
		flock($fp, LOCK_UN);
		fclose($fp);
		@chmod($filepath, 0755);
		
		if ($level > 4) {
		    $data = [
		        'type' => $module_name,
		        'level' => $level,
		        'date' => $date_fmt,
		        'head' => '',
		        'body' => ''
		    ];
		    
		    // 5 - 9 级不发送日志内容，只统计数量
		    if ($level >= 10) {
		        //6k以上日志截断
		        $data['head'] = $notice_header;
		        $data['body'] = substr($notice_body, 0, 6 * 1024);
		    }
		    
		    static::_synclog(json_encode($data));
		}
		
		return true;
	}
}